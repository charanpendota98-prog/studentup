<?php
/**
 * v64: PWA + performance head hints.
 *
 * Mobile lo "Add to Home screen" (app laga), theme-color, preconnect
 * (AdSense/GA — first ad request fast), apple touch icon.
 * v72: service worker kuda undi (query tho serve — / lo scope header tho). Adi only
 * site pages/fonts cache chestundi; AdSense/analytics requests ni touch cheyyadu.
 *
 * @package studentup
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * manifest.json ni query tho serve cheyyadam (rewrite rules avasaram ledu).
 */
function studentup_manifest() {
	if ( ! isset( $_GET['studentup_manifest'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
		return;
	}
	$icon = '';
	if ( has_site_icon() ) {
		$icon = get_site_icon_url( 512 );
	}
	/*
	 * Keep every long-press shortcut actionable. `#jobs` and `#qualsplit` are
	 * real homepage anchors; results and quiz are content groups/pages and do
	 * not have guaranteed anchors on every WordPress install. Resolve those to
	 * the live category/page when available, with a same-site search fallback
	 * instead of shipping shortcuts that open an empty section.
	 */
	$results_url = add_query_arg( 's', 'results', home_url( '/' ) );
	$results_cat = function_exists( 'studentup_used_term' ) ? studentup_used_term( 'results' ) : null;
	if ( $results_cat && ! is_wp_error( $results_cat ) ) {
		$results_url = get_category_link( $results_cat );
	}
	$quiz_url  = add_query_arg( 's', 'daily quiz', home_url( '/' ) );
	/*
	 * v178 REAL FIX: purathana logic EMPTY daily-quiz category ki pontundi —
	 * posts lekapote shortcut ki dead-end (live install proof: cards=0).
	 * Home lo #daily-quiz section (real quiz UI) opt ON unta sariga render
	 * avutundi — categories lekunda kuda shortcut live destination ki.
	 */
	if ( studentup_opt( 'daily_quiz', '1' ) ) {
		$quiz_url = home_url( '/#daily-quiz' );
	} else {
		$quiz_page = get_page_by_path( 'quiz' );
		$quiz_cat  = get_category_by_slug( 'daily-quiz' );
		if ( $quiz_page && 'publish' === get_post_status( $quiz_page ) ) {
			$quiz_url = get_permalink( $quiz_page );
		} elseif ( $quiz_cat && ! is_wp_error( $quiz_cat ) ) {
			$quiz_url = get_category_link( $quiz_cat );
		}
	}
	$manifest = array(
		'name'             => get_bloginfo( 'name' ),
		'short_name'       => mb_substr( get_bloginfo( 'name' ), 0, 12 ),
		'start_url'        => home_url( '/' ),
		'scope'            => home_url( '/' ),
		'display'          => 'standalone',
		'background_color' => '#ffffff',
		'theme_color'      => function_exists( 'studentup_brand_theme_color' ) ? studentup_brand_theme_color() : '#c2410c',
		'lang'             => 'te-IN',
		'orientation'      => 'portrait',
		'description'      => get_bloginfo( 'description' ),
		'categories'       => array( 'news', 'education', 'jobs' ),
		// v72.1: app icon long-press → live, student-first destinations.
		'shortcuts'        => array(
			array(
				'name'       => 'Jobs',
				'short_name' => 'Jobs',
				'url'        => home_url( '/#jobs' ),
			),
			array(
				'name'       => 'Jobs by qualification',
				'short_name' => 'Qualification',
				'url'        => home_url( '/#qualsplit' ),
			),
			array(
				'name'       => 'Results',
				'short_name' => 'Results',
				'url'        => $results_url,
			),
			array(
				'name'       => 'Daily Quiz',
				'short_name' => 'Quiz',
				'url'        => $quiz_url,
			),
		),
	);
	if ( $icon ) {
		/*
		 * v178: Site Icon unte 192 + 512 + maskable — Chrome install prompt
		 * minimum 192x192 icon kavali; okka 512 matrame chalu kadhu.
		 */
		$manifest['icons'] = array(
			array( 'src' => get_site_icon_url( 192 ), 'sizes' => '192x192', 'type' => 'image/png', 'purpose' => 'any' ),
			array( 'src' => $icon, 'sizes' => '512x512', 'type' => 'image/png', 'purpose' => 'any' ),
			array( 'src' => $icon, 'sizes' => '512x512', 'type' => 'image/png', 'purpose' => 'maskable' ),
		);
	} else {
		/*
		 * v178 REAL FIX: Site Icon set cheyyakapote manifest lo icons LEdu —
		 * Chrome/PWA install prompt eppudu raadu (live install proof: manifest
		 * icons: [] empty). Theme lo ship aina brand icons fallback:
		 * pwa-192.png + pwa-512.png + maskable variant.
		 */
		$base                = get_template_directory_uri() . '/assets';
		$manifest['icons']   = array(
			array( 'src' => $base . '/pwa-192.png', 'sizes' => '192x192', 'type' => 'image/png', 'purpose' => 'any' ),
			array( 'src' => $base . '/pwa-512.png', 'sizes' => '512x512', 'type' => 'image/png', 'purpose' => 'any' ),
			array( 'src' => $base . '/pwa-maskable-512.png', 'sizes' => '512x512', 'type' => 'image/png', 'purpose' => 'maskable' ),
		);
	}
	// v178: empty/default tagline unte brand description — install sheet lo nagna text vaddu.
	$manifest_desc = (string) get_bloginfo( 'description' );
	if ( '' === trim( $manifest_desc ) || 'Just another WordPress site' === $manifest_desc ) {
		$manifest_desc = 'తెలంగాణ & ఆంధ్రప్రదేశ్ విద్యార్థుల కోసం ఉద్యోగాలు, స్కాలర్‌షిప్‌లు, రిజల్ట్స్, హాల్ టికెట్లు — అన్ని అప్‌డేట్స్ ఒకే యాప్‌లో.';
	}
	$manifest['description'] = $manifest_desc;
	nocache_headers();
	header( 'Content-Type: application/manifest+json; charset=utf-8' );
	echo wp_json_encode( $manifest, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES );
	exit;
}
add_action( 'template_redirect', 'studentup_manifest' );

/**
 * head hints: manifest link, theme-color and apple icon. Third-party hints live
 * in perf.php and are conditional on a configured feature.
 */
function studentup_head_hints() {
	if ( is_admin() ) {
		return;
	}
	echo '<meta name="theme-color" content="' . esc_attr( function_exists( 'studentup_brand_theme_color' ) ? studentup_brand_theme_color() : '#c2410c' ) . '">' . "\n";
	// Third-party resource hints are emitted centrally by perf.php only when
	// Ads/GA4 are really enabled; avoid duplicate or unused connections here.
	if ( studentup_opt( 'pwa', '1' ) ) {
		echo '<link rel="manifest" href="' . esc_url( add_query_arg( 'studentup_manifest', '1', home_url( '/' ) ) ) . '">' . "\n";
		echo '<meta name="apple-mobile-web-app-capable" content="yes">' . "\n";
		echo '<meta name="apple-mobile-web-app-title" content="' . esc_attr( get_bloginfo( 'name' ) ) . '">' . "\n";
		if ( has_site_icon() ) {
			echo '<link rel="apple-touch-icon" href="' . esc_url( get_site_icon_url( 180 ) ) . '">' . "\n";
		}
	}
}
add_action( 'wp_head', 'studentup_head_hints', 3 );

/**
 * v72: service worker JS (query `?studentup_sw=1` tho serve — root scope header tho).
 *
 * Enti cache avutundi: site pages (network-first → fresh news), static files
 * (cache-first). Enti cache avvadu: AdSense/GA/third-party (avvi touch cheyyamu).
 *
 * @return string
 */
function studentup_sw_js() {
	$ver     = defined( 'STUDENTUP_VERSION' ) ? STUDENTUP_VERSION : '1';
	$offline = '<!doctype html><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">'
		. '<title>ఆఫ్‌లైన్ — ' . esc_html( get_bloginfo( 'name' ) ) . '</title>'
		. '<body style="font-family:system-ui,sans-serif;margin:0;padding:28px;text-align:center;color:#c2410c">'
		. '<h1 style="font-size:20px">మీరు ఆఫ్‌లైన్‌లో ఉన్నారు</h1>'
		. '<p style="color:#5b6b85;font-size:14px;line-height:1.7">ఇప్పటికే చూసిన పేజీలు అందుబాటులో ఉంటాయి — ఇంటర్నెట్ తిరిగి వచ్చాక కొత్త ఉద్యోగాలు, ఫలితాలు, అప్‌డేట్స్ లోడ్ అవుతాయి.</p>'
		. '<p style="font-size:14px"><a href="' . esc_url( home_url( '/' ) ) . '" style="color:#c2410c">↻ మళ్లీ ప్రయత్నించండి</a></p>';

	return 'var VERSION=' . wp_json_encode( 'su-' . $ver ) . ';' . "\n"
		. 'var OFFLINE=' . wp_json_encode( $offline ) . ';' . "\n"
		. 'var SHELL=' . wp_json_encode( array( home_url( '/' ) ) ) . ';' . "\n"
		. <<<'JSEOF'
// v163: web push — bot pampina notification ni chupinchadam.
self.addEventListener("push", function (e) {
  var d = {};
  try { d = e.data ? e.data.json() : {}; } catch (err) { d = {}; }
  var title = d.title || "StudentUp";
  var opts = {
    body: d.body || "",
    icon: d.icon || undefined,
    badge: d.badge || undefined,
    tag: d.tag || "studentup",
    renotify: !!d.high,
    requireInteraction: !!d.high,
    vibrate: d.high ? [120, 60, 120] : [80],
    timestamp: d.ts ? d.ts * 1000 : Date.now(),
    data: { url: d.url || "/", title: title },
    actions: [{ action: "open", title: "Open" }, { action: "wa", title: "WhatsApp" }]
  };
  if (d.image) { opts.image = d.image; }   /* v305: featured image = big picture (Android) */
  e.waitUntil(self.registration.showNotification(title, opts));
});

// Notification click -> aa post ki. Already open unna tab unte adi focus
// chestam, kotha tab spam cheyyam.
self.addEventListener("notificationclick", function (e) {
  e.notification.close();
  var url = (e.notification.data && e.notification.data.url) || "/";
  if (e.action === "wa") {   /* v305: share to WhatsApp straight from the notification */
    var t = (e.notification.data && e.notification.data.title) || "StudentUp";
    url = "https://wa.me/?text=" + encodeURIComponent(t + "\n" + url.split("?")[0] + "\n— StudentUp (studentup.in)");
    e.waitUntil(clients.openWindow ? clients.openWindow(url) : null);
    return;
  }
  e.waitUntil(clients.matchAll({ type: "window", includeUncontrolled: true }).then(function (list) {
    for (var i = 0; i < list.length; i++) {
      if (list[i].url === url && "focus" in list[i]) { return list[i].focus(); }
    }
    return clients.openWindow ? clients.openWindow(url) : null;
  }));
});

self.addEventListener("install", function (e) {
  e.waitUntil(caches.open(VERSION).then(function (c) { return c.addAll(SHELL).catch(function () {}); })
    .then(function () { return self.skipWaiting(); }));
});
self.addEventListener("activate", function (e) {
  e.waitUntil(caches.keys().then(function (keys) {
    return Promise.all(keys.map(function (k) { return k === VERSION ? null : caches.delete(k); }));
  }).then(function () { return self.clients.claim(); }));
});
self.addEventListener("fetch", function (e) {
  var req = e.request;
  if (req.method !== "GET") return;
  var url = new URL(req.url);
  if (url.origin !== self.location.origin) return;   /* ads/analytics untouch */
  var isHtml = req.mode === "navigate" || (req.headers.get("accept") || "").indexOf("text/html") > -1;
  if (isHtml) {
    e.respondWith(fetch(req).then(function (res) {
      var copy = res.clone();
      caches.open(VERSION).then(function (c) { c.put(req, copy); });
      return res;
    }).catch(function () {
      return caches.match(req).then(function (hit) {
        return hit || new Response(OFFLINE, { headers: { "Content-Type": "text/html; charset=utf-8" } });
      });
    }));
    return;
  }
  e.respondWith(caches.match(req).then(function (hit) {
    return hit || fetch(req).then(function (res) {
      if (res && res.status === 200 && res.type === "basic") {
        var copy = res.clone();
        caches.open(VERSION).then(function (c) { c.put(req, copy); });
      }
      return res;
    }).catch(function () { return hit; });
  }));
});
JSEOF;
}

/**
 * Service worker ni query tho serve cheyyadam (rewrite rule avasaram ledu).
 */
function studentup_service_worker() {
	if ( ! isset( $_GET['studentup_sw'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
		return;
	}
	if ( ! studentup_opt( 'pwa', '1' ) ) {
		return;
	}
	nocache_headers();
	header( 'Content-Type: application/javascript; charset=utf-8' );
	header( 'Service-Worker-Allowed: /' );
	echo studentup_sw_js(); // phpcs:ignore WordPress.Security.EscapeOutput
	exit;
}
add_action( 'template_redirect', 'studentup_service_worker' );

/**
 * Install-prompt JS ki data pass (SW url, iOS hint).
 */
function studentup_pwa_data() {
	if ( is_admin() || ! wp_script_is( 'studentup-pwa', 'enqueued' ) ) {
		return;
	}
	wp_localize_script(
		'studentup-pwa',
		'STUDENTUP_PWA',
		array(
			'sw'      => esc_url_raw( add_query_arg( 'studentup_sw', '1', home_url( '/' ) ) ),
			'scope'   => '/',
			'iosHint' => 'iPhone: tap Share → Add to Home Screen to install it like an app.',
		)
	);
}
add_action( 'wp_enqueue_scripts', 'studentup_pwa_data', 20 );

/**
 * v211 — "Download app chupisthu undali": persistent app-install mini bar.
 *
 * Footer lo #installbtn deep ga undi — chala readers ki kanipinchadu. Ee slim
 * bar phone lo bottom-nav paina kurchuntundi, desktop lo right-bottom card.
 * Close chesina session matrame remember (owner: "chupisthu undali" —
 * next visit lo malli kanipistundi), app install ayithe poyipoddi.
 * Layout clash levu: .su-appbar-on class tho push bar automatic ga painiki
 * jarugutundi (worldclass.css §26), bottom-nav paina clean stack.
 */
function studentup_app_bar() {
	if ( is_admin() ) {
		return;
	}
	?>
	<div class="su-appbar" id="su-appbar" role="complementary" aria-label="<?php echo esc_attr__( 'StudentUp App', 'studentup' ); ?>" hidden>
		<div class="su-appbar-in">
			<span class="su-appbar-mark" aria-hidden="true">SU</span>
			<div class="su-appbar-tx"><strong><?php echo esc_html__( 'StudentUp App', 'studentup' ); ?></strong></div>
			<button type="button" class="su-appbar-go su-install-cta"><?php echo esc_html__( 'Install', 'studentup' ); ?></button>
			<button type="button" class="su-appbar-x" aria-label="<?php echo esc_attr__( 'Close install banner', 'studentup' ); ?>">✕</button>
		</div>
	</div>
	<?php
}
add_action( 'wp_footer', 'studentup_app_bar', 25 );

/**
 * AdSense auto ads script (option ON unte mattrame) — AdSense policy: ee code
 * unte site lo ads Google auto ga pedutundi; slots manual ga kuda undachu.
 */
function studentup_adsense_auto_head() {
	if ( is_admin() || ! studentup_opt( 'adsense_auto', '0' ) ) {
		return;
	}
	// v84: approval gate + format check anni studentup_adsense_client() lone
	// (ads.php mundhe load avutundi — functions.php line 20 vs 32).
	$client = function_exists( 'studentup_adsense_client' )
		? (string) studentup_adsense_client() : '';
	if ( '' === $client ) {
		return;
	}
	echo '<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client='
		. esc_attr( $client ) . '" crossorigin="anonymous"></script>' . "\n";
}
add_action( 'wp_head', 'studentup_adsense_auto_head', 6 );
