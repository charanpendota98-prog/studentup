<?php
/**
 * v158 — Key-facts strip + HowTo schema (AEO).
 *
 * Rendu kuda **meta unte ne** vastayi. Data lekapote block ye raadu —
 * empty "—" cells or guessed numbers Google ki thin content signal,
 * readers ki kuda cheddha experience.
 *
 * @package studentup
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Post lo unna real meta values matrame collect chestundi.
 *
 * @param int $post_id post id.
 * @return array label => value (only non-empty).
 */
function studentup_keyfacts_data( $post_id = 0 ) {
	$post_id = $post_id ? (int) $post_id : get_the_ID();
	/* v173: emoji icons → pro SVG icon keys (studentup_ui_icon). */
	$map     = array(
		'studentup_vacancies' => array( __( 'Vacancies', 'studentup' ), 'card' ),
		'studentup_qual'      => array( __( 'Qualification', 'studentup' ), 'school' ),
		'studentup_salary'    => array( __( 'Salary', 'studentup' ), 'wallet' ),
		'studentup_fee'       => array( __( 'Fee', 'studentup' ), 'ticket' ),
		'studentup_age_min'   => array( __( 'Age', 'studentup' ), 'person' ),
		'studentup_last_date' => array( __( 'Last date', 'studentup' ), 'calendar' ),
	);

	$out = array();
	foreach ( $map as $key => $meta ) {
		$val = trim( (string) get_post_meta( $post_id, $key, true ) );
		if ( '' === $val ) {
			continue;
		}
		if ( 'studentup_qual' === $key && function_exists( 'studentup_qual_pretty' ) ) {
			$val = studentup_qual_pretty( $val );   // v174: "degree,pg" → "Degree · PG".
		}
		if ( 'studentup_age_min' === $key ) {
			$mx  = trim( (string) get_post_meta( $post_id, 'studentup_age_max', true ) );
			$val = $mx ? $val . ' – ' . $mx . ' yrs' : $val . '+ yrs';
		}
		if ( 'studentup_last_date' === $key ) {
			$ts = strtotime( $val );
			if ( $ts ) {
				$val = date_i18n( 'd M Y', $ts );
			}
		}
		$out[] = array(
			'label' => $meta[0],
			'icon'  => $meta[1],
			'value' => $val,
		);
	}
	return $out;
}

/**
 * Key numbers strip — snippet-friendly plain text (spans, no tables).
 */
function studentup_keyfacts_box() {
	if ( ! is_singular( 'post' ) || ! studentup_opt( 'keyfacts', '1' ) ) {
		return;
	}
	// v310: Key Highlights box (quick_summary) already lists vacancies/qualification/salary/last date —
	// same facts twice, stacked = clutter. Strip renders only when that box is switched off.
	// v1.9.117: quick_summary box no longer in the post template → this strip is THE facts block.
	$facts = studentup_keyfacts_data();
	$apply = esc_url_raw( (string) get_post_meta( get_the_ID(), 'studentup_apply_url', true ) );
	if ( count( $facts ) < 2 && ! $apply ) {
		return; // okate fact unte strip ki value ledu.
	}
	?>
	<div class="su-keyfacts" aria-label="<?php esc_attr_e( 'Key details', 'studentup' ); ?>">
		<?php if ( $apply ) : // v1.9.117: primary click — official apply link first, above the fold ?>
			<a class="su-kf-apply" href="<?php echo esc_url( $apply ); ?>" target="_blank" rel="noopener nofollow" data-su-click="apply-top"><?php echo studentup_ui_icon( 'external', 16 ); // phpcs:ignore WordPress.Security.EscapeOutput -- trusted SVG ?> <?php esc_html_e( 'Apply Online (Official)', 'studentup' ); ?></a>
		<?php endif; ?>
		<?php foreach ( $facts as $f ) : ?>
			<div class="su-kf">
				<span class="su-kf-i" aria-hidden="true"><?php echo studentup_ui_icon( $f['icon'], 16 ); // phpcs:ignore WordPress.Security.EscapeOutput -- trusted SVG ?></span>
				<span class="su-kf-l"><?php echo esc_html( $f['label'] ); ?></span>
				<strong class="su-kf-v"><?php echo esc_html( $f['value'] ); ?></strong>
			</div>
		<?php endforeach; ?>
	</div>
	<?php
}

/**
 * Content lo "How to apply" heading kinda unna <ol> nunchi steps teestundi.
 *
 * @param string $content post content.
 * @return array steps (plain text). 3 kanna thakkuva unte empty.
 */
function studentup_howto_steps( $content = '' ) {
	if ( '' === $content ) {
		$content = get_post_field( 'post_content', get_the_ID() );
	}
	/**
	 * Apply-section heading patterns. Theme PHP lo Telugu literals undakudadu
	 * (v73 rule) — extra languages ee filter dwara add cheyyandi.
	 *
	 * @param string $pattern regex alternation body.
	 */
	$su_apply = apply_filters( 'studentup_apply_heading_pattern', 'how\s+to\s+apply|apply\s+online|application\s+process' );

	if ( ! $content || ! preg_match( '~(' . $su_apply . ')~i', $content ) ) {
		return array();
	}

	// Apply heading taruvata unna first <ol> matrame.
	if ( ! preg_match(
		'~<h[2-4][^>]*>[^<]*(?:' . $su_apply . ')[^<]*</h[2-4]>(.*?)(?:<h[2-4]|$)~is',
		$content,
		$block
	) ) {
		return array();
	}
	if ( ! preg_match( '~<ol[^>]*>(.*?)</ol>~is', $block[1], $ol ) ) {
		return array();
	}
	if ( ! preg_match_all( '~<li[^>]*>(.*?)</li>~is', $ol[1], $items ) ) {
		return array();
	}

	$steps = array();
	foreach ( $items[1] as $raw ) {
		$text = trim( wp_strip_all_tags( $raw ) );
		if ( strlen( $text ) >= 8 ) {
			$steps[] = $text;
		}
	}
	return count( $steps ) >= 3 ? array_slice( $steps, 0, 12 ) : array();
}

/**
 * HowTo JSON-LD — nijamaina steps unte ne. Fake schema = manual action risk.
 */
function studentup_howto_schema() {
	if ( is_admin() || is_feed() || ! is_singular( 'post' ) || ! studentup_opt( 'keyfacts', '1' ) ) {
		return;
	}
	$steps = studentup_howto_steps();
	if ( count( $steps ) < 3 ) {
		return;
	}

	$list = array();
	$i    = 0;
	foreach ( $steps as $step ) {
		$i++;
		$list[] = array(
			'@type'    => 'HowToStep',
			'position' => $i,
			'text'     => wp_html_excerpt( $step, 300, '' ),
		);
	}

	$node = array(
		'@context' => 'https://schema.org',
		'@type'    => 'HowTo',
		'@id'      => get_permalink() . '#howto',
		'name'     => wp_html_excerpt( get_the_title(), 110, '' ),
		'step'     => $list,
	);

	echo "\n<script type=\"application/ld+json\">" .
		wp_json_encode( $node, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ) .
		"</script>\n"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- wp_json_encode output.
}
add_action( 'wp_head', 'studentup_howto_schema', 22 );
