<?php
/**
 * Template helpers — post cards, breadcrumbs, trust note, share/qualification bits.
 *
 * @package studentup
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Category slug → count (most-used tiles ki).
 *
 * @param string $slug category slug.
 * @return int
 */
function studentup_cat_count( $slug ) {
	$term = studentup_used_term( $slug );   // v89: alias-aware (live slugs differ)
	return $term ? (int) $term->count : 0;
}

/**
 * Card category slug (WP category slug nunchi design chips ki).
 *
 * @param int $post_id post id.
 * @return string
 */
function studentup_card_cat( $post_id = 0 ) {
	$post_id = $post_id ? $post_id : get_the_ID();
	$cats    = get_the_category( $post_id );
	if ( ! $cats ) {
		return 'current-affairs';
	}
	// v89: live slug (‑govt heavy) → theme chip slug — TS/AP/Central chips filter match avvali.
	foreach ( $cats as $c ) {
		$theme_slug = studentup_theme_cat( $c->slug );
		if ( $theme_slug !== $c->slug || in_array( $theme_slug, wp_list_pluck( studentup_most_used(), 'slug' ), true ) ) {
			return sanitize_html_class( $theme_slug );
		}
	}
	return sanitize_html_class( studentup_theme_cat( $cats[0]->slug ) );
}

/**
 * Post card — design (preview) markup same.
 *
 * @param int $idx index (thumb colour rotation).
 */
/**
 * v191.1 WORLDCLASS: card category accent (left/top edge colour).
 *
 * Enduku: list lo okka look tho "TS job aa, AP job aa, result aa" teliyali —
 * reader scan speed perigutundi, bounce taggutundi. Guess ledu: mee category
 * peru nunchi mattrame decide chestundi.
 *
 * @param string $label first category name.
 * @return string accent slug.
 */
function studentup_card_accent( $label = '' ) {
	$key = strtolower( (string) $label );
	if ( false !== strpos( $key, 'result' ) ) {
		return 'result';
	}
	if ( false !== strpos( $key, 'scholarship' ) ) {
		return 'scholarship';
	}
	if ( false !== strpos( $key, 'central' ) || false !== strpos( $key, 'ssc' ) || false !== strpos( $key, 'rrb' ) ) {
		return 'central';
	}
	if ( false !== strpos( $key, 'ap ' ) || false !== strpos( $key, 'andhra' ) ) {
		return 'ap';
	}
	if ( false !== strpos( $key, 'ts ' ) || false !== strpos( $key, 'telangana' ) ) {
		return 'ts';
	}
	return 'update';
}

/**
 * v192: monogram for the designed cover art ("Central Govt" → "CG", "TS Jobs" → "TS").
 *
 * @param string $label Category label.
 * @return string 1-3 uppercase characters.
 */
function studentup_card_monogram( $label ) {
	$label = trim( preg_replace( '/\s+/u', ' ', (string) $label ) );
	if ( '' === $label ) {
		return 'SU';
	}
	$words = preg_split( '/\s+/u', $label );
	$first = mb_strtoupper( $words[0] );
	// "SSC CHSL" → SSC · "TSPSC Group" → TSP · "Central Govt" → CG · "Results" → RE
	if ( mb_strlen( $first ) <= 3 ) {
		return $first;
	}
	$mono = mb_substr( $first, 0, 2 );
	if ( isset( $words[1] ) && mb_strlen( $mono ) < 2 ) {
		$mono .= mb_strtoupper( mb_substr( $words[1], 0, 1 ) );
	}
	return $mono;
}

function studentup_card( $idx = 0 ) {
	$cat   = studentup_card_cat();
	$terms = get_the_category();
$label = $terms ? $terms[0]->name : 'Update';
	$tones = array( '', 't2', 't3' );
	$tone  = $tones[ $idx % 3 ];
	?>
	<?php
	$su_qual_raw = trim( (string) get_post_meta( get_the_ID(), 'studentup_qual', true ) );
	$su_last_raw = trim( (string) get_post_meta( get_the_ID(), 'studentup_last_date', true ) );
	// v156: state tags for the personalised strip - derived from the real
	// category slugs, never guessed.
	$su_states = array();
	foreach ( (array) get_the_category() as $su_term ) {
		$su_slug = isset( $su_term->slug ) ? $su_term->slug : '';
		if ( false !== strpos( $su_slug, 'ts-' ) || false !== strpos( $su_slug, 'telangana' ) ) {
			$su_states[] = 'ts';
		}
		if ( false !== strpos( $su_slug, 'ap-' ) || false !== strpos( $su_slug, 'andhra' ) ) {
			$su_states[] = 'ap';
		}
		if ( false !== strpos( $su_slug, 'central' ) ) {
			$su_states[] = 'central';
		}
	}
	$su_states = implode( ' ', array_unique( $su_states ) );
	// v191.1: home first card = editorial lead (peddha card) + category accent.
	$su_accent = studentup_card_accent( $label );
	$su_lead   = ( 0 === (int) $idx && ( is_front_page() || is_home() ) ) ? ' news--lead' : '';
	?>
	<article <?php post_class( 'news' . $su_lead ); ?> data-accent="<?php echo esc_attr( $su_accent ); ?>" data-su-card data-cat="<?php echo esc_attr( $cat ); ?>"
		data-qual="<?php echo esc_attr( $su_qual_raw ); ?>"
		data-state="<?php echo esc_attr( $su_states ); ?>"
		data-last="<?php echo esc_attr( $su_last_raw ); ?>"
		data-pub="<?php echo esc_attr( (string) get_post_time( 'U', true ) ); ?>"
		data-text="<?php echo esc_attr( mb_strtolower( get_the_title() . ' ' . get_the_excerpt() ) ); ?>">
		<?php if ( has_post_thumbnail() ) : ?>
			<a class="thumb <?php echo esc_attr( $tone ); ?>" href="<?php the_permalink(); ?>" aria-hidden="true" tabindex="-1">
				<?php
				// v157 LCP: the first card image is usually the largest element
				// above the fold, so it must NOT be lazy-loaded. Everything
				// after it stays lazy.
				$su_img_attr = array( 'alt' => esc_attr( get_the_title() ) );
				if ( 0 === (int) $idx ) {
					$su_img_attr['loading']       = 'eager';
					$su_img_attr['fetchpriority'] = 'high';
				} else {
					$su_img_attr['loading'] = 'lazy';
				}
				the_post_thumbnail( 'studentup-card', $su_img_attr );
				?>
			</a>
		<?php else : ?>
			<?php // v192: photo lekapote DESIGNED cover (gradient + monogram + category pill) —
			// purathana version post title ni plain text box lo print chesedi, adi wireframe la kanipinchedi. ?>
			<a class="thumb thumb--auto <?php echo esc_attr( $tone ); ?>" href="<?php the_permalink(); ?>" aria-hidden="true" tabindex="-1">
				<span class="su-cov">
					<b class="su-cov-mono"><?php echo esc_html( studentup_card_monogram( $label ) ); ?></b>
					<span class="su-cov-cat"><?php echo esc_html( $label ); ?></span>
					<span class="su-cov-brand">StudentUp</span>
				</span>
			</a>
		<?php endif; ?>
		<div class="newsbody">
			<div class="tagrow">
				<span class="tag"><?php echo esc_html( $label ); ?></span>
				<?php
				// v140: honest freshness tag — only for posts actually published
				// in the last 24 hours. No fake "HOT" on an old notification.
				if ( ( time() - (int) get_post_time( 'U', true ) ) < DAY_IN_SECONDS ) {
					echo '<span class="su-fresh">' . esc_html__( 'NEW', 'studentup' ) . '</span>';
				}
				?>
				<?php studentup_qual_chip(); ?>
				<?php
				// v206 FIX: owner feedback — "Central2 hrs ago" / "3 min read" /
				// "Last date 05 Nov" ani copy-paste chesinappudu bunchाga kanipinchi,
				// "ivi vaddu" ani confirm chesaru → statechip (time-ago), reading-time,
				// last-date badge anni card meta nunchi full ga తీసేశాం. Category tag
				// (.tag span above) + title + excerpt + read-more/share/save matrame
				// migిలాయి.
				?>
			</div>
			<?php $su_card_h = ( is_archive() || is_search() || is_home() ) ? 'h2' : 'h3'; // v1.9.143: archive h1 → card h2 (no heading skip). ?>
			<<?php echo tag_escape( $su_card_h ); ?>><a href="<?php the_permalink(); ?>" style="color:inherit"><?php the_title(); ?></a></<?php echo tag_escape( $su_card_h ); ?>>
			<p><?php echo esc_html( wp_trim_words( get_the_excerpt(), 20, '…' ) ); ?></p>
			<div class="newsfoot">
				<a class="su-readmore" href="<?php the_permalink(); ?>" aria-label="<?php echo esc_attr( get_the_title() . ' — ' . __( 'Read more', 'studentup' ) ); ?>"><?php echo esc_html__( 'Read more', 'studentup' ) . ' →'; ?></a>

				<?php
				$su_share_title = rawurlencode( get_the_title() );
				$su_share_url   = rawurlencode( get_permalink() );
				?>
				<a class="su-card-wa" href="https://wa.me/?text=<?php echo esc_attr( $su_share_title . '%20' . $su_share_url ); ?>" target="_blank" rel="noopener" aria-label="<?php echo esc_attr( get_the_title() . ' — ' . __( 'Share on WhatsApp', 'studentup' ) ); ?>" title="<?php esc_attr_e( 'Share on WhatsApp', 'studentup' ); ?>">
					<svg width="12" height="12" viewBox="0 0 24 24" fill="currentColor"><path d="M12.04 2C6.58 2 2.13 6.45 2.13 11.91C2.13 13.66 2.59 15.36 3.45 16.86L2.05 22L7.3 20.62C8.75 21.41 10.38 21.83 12.04 21.83C17.5 21.83 21.95 17.38 21.95 11.92C21.95 9.27 20.92 6.78 19.05 4.91C17.18 3.03 14.69 2 12.04 2Z"/></svg> <?php esc_html_e( 'Share', 'studentup' ); ?>
				</a>
				<?php echo studentup_save_button( 0, 'su-save-card' ); // v92: 🔖 save-for-later (escaped in helper) ?>
				<?php if ( function_exists( 'studentup_tool_buttons' ) ) : ?>
					<?php echo wp_kses_post( studentup_tool_buttons( 0, 'card' ) ); ?>
				<?php endif; ?>
			</div>
		</div>
	</article>
	<?php
}

/**
 * Reading time (Telugu label).
 *
 * @param int $post_id post.
 * @return string
 */
function studentup_reading_time( $post_id = 0 ) {
	$post_id = $post_id ? $post_id : get_the_ID();
	$words   = str_word_count( wp_strip_all_tags( (string) get_post_field( 'post_content', $post_id ) ) );
	$words   = max( $words, mb_strlen( wp_strip_all_tags( (string) get_post_field( 'post_content', $post_id ) ) ) / 6 );
	$minutes = max( 2, (int) ceil( $words / 220 ) );
	/* translators: %d: minutes */
	return sprintf( __( '%d min read', 'studentup' ), $minutes );
}

/**
 * Trust note (corrections email) — prathi post kindha.
 */
function studentup_trust_note() {
	$email = (string) get_option( 'admin_email', '' );
	echo '<div class="trustnote">' . studentup_ui_icon( 'check', 13 ) . ' ' // phpcs:ignore WordPress.Security.EscapeOutput -- trusted SVG
		. esc_html( sprintf(
			/* translators: %s: corrections email */
			__( 'This article was checked against official sources and written in simple language. If you spot a mistake, %s — we correct it within 24 hours. Always confirm deadlines and numbers in the official notification.', 'studentup' ),
			$email
		) ) . '</div>';
}

/**
 * Default menu (Appearance → Menus lo 'primary' assign cheyyakapote).
 *
 * v93 (UI fix): ippati varaku idi Home + 9 categories ni **flat ga** render chesindi —
 * prathi item ki description line tho. Result: header lo 10 items, 2 lines each,
 * overflow — menu chala cluttered ga kanipinchindi (approved preview design ki
 * polika ledu). Preview design lo menu **grouped dropdowns**:
 *   Home · Jobs ▾ · Hall Tickets · Results · Current Affairs · More ▾
 *
 * Ippudu fallback kuda ade structure istundi (`menu-item-has-children` +
 * `ul.sub-menu`) — anduke theme CSS dropdown anni pani chestayi, and
 * `wp_nav_menu` (user menu) tho markup **okate** feel.
 *
 * Rules:
 *   · Terms eppudu alias-aware (`studentup_used_term`) — TS/AP/Central missing aithe
 *     aa item automatic ga skip (empty link ledu).
 *   · Ee category okkati kuda exist kaakapote parent **khali dropdown** chupinchadu —
 *     daaniki badulu flat Home-only menu (site clean).
 *   · Page links (Saved / Contact / Quiz) unte mattrame chupistundi (404 ledu).
 *
 * @return void
 */
function studentup_menu_fallback() {
	$home = home_url( '/' );

	/** Theme slug → term (alias-aware). Missing = null (skip). */
	$term_of = static function ( $slug ) {
		return studentup_used_term( $slug );
	};

	/*
	 * v197 MEGA PANEL — terms/pages nijamga unte mattrame (404 ledu). Module
	 * lekunda (purana install) kinda v93 dropdown body ne pani chestundi.
	 */
	if ( function_exists( 'studentup_mega_render' ) && '0' !== (string) studentup_opt( 'mega_menu', '1' ) ) {
		$su_mega = studentup_mega_ready();
		if ( $su_mega ) {
			studentup_mega_render( $su_mega, $home );
			return;
		}
	}

	// Dropdown group definitions (preview design order).
	$groups = array(
		array(
			'label' => 'Jobs',
			'items' => array( 'ts-jobs', 'ap-jobs', 'central-jobs', 'private-jobs', 'walkin-jobs', 'software-jobs', 'success-stories' ),
		),
	);
	// v123: Scholarships + Daily Quiz menu lo eppudu kanipinchali (user request).
	$top = array( 'scholarships', 'hall-tickets', 'results', 'current-affairs', 'daily-quiz' );

	$label_of = array();
	foreach ( studentup_most_used() as $m ) {
		$label_of[ $m['slug'] ] = $m;
	}
	// v123: most_used lo leni, kaani menu lo kavalsina sections.
	$label_of['scholarships'] = array( 'slug' => 'scholarships', 'label' => 'Scholarships', 'icon' => 'school', 'hint' => 'Central · state · private' );
	$label_of['daily-quiz']   = array( 'slug' => 'daily-quiz', 'label' => 'Daily Quiz', 'icon' => 'chart', 'hint' => 'Roju 5 questions' );
	$label_of['internships']  = array( 'slug' => 'internships', 'label' => 'Internships', 'icon' => 'work', 'hint' => 'Stipend · remote · college' );

	$menu = array();

	/**
	 * Jobs dropdown — terms unte mattrame (lekapote top-level ga chupinchadu).
	 */
	$jobs_children = array();
	foreach ( $groups[0]['items'] as $slug ) {
		$term = $term_of( $slug );
		if ( ! $term || ! isset( $label_of[ $slug ] ) ) {
			continue;
		}
		$jobs_children[] = array(
			'label' => $label_of[ $slug ]['label'],
			'url'   => get_category_link( $term ),
			'desc'  => $label_of[ $slug ]['hint'],
		);
	}
	if ( $jobs_children ) {
		$menu[] = array( 'label' => 'Jobs', 'url' => $jobs_children[0]['url'], 'children' => $jobs_children );
	}

	/**
	 * Top-level singles (only if the term really exists).
	 */
	foreach ( $top as $slug ) {
		$term = $term_of( $slug );
		if ( ! $term || ! isset( $label_of[ $slug ] ) ) {
			continue;
		}
		$menu[] = array(
			'label' => $label_of[ $slug ]['label'],
			'url'   => get_category_link( $term ),
		);
	}

	/**
	 * "More" — page links unte mattrame (404 eppudu ledu).
	 */
	$more = array(
		array( 'label' => 'Latest active jobs', 'url' => studentup_opportunity_board_url(), 'desc' => 'Dates unna active notices only' ),
		array( 'label' => 'Daily Quiz', 'url' => $home . '#daily-quiz', 'desc' => 'Today\'s 5 questions' ),
		array( 'label' => 'Compare Jobs', 'url' => studentup_compare_page_url(), 'desc' => 'Compare up to 3 posts' ),
		array( 'label' => 'Instant alerts', 'url' => studentup_alerts_url(), 'desc' => 'WhatsApp · Telegram channel' ),
	);
	if ( function_exists( 'studentup_tools_enabled' ) && studentup_tools_enabled() ) { // v304: tools OFF (v248) → dead #anchor entries vaddu
		$more[] = array( 'label' => 'Age Calculator', 'url' => $home . '#age-calculator', 'desc' => 'Check age eligibility with reservation relaxation' );
		$more[] = array( 'label' => 'Fee Calculator', 'url' => $home . '#fee-calculator', 'desc' => 'Calculate application & exam fee' );
		$more[] = array( 'label' => 'Syllabus Tracker', 'url' => $home . '#syllabus-tracker', 'desc' => 'Track your exam study progress' );
		$more[] = array( 'label' => 'Salary Calculator', 'url' => $home . '#salary-calculator', 'desc' => '7th Pay Commission in-hand pay' );
	}
	$intern_term = $term_of( 'internships' );
	if ( $intern_term ) {
		$more[] = array( 'label' => 'Internships', 'url' => get_category_link( $intern_term ), 'desc' => 'Stipend · remote · college' );
	}
	$success_term = $term_of( 'success-stories' );
	if ( $success_term && isset( $label_of['success-stories'] ) ) {
		$more[] = array(
			'label' => $label_of['success-stories']['label'],
			'url'   => get_category_link( $success_term ),
			'desc'  => $label_of['success-stories']['hint'],
		);
	}
	$pages = array(
		array( 'slug' => 'saved',   'label' => 'Saved posts', 'desc' => 'Padhukoni tarvata chudandi' ),
		array( 'slug' => 'contact', 'label' => 'Contact',     'desc' => 'Corrections · suggestions' ),
		array( 'slug' => 'about',   'label' => 'About',       'desc' => 'Who writes this' ),
		array( 'slug' => 'quiz',    'label' => 'Daily Quiz',  'desc' => 'Practice questions' ),
	);
	foreach ( $pages as $pg ) {
		$page = get_page_by_path( $pg['slug'] );
		if ( $page && 'publish' === get_post_status( $page ) ) {
			$more[] = array(
				'label' => $pg['label'],
				'url'   => get_permalink( $page ),
				'desc'  => $pg['desc'],
			);
		}
	}
	$more[] = array(
		'label' => 'Jobs by qualification',
		'url'   => $home . '#qualsplit',
		'desc'  => '10th · Inter · Degree · PG',
	);
	$tg = function_exists( 'studentup_tg_channel_url' ) ? studentup_tg_channel_url() : '';
	if ( $tg ) {
		$more[] = array( 'label' => 'Telegram channel', 'url' => $tg, 'desc' => 'Job alerts first' );
	}
	$more[] = array( 'label' => 'All categories', 'url' => $home . '#jobs', 'desc' => 'Every job section' );

	if ( $more ) {
		$menu[] = array(
			'label'    => 'More',
			'url'      => $more[0]['url'],
			'children' => $more,
		);
	}

	/**
	 * Render — `wp_nav_menu` markup ki same (CSS okkate pani chestundi).
	 */
	echo '<ul id="primary-menu" class="menu-primary">';
	printf(
		'<li class="menu-item%s"><a href="%s">%s</a></li>',
		( is_front_page() ? ' current-menu-item' : '' ),
		esc_url( $home ),
		esc_html__( 'Home', 'studentup' )
	);
	// v202: Breaking News item — mega renderer laage legacy fallback lo kuda (Home tarvata).
	if ( function_exists( 'studentup_breaking_nav_li' ) ) {
		echo studentup_breaking_nav_li(); // phpcs:ignore WordPress.Security.EscapeOutput -- escaped inside.
	}
	foreach ( $menu as $it ) {
		$has_kids = ! empty( $it['children'] );
		printf(
			'<li class="menu-item%s">',
			$has_kids ? ' menu-item-has-children' : ''
		);
		if ( $has_kids ) {
			printf(
				'<a href="%s" aria-haspopup="true" aria-expanded="false">%s</a>',
				esc_url( $it['url'] ),
				esc_html( translate( $it['label'], 'studentup' ) )
			);
			echo '<ul class="sub-menu">';
			foreach ( $it['children'] as $ch ) {
				printf(
					'<li class="menu-item"><a href="%s">%s%s</a></li>',
					esc_url( $ch['url'] ),
					esc_html( translate( $ch['label'], 'studentup' ) ),
					( ! empty( $ch['desc'] ) ? '<small>' . esc_html( translate( $ch['desc'], 'studentup' ) ) . '</small>' : '' )
				);
			}
			echo '</ul>';
		} else {
			printf( '<a href="%s">%s</a>', esc_url( $it['url'] ), esc_html( translate( $it['label'], 'studentup' ) ) );
		}
		echo '</li>';
	}
	echo '</ul>';
}

/**
 * Breadcrumbs (Rank Math unte adi — ledu aithe idi).
 *
 * @return string
 */
function studentup_breadcrumbs() {
	if ( function_exists( 'rank_math_the_breadcrumbs' ) ) {
		ob_start();
		rank_math_the_breadcrumbs();
		$rm = trim( (string) ob_get_clean() );
		if ( '' !== $rm ) {
			return $rm;
		}
		// v1.9.126: Rank Math breadcrumbs module OFF (default) → theme trail below.
	}
	$out = '<a href="' . esc_url( home_url( '/' ) ) . '">' . esc_html__( 'Home', 'studentup' ) . '</a>';
	if ( is_singular() ) {
		$cats = get_the_category();
		if ( $cats ) {
			$out .= ' › <a href="' . esc_url( get_category_link( $cats[0] ) ) . '">' . esc_html( $cats[0]->name ) . '</a>';
		}
		$out .= ' › ' . esc_html( wp_trim_words( get_the_title(), 8, '…' ) );
	} elseif ( is_archive() ) {
		// v353: "Category: Jobs" prefix → plain term name (prefix is noise in a trail).
		$crumb = is_category() || is_tag() || is_tax() ? single_term_title( '', false ) : '';
		if ( '' === (string) $crumb ) {
			$crumb = wp_strip_all_tags( get_the_archive_title() );
		}
		$out .= ' › ' . esc_html( $crumb );
	}
	return $out;
}

/**
 * v67: comments OFF (admin option) → comment form + list are not rendered.
 *
 * @param bool $open Comments open state.
 * @return bool
 */
function studentup_comments_open( $open ) {
	return '0' === (string) studentup_opt( 'comments_on', '1' ) ? false : $open;
}
add_filter( 'comments_open', 'studentup_comments_open' );

/**
 * v80 (P16): subcategory chips for category archives (child cats + counts).
 * Child categories levu → output emi ledu (honest empty, no dummy chips).
 */
function studentup_subcat_chips( $cat_id ) {
	$cat_id = (int) $cat_id;
	if ( $cat_id <= 0 ) {
		return;
	}
	$kids = get_categories(
		array(
			'parent'     => $cat_id,
			'hide_empty' => true,
			'number'     => 12,
		)
	);
	if ( ! $kids ) {
		return;
	}
	echo '<nav class="su-subcats" aria-label="' . esc_attr__( 'Subcategories', 'studentup' ) . '">';
	foreach ( $kids as $kid ) {
		printf(
			'<a href="%s">%s</a>',
			esc_url( get_category_link( $kid ) ),
			esc_html( $kid->name )
		);
	}
	echo '</nav>';
}
