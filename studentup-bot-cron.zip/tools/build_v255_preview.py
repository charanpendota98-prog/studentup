#!/usr/bin/env python3
"""v255 preview builder — phone-fix design (section grid + social rail).

Emits preview/v255/index.html: the REAL theme markup (hero + 3-per-row
section grid + usedgrid + drawer + footer + social rail) wired to the REAL
theme CSS files, so the owner can open it on phone AND laptop and verify
before uploading the theme zip to WordPress.
"""
import json
import pathlib
import re

ROOT = pathlib.Path(__file__).resolve().parents[1]
THEME = ROOT / "wordpress-theme" / "studentup"
OUT = ROOT / "preview" / "v255" / "index.html"

ui = {
    "moon": "M12 3a9 9 0 1 0 9 9c0-.46-.04-.92-.1-1.36a5.389 5.389 0 0 1-4.4 2.26 5.403 5.403 0 0 1-3.14-9.8c-.44-.06-.9-.1-1.36-.1z",}
for m in re.finditer(r"^\s*'([a-z-]+)'\s*=>\s*'([^']+)'",
                     (THEME / "inc" / "icons.php").read_text(encoding="utf-8"), re.M):
    ui[m.group(1)] = m.group(2)
soc = {}
src = (THEME / "inc" / "options.php").read_text(encoding="utf-8")
m = re.search(r"function studentup_social_icon_paths\(\).*?\$paths = array\((.*?)\n\t\);", src, re.S)
for k, d in re.findall(r"'([a-z]+)'\s*=>\s*'([^']+)'", m.group(1)):
    soc[k] = d


def icon(key, size=22):
    return ('<svg class="su-uicon" width="%d" height="%d" viewBox="0 0 24 24" '
            'fill="currentColor" aria-hidden="true"><path d="%s"></path></svg>'
            % (size, size, ui.get(key, ui["arrow"])))


def socicon(key, size=19):
    return ('<svg width="%d" height="%d" viewBox="0 0 24 24" fill="currentColor" '
            'aria-hidden="true"><path d="%s"></path></svg>' % (size, size, soc[key]))


SITE = "https://studentup.in"
RAIL = [
    ("bank", "TS Govt Jobs", "TSPSC · Police", SITE + "/category/ts-jobs/"),
    ("city", "AP Govt Jobs", "APPSC · DSC", SITE + "/category/ap-jobs/"),
    ("flag", "Central Jobs", "SSC · UPSC · RRB", SITE + "/category/central-jobs/"),
    ("laptop", "Software Jobs", "IT · fresher", SITE + "/category/software-jobs/"),
    ("building", "Private Jobs", "Off-campus", SITE + "/category/private-jobs/"),
    ("ticket", "Hall Tickets", "Admit cards", SITE + "/category/hall-tickets/"),
    ("award", "Results", "Marks · cutoff", SITE + "/category/results/"),
    ("bolt", "Breaking News", "Live updates", SITE + "/#jobs"),
    ("walk", "Walk-in Jobs", "This week", SITE + "/category/walkin-jobs/"),
    ("work", "Internships", "Stipend · FTE", SITE + "/category/internships/"),
    ("school", "Scholarships", "Fees · renewals", SITE + "/category/scholarships/"),
    ("trophy", "Success Stories", "Verified journeys", SITE + "/category/success-stories/"),
    ("news", "Current Affairs", "Daily GK", SITE + "/category/current-affairs/"),
]

USED = [
    ("bolt", "Breaking News", "Live flash updates", "su-used-breaking"),
    ("bank", "TS Govt Jobs", "TSPSC · Police · Gurukul", "usedcard hot"),
    ("city", "AP Govt Jobs", "APPSC · DSC · Secretariat", "usedcard hot"),
    ("flag", "Central Jobs", "SSC · UPSC · RRB · Banks", "usedcard hot"),
    ("badge", "Hall Tickets", "Admit card download", "usedcard"),
    ("award", "Results", "Marks · cutoff · answer key", "usedcard"),
    ("school", "Scholarships", "Fees · renewals · status", "usedcard"),
    ("work", "Internships", "Stipend · FTE offers", "usedcard"),
]

NOTIFS = [
    ("TS Police Constable Result 2026 Released — Check Cutoff & Marks", "Results · 2 hrs ago"),
    ("TG Gurukulam TSA Admit Card 2026 Download Hall Ticket @gurukulam", "Hall Tickets · 4 hrs ago"),
    ("UPSC NTA Exam Calendar 2027 Out — Full Schedule, 4 New Exams", "Central Jobs · today"),
    ("ICAR Internship Applications Open — Stipend Rs 10,000/mo", "Internships · today"),
    ("TSPSC Group-2 Notification 2026 — 783 Posts, Apply Online", "TS Govt · today"),
    ("APPSC Junior Assistant Hall Tickets Out — Download Now", "AP Govt · 6 hrs ago"),
    ("TCS NQT Freshers Drive 2026 — 2025/2026 Batch Eligible", "Software · 1 day ago"),
    ("National Scholarship Portal NSP 2.0 — Registration Open", "Scholarships · 1 day ago"),
]
NEWS_ICONS = ["award", "ticket", "flag", "work"]
scards = []
for i, (t, meta) in enumerate(NOTIFS):
    tag, _, when = meta.partition(" · ")
    badge = '<span class="su-scard-new"><i></i>NEW</span>' if i < 2 else ''
    scards.append(
        '<div class="su-scard" data-cat="blue">%s<div class="su-scard-head">'
        '<span class="su-scard-tag">%s</span></div>'
        '<div class="su-scard-thumb">%s</div>'
        '<h3><a href="%s">%s</a></h3>'
        '<div class="su-scard-meta"><span>%s</span></div>'
        '<div class="su-scard-acts-row"><a class="su-scard-act" href="%s">'
        '<span>Full details &amp; Apply</span><span aria-hidden="true">→</span></a></div></div>'
        % (badge, tag, icon(NEWS_ICONS[i % 4], 36), SITE, t, when, SITE))
news_html = "".join(scards)

TREND = ["TSPSC Group-1", "Police Constable", "DSC 2026", "RRB NTPC", "Hall Tickets"]
trend_html = "".join('<button type="button" class="su-tchip">%s</button>' % q for q in TREND)

dots_html = "".join(
    '<button type="button" class="su-sdot%s" role="tab" aria-selected="%s" aria-label="Slide %d"></button>'
    % (" on" if i == 0 else "", "true" if i == 0 else "false", i + 1)
    for i in range(len(scards)))

rail_html = []
for i, (ic, lab, hint, url) in enumerate(RAIL, 1):
    rail_html.append(
        '<a role="listitem" class="su-cat c%d" href="%s">%s<b>%s</b><small>%s</small></a>'
        % (i, url, '<span class="su-cat-ic" aria-hidden="true">%s</span>' % icon(ic, 24), lab, hint))

used_html = []
for ic, lab, hint, cls in USED:
    if cls == "su-used-breaking":
        used_html.append(
            '<a class="su-used-breaking" href="#"><span class="ui ui--breaking">%s</span>'
            '<div class="su-ub-body"><div class="su-ub-top"><span class="su-ub-tag">'
            '<span class="su-pulse-dot"></span> LIVE FLASH</span><b>Breaking News</b></div>'
            '<small>Latest notifications · hall tickets &amp; exam alerts</small></div>'
            '<em class="ucount ucount--brk">Flash Updates →</em></a>' % icon("bolt", 20))
    else:
        used_html.append(
            '<a class="%s" href="#"><span class="ui">%s</span><div><b>%s</b>'
            '<small>%s</small></div><em class="ucount">12 updates</em></a>'
            % (cls, icon(ic, 22), lab, hint))

drawer_rows = [
    ("home", "Home", ""), ("bank", "TS Govt Jobs", ""),
    ("city", "AP Govt Jobs", "APPSC · DSC · Secretariat"), ("flag", "Central Jobs", "SSC · UPSC · RRB · Banks"),
    ("walk", "Walk-in Jobs", "This week drives · venues"), ("laptop", "Software Jobs", "IT · developer · support"),
    ("building", "Private Jobs", "Off-campus · fresher drives"), ("ticket", "Hall Tickets", "Admit card download"),
    ("award", "Results", "Marks · cutoff · answer key"), ("bolt", "Breaking News", "Live verified updates"),
    ("chart", "Daily Quiz", "Fresh questions every day"),
]
drawer_html = "".join(
    '<a class="su-mmain-a%s" href="#">%s<span class="su-mmain-t">%s%s</span>%s</a>'
    % (" su-mmain-brk" if r[0] == "bolt" else "", icon(r[0], 18), r[1],
       ("<small>%s</small>" % r[2]) if r[2] else "", icon("chevron", 14))
    for r in drawer_rows)

critical = (THEME / "assets" / "css" / "critical-home.min.css").read_text(encoding="utf-8")

html = """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>StudentUp v255 — phone fix preview (open on phone &amp; laptop)</title>
<style>/* production first-paint layer (inline, exactly like WP) */
%(critical)s</style>
<link rel="stylesheet" href="../../wordpress-theme/studentup/style.min.css">
<link rel="stylesheet" href="../../wordpress-theme/studentup/assets/css/premium.min.css?v=266">
<link rel="stylesheet" href="../../wordpress-theme/studentup/assets/css/worldclass.min.css?v=266">
<link rel="stylesheet" href="../../wordpress-theme/studentup/assets/css/delight.min.css?v=266">
</head>
<body>
<script>
(function () {
  var el = document.body;
  if (!el) { return; }
  var saved = "";
  try { saved = localStorage.getItem("su_theme") || ""; } catch (e) {}
  var dark = saved === "dark" || (!saved && window.matchMedia &&
    window.matchMedia("(prefers-color-scheme: dark)").matches);
  if (dark) { el.classList.add("dark"); }
  el.setAttribute("data-su-theme", dark ? "dark" : "light");
})();
</script>
<header class="header">
  <div class="wrap headrow">
    <a class="logo" href="#"><svg width="30" height="30" viewBox="0 0 24 24" fill="#2563eb"><path d="%(logo)s"></path></svg>
      <span><span class="brand">Student<span style="color:var(--orange)">Up</span></span></span></a>
    <nav class="nav" aria-label="Primary"><ul class="menu-primary">
      <li class="menu-item"><a href="#">TS Govt Jobs</a></li>
      <li class="menu-item"><a href="#">AP Govt Jobs</a></li>
      <li class="menu-item"><a href="#">Central Jobs</a></li>
      <li class="menu-item"><a href="#">Hall Tickets</a></li>
      <li class="menu-item"><a href="#">Results</a></li>
    </ul></nav>
    <div class="headactions">
      <button type="button" class="iconbtn" aria-label="Search">%(search)s</button>
      <button type="button" class="iconbtn" id="su-theme-adv" aria-label="Dark mode" aria-pressed="false">%(moon)s</button>
      <button type="button" class="iconbtn" id="menubtn" aria-label="Menu">%(menu)s</button>
    </div>
  </div>
</header>

<section class="su-hero" aria-label="StudentUp search and quick links">
  <div class="wrap su-hero-in">
    <h1 class="su-hero-title">Government Jobs, Results &amp; Notifications</h1>
    <div class="su-search-wrap">
      <form class="su-hero-search" role="search">
        <span class="su-hs-ico">%(search)s</span>
        <input id="su-q" type="search" placeholder="Search StudentUp — jobs, hall tickets, results…">
        <button type="submit">Search</button>
      </form>
    </div>
    <div class="su-trend" role="group" aria-label="Trending searches"><b>Trending</b>%(trend)s</div>

    <section class="su-catwrap is-static" aria-label="Browse by section">
      <div class="su-cathead"><b>Browse by section</b><a class="su-viewall" href="#">All sections &rarr;</a></div>
      <div class="su-catbox">
        <div class="su-catrail" role="list">%(rail)s</div>
      </div>
    </section>

    <div class="su-hero-acts">
      <a class="su-hact su-hact--breaking" href="#">%(bolt)s Breaking News</a>
      <a class="su-hact" href="#">%(board)s Latest Jobs</a>
    </div>
    <div class="su-stats" role="list" aria-label="StudentUp live stats">
      <div class="su-stats-item" role="listitem"><b class="su-count" data-count="12">0</b><span>Updates today</span></div>
      <div class="su-stats-item" role="listitem"><b class="su-count" data-count="6">0</b><span>Live job alerts</span></div>
      <div class="su-stats-item" role="listitem"><b class="su-count" data-count="9">0</b><span>Categories</span></div>
      <div class="su-stats-item" role="listitem"><b class="su-count" data-count="100" data-suffix="%%">0</b><span>Free forever</span></div>
    </div>
  </div>
</section>

<section class="usedwrap" aria-label="Most searched by students">
  <div class="wrap">
    <div class="usedhead"><b>Most searched by students</b></div>
    <div class="usedgrid">%(used)s</div>
  </div>
</section>

<section class="su-slider-sec" aria-label="Latest notifications" style="margin:22px 0">
  <div class="wrap">
    <div class="su-slider-head">
      <div class="su-slider-title-wrap">
        <span class="su-slider-badge"><i aria-hidden="true"></i> LIVE</span>
        <h2>Latest Notifications</h2>
      </div>
      <span class="su-slider-arrs"><button type="button" class="su-sbtn" id="su-track-prev" aria-label="Slide Left">&lsaquo;</button><button type="button" class="su-sbtn" id="su-track-next" aria-label="Slide Right">&rsaquo;</button></span>
      <a class="su-viewall" href="%(site)s/latest-jobs/">View all &rarr;</a>
    </div>
    <div class="su-slider-viewport" id="su-jobs-track-wrap" tabindex="0" role="region" aria-label="Scrolling latest jobs">
      <div class="su-slider-track" id="su-jobs-track">%(news)s</div>
    </div>
    <div class="su-sdots" role="tablist" aria-label="Choose slide">%(dots)s</div>
  </div>
</section>

<section class="su-quiz" id="daily-quiz" aria-label="Daily quiz" style="margin:22px 0">
  <div class="wrap"><div class="su-quiz-card">
    <div class="su-quiz-head">
      <div><p class="su-quiz-kick">DAILY QUIZ</p><h2>Roju 3 questions — 1 minute chaalu</h2></div>
      <div class="su-quiz-score" role="status"><b id="qscore">0</b><span>/ 3</span></div>
    </div>
    <div class="su-quiz-bar"><i id="qbar" style="width:0%%"></i></div>
    <div class="su-quiz-live">
      <div class="su-quiz-timer" id="qtimerwrap" aria-hidden="true"><i id="qtimer" style="width:100%%"></i></div>
      <span class="su-quiz-streak" id="qstreak">Streak 0</span>
      <span class="su-quiz-hint">KEYS 1-4 &middot; ENTER NEXT</span>
    </div>
    <fieldset class="su-q su-q-run" data-c="1"><legend class="su-q-title"><span class="su-q-n">1</span> Quantitative Aptitude: A train 240 m long crosses a telegraph pole in 12 seconds. Speed in km/h?</legend>
      <div class="su-q-opts"><button type="button" class="su-q-opt">60 km/h<span class="su-kbd">1</span></button><button type="button" class="su-q-opt">72 km/h<span class="su-kbd">2</span></button><button type="button" class="su-q-opt">54 km/h<span class="su-kbd">3</span></button><button type="button" class="su-q-opt">80 km/h<span class="su-kbd">4</span></button></div></fieldset>
    <fieldset class="su-q" data-c="1"><legend class="su-q-title"><span class="su-q-n">2</span> Logical Reasoning: If 'PAPER' is coded as 'QBQFS', how is 'OFFICE' coded?</legend>
      <div class="su-q-opts"><button type="button" class="su-q-opt">PGGIDF<span class="su-kbd">1</span></button><button type="button" class="su-q-opt">PGGJDF<span class="su-kbd">2</span></button><button type="button" class="su-q-opt">NFFHBD<span class="su-kbd">3</span></button><button type="button" class="su-q-opt">QHHJEG<span class="su-kbd">4</span></button></div></fieldset>
    <fieldset class="su-q" data-c="0"><legend class="su-q-title"><span class="su-q-n">3</span> Indian Polity: Under which Article can a citizen approach the Supreme Court directly for enforcement of Fundamental Rights?</legend>
      <div class="su-q-opts"><button type="button" class="su-q-opt">Article 32<span class="su-kbd">1</span></button><button type="button" class="su-q-opt">Article 226<span class="su-kbd">2</span></button><button type="button" class="su-q-opt">Article 131<span class="su-kbd">3</span></button><button type="button" class="su-q-opt">Article 143<span class="su-kbd">4</span></button></div></fieldset>
    <div class="su-quiz-result" id="qresult" hidden>
      <div class="su-quiz-ring" id="qring"><b id="qringn">0/3</b></div>
      <div><h3 id="qrtitle">Quiz complete!</h3><p id="qrsub">Score share cheyyandi &mdash; friends ni challenge cheyyandi.</p>
      <button type="button" class="su-quiz-share" id="qshare">Share score</button></div>
    </div>
  </div></div>
</section>
<script>
(function () {
  var qs = document.querySelectorAll(".su-q"), qi = 0, score = 0, streak = 0, answered = false;
  var qbar = document.getElementById("qbar"), qscore = document.getElementById("qscore");
  var qtimer = document.getElementById("qtimer"), qtimerwrap = document.getElementById("qtimerwrap");
  var qstreak = document.getElementById("qstreak"), qresult = document.getElementById("qresult");
  var qring = document.getElementById("qring"), qringn = document.getElementById("qringn");
  var qrtitle = document.getElementById("qrtitle"), qrsub = document.getElementById("qrsub");
  var qshare = document.getElementById("qshare");
  var t0 = 0, ticking = false, TOTAL = qs.length, LIMIT = 20000;

  function show(i) {
    for (var k = 0; k < qs.length; k++) { qs[k].style.display = k === i ? "" : "none"; }
  }
  function tick(ts) {
    if (!t0) { t0 = ts; }
    var passed = ts - t0, left = Math.max(0, 1 - passed / LIMIT);
    if (qtimer) { qtimer.style.width = (left * 100).toFixed(1) + "%%"; }
    if (qtimerwrap) {
      if (left < 0.35) { qtimerwrap.classList.add("su-warn"); }
      else { qtimerwrap.classList.remove("su-warn"); }
    }
    if (!answered && left > 0) { window.requestAnimationFrame(tick); }
    else if (!answered) { timeout(); }
    ticking = false;
  }
  function startTimer() {
    t0 = 0; answered = false;
    if (qtimer) { qtimer.style.width = "100%%"; }
    if (qtimerwrap) { qtimerwrap.classList.remove("su-warn"); }
    window.requestAnimationFrame(tick);
  }
  function lock(btns, correct) {
    for (var k = 0; k < btns.length; k++) {
      btns[k].disabled = true;
      if (k === correct) { btns[k].classList.add("ok"); }
    }
  }
  function next() {
    qi++;
    if (qbar) { qbar.style.width = ((qi / TOTAL) * 100).toFixed(1) + "%%"; }
    if (qi < TOTAL) { show(qi); startTimer(); }
    else { finish(); }
  }
  function timeout() {
    answered = true;
    var q = qs[qi], btns = q.querySelectorAll(".su-q-opt");
    lock(btns, parseInt(q.getAttribute("data-c"), 10) || 0);
    streak = 0;
    if (qstreak) { qstreak.textContent = "Streak 0"; }
    window.setTimeout(next, 650);
  }
  function choose(b) {
    if (answered) { return; }
    answered = true;
    var q = qs[qi], btns = q.querySelectorAll(".su-q-opt");
    var c = parseInt(q.getAttribute("data-c"), 10) || 0;
    var picked = -1;
    for (var k = 0; k < btns.length; k++) {
      if (btns[k] === b) { picked = k; }
    }
    if (picked === c) {
      b.classList.add("ok");
      score++; streak++;
      if (qscore) { qscore.textContent = String(score); }
    } else {
      b.classList.add("bad");
      streak = 0;
    }
    if (qstreak) { qstreak.textContent = "Streak " + streak; }
    lock(btns, c);
    window.setTimeout(next, 550);
  }
  function finish() {
    if (qresult) {
      qresult.hidden = false;
      if (qring) {
        qring.style.setProperty("--su-qr", Math.round((score / TOTAL) * 360) + "deg");
      }
      if (qringn) { qringn.textContent = score + "/" + TOTAL; }
      if (qrtitle) {
        qrtitle.textContent = score === TOTAL ? "Perfect score! Super!" : (score >= 2 ? "Bagundi! Chala better avutundi." : "Practice chesthe improve avutundi.");
      }
      if (qrsub) { qrsub.textContent = "StudentUp Daily Quiz — roju kotha questions. Share cheyyandi!"; }
    }
  }
  for (var i = 0; i < qs.length; i++) {
    (function (q) {
      var btns = q.querySelectorAll(".su-q-opt");
      for (var k = 0; k < btns.length; k++) {
        (function (b) { b.addEventListener("click", function () { choose(b); }); })(btns[k]);
      }
    })(qs[i]);
  }
  if (qshare) {
    qshare.addEventListener("click", function () {
      var msg = "StudentUp Daily Quiz lo " + score + "/" + TOTAL + " score! Meeru try cheyyandi: studentup.in";
      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(msg).then(function () {
          qshare.textContent = "Copied!";
          window.setTimeout(function () { qshare.textContent = "Share score"; }, 1600);
        });
      }
    });
  }
  document.addEventListener("keydown", function (e) {
    var t = e.target, tag = t && t.tagName ? String(t.tagName).toLowerCase() : "";
    if (tag === "input" || tag === "textarea" || (t && t.isContentEditable)) { return; }
    if (qi >= TOTAL) { return; }
    if (e.key >= "1" && e.key <= "4") {
      var btns = qs[qi].querySelectorAll(".su-q-opt");
      var idx = parseInt(e.key, 10) - 1;
      if (btns[idx]) { btns[idx].click(); }
      e.preventDefault();
    } else if (e.key === "Enter" && answered) {
      e.preventDefault();
    }
  });
  if (qs.length) { show(0); startTimer(); }
})();
</script>

<footer class="footer">
  <div class="wrap">
    <div class="footer-grid">
      <div><h3>StudentUp</h3><p>Jobs, scholarships, results and exam updates for students.</p></div>
      <div><h3>Categories</h3><ul>
        <li><a href="#">TS Govt Jobs</a></li><li><a href="#">AP Govt Jobs</a></li>
        <li><a href="#">Central Jobs</a></li><li><a href="#">Hall Tickets</a></li>
      </ul></div>
      <div><h3>Follow us</h3>
        <div class="su-ft-soc">
          <a class="su-socb-wa" href="#" aria-label="WhatsApp">%(wa)s</a>
          <a class="su-socb-tg" href="#" aria-label="Telegram">%(tg)s</a>
          <a class="su-socb-ig" href="#" aria-label="Instagram">%(ig)s</a>
          <a class="su-socb-yt" href="#" aria-label="YouTube">%(yt)s</a>
        </div>
        <p>Daily updates free ga — join avvandi.</p></div>
      <div><h3>Other links</h3>
        <ul class="menu">
          <li class="menu-item"><a href="#">Home</a></li>
          <li class="menu-item"><a href="#">Telangana Jobs</a></li>
          <li class="menu-item"><a href="#">AP Jobs</a></li>
          <li class="menu-item"><a href="#">Central Jobs</a></li>
          <li class="menu-item"><a href="#">Results</a></li>
          <li class="menu-item"><a href="#">Hall Tickets</a></li>
          <li class="menu-item"><a href="#">Scholarships</a></li>
        </ul>
        <ul>
          <li><a href="#">Telegram channel</a></li>
          <li><a href="#">Privacy policy</a></li>
          <li><a href="#">About us</a></li>
          <li><a href="#">Contact</a></li>
        </ul>
      </div>
    </div>
    <div class="footer-bottom"><span>© 2026 StudentUp — All rights reserved.</span></div>
  </div>
</footer>

<nav class="su-social" id="surail" aria-label="Social media">
  <button type="button" class="su-close" aria-label="Hide social icons">%(close)s</button>
  <a class="su-soc su-socb-wa" href="#" aria-label="WhatsApp">%(wa)s</a>
  <a class="su-soc su-socb-tg" href="#" aria-label="Telegram">%(tg)s</a>
  <a class="su-soc su-socb-ig" href="#" aria-label="Instagram">%(ig)s</a>
  <a class="su-soc su-socb-yt" href="#" aria-label="YouTube">%(yt)s</a>
</nav>

<div class="mbackdrop" id="mbackdrop" aria-hidden="true"></div>
<div class="mpanel" id="mpanel" role="dialog" aria-label="Site menu" aria-hidden="true">
  <div class="mpanel-head"><strong>StudentUp</strong>
    <button type="button" id="mpanelclose" aria-label="Close menu">%(close2)s</button></div>
  <div class="mlabel">Main menu</div>
  <nav class="su-mmain">%(drawer)s</nav>
  <div class="mlabel">More</div>
  <ul class="menu">
    <li class="menu-item"><a href="#">Home</a></li>
    <li class="menu-item"><a href="#">Telangana Jobs</a></li>
    <li class="menu-item"><a href="#">AP Jobs</a></li>
    <li class="menu-item"><a href="#">Central Jobs</a></li>
    <li class="menu-item"><a href="#">Results</a></li>
    <li class="menu-item"><a href="#">Hall Tickets</a></li>
    <li class="menu-item"><a href="#">Scholarships</a></li>
  </ul>
  <div class="mlabel">Social</div>
  <a class="su-msoc su-msoc-wa" href="#">%(wa2)s WhatsApp</a>
  <a class="su-msoc su-msoc-tg" href="#">%(tg2)s Telegram</a>
  <a class="su-msoc su-msoc-ig" href="#">%(ig2)s Instagram</a>
  <a class="su-msoc su-msoc-yt" href="#">%(yt2)s YouTube</a>
</div>

<script>
(function(){
  var btn=document.getElementById('menubtn'),panel=document.getElementById('mpanel'),
      close=document.getElementById('mpanelclose'),back=document.getElementById('mbackdrop');
  function open(){panel.classList.add('open');back.classList.add('open');}
  function shut(){panel.classList.remove('open');back.classList.remove('open');}
  btn&&btn.addEventListener('click',open);
  close&&close.addEventListener('click',shut);
  back&&back.addEventListener('click',shut);
})();
</script>
<script src="../../wordpress-theme/studentup/assets/js/studentup-premium.js?v=266"></script>
<script src="../../wordpress-theme/studentup/assets/js/studentup-slider.js?v=266"></script>
</body>
</html>
""" % {
    "critical": critical,
    "logo": ui["school"],
    "search": icon("search", 17),
    "menu": icon("menu", 22),
    "bolt": icon("bolt", 15),
    "board": icon("board", 15),
    "rail": "".join(rail_html),
    "news": news_html,
    "dots": dots_html,
    "trend": trend_html,
    "site": SITE,
    "used": "".join(used_html),
    "chart": icon("chart", 13), "card": icon("card", 13), "board2": icon("board", 13),
    "ticket": icon("ticket", 13), "doc": icon("doc", 13), "book": icon("book", 13),
    "moon": icon("moon", 19),
    "close": icon("close", 15), "close2": icon("close", 20),
    "wa": socicon("whatsapp"), "tg": socicon("telegram"), "ig": socicon("instagram"), "yt": socicon("youtube"),
    "wa2": socicon("whatsapp", 16), "tg2": socicon("telegram", 16),
    "ig2": socicon("instagram", 16), "yt2": socicon("youtube", 16),
    "drawer": drawer_html,
}

OUT.parent.mkdir(parents=True, exist_ok=True)
OUT.write_text(html, encoding="utf-8")
print("preview written:", OUT, len(html), "bytes")
