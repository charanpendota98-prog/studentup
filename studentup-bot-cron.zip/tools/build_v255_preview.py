#!/usr/bin/env python3
"""v255 preview builder — phone-fix design (section grid + social rail).

Emits preview/v255/index.html: the REAL theme markup (hero + 3-per-row
section grid + usedgrid + drawer + footer + social rail) wired to the REAL
theme CSS files, so the owner can open it on phone AND laptop and verify
before uploading the theme zip to WordPress.
"""
import json
import pathlib
import re

ROOT = pathlib.Path(__file__).resolve().parents[1]
THEME = ROOT / "wordpress-theme" / "studentup"
OUT = ROOT / "preview" / "v255" / "index.html"

ui = {}
for m in re.finditer(r"^\s*'([a-z-]+)'\s*=>\s*'([^']+)'",
                     (THEME / "inc" / "icons.php").read_text(encoding="utf-8"), re.M):
    ui[m.group(1)] = m.group(2)
soc = {}
src = (THEME / "inc" / "options.php").read_text(encoding="utf-8")
m = re.search(r"function studentup_social_icon_paths\(\).*?\$paths = array\((.*?)\n\t\);", src, re.S)
for k, d in re.findall(r"'([a-z]+)'\s*=>\s*'([^']+)'", m.group(1)):
    soc[k] = d


def icon(key, size=22):
    return ('<svg class="su-uicon" width="%d" height="%d" viewBox="0 0 24 24" '
            'fill="currentColor" aria-hidden="true"><path d="%s"></path></svg>'
            % (size, size, ui.get(key, ui["arrow"])))


def socicon(key, size=19):
    return ('<svg width="%d" height="%d" viewBox="0 0 24 24" fill="currentColor" '
            'aria-hidden="true"><path d="%s"></path></svg>' % (size, size, soc[key]))


SITE = "https://studentup.in"
RAIL = [
    ("bank", "TS Govt Jobs", "TSPSC · Police", SITE + "/category/ts-jobs/"),
    ("city", "AP Govt Jobs", "APPSC · DSC", SITE + "/category/ap-jobs/"),
    ("flag", "Central Jobs", "SSC · UPSC · RRB", SITE + "/category/central-jobs/"),
    ("laptop", "Software Jobs", "IT · fresher", SITE + "/category/software-jobs/"),
    ("building", "Private Jobs", "Off-campus", SITE + "/category/private-jobs/"),
    ("ticket", "Hall Tickets", "Admit cards", SITE + "/category/hall-tickets/"),
    ("award", "Results", "Marks · cutoff", SITE + "/category/results/"),
    ("bolt", "Breaking News", "Live updates", SITE + "/#jobs"),
    ("walk", "Walk-in Jobs", "This week", SITE + "/category/walkin-jobs/"),
    ("work", "Internships", "Stipend · FTE", SITE + "/category/internships/"),
    ("school", "Scholarships", "Fees · renewals", SITE + "/category/scholarships/"),
    ("trophy", "Success Stories", "Verified journeys", SITE + "/category/success-stories/"),
    ("news", "Current Affairs", "Daily GK", SITE + "/category/current-affairs/"),
]

USED = [
    ("bolt", "Breaking News", "Live flash updates", "su-used-breaking"),
    ("bank", "TS Govt Jobs", "TSPSC · Police · Gurukul", "usedcard hot"),
    ("city", "AP Govt Jobs", "APPSC · DSC · Secretariat", "usedcard hot"),
    ("flag", "Central Jobs", "SSC · UPSC · RRB · Banks", "usedcard hot"),
    ("badge", "Hall Tickets", "Admit card download", "usedcard"),
    ("award", "Results", "Marks · cutoff · answer key", "usedcard"),
    ("school", "Scholarships", "Fees · renewals · status", "usedcard"),
    ("work", "Internships", "Stipend · FTE offers", "usedcard"),
]

NOTIFS = [
    ("TS Police Constable Result 2026 Released — Check Cutoff & Marks", "Results · 2 hrs ago"),
    ("TG Gurukulam TSA Admit Card 2026 Download Hall Ticket @gurukulam", "Hall Tickets · 4 hrs ago"),
    ("UPSC NTA Exam Calendar 2027 Out — Full Schedule, 4 New Exams", "Central Jobs · today"),
    ("ICAR Internship Applications Open — Stipend Rs 10,000/mo", "Internships · today"),
]
NEWS_ICONS = ["award", "ticket", "flag", "work"]
scards = []
for i, (t, meta) in enumerate(NOTIFS):
    tag, _, when = meta.partition(" · ")
    scards.append(
        '<div class="su-scard" data-cat="blue"><div class="su-scard-head">'
        '<span class="su-scard-tag">%s</span></div>'
        '<div class="su-scard-thumb">%s</div>'
        '<h3><a href="%s">%s</a></h3>'
        '<div class="su-scard-meta"><span>%s</span></div>'
        '<div class="su-scard-acts-row"><a class="su-scard-act" href="%s">'
        '<span>Full details &amp; Apply</span><span aria-hidden="true">→</span></a></div></div>'
        % (tag, icon(NEWS_ICONS[i % 4], 36), SITE, t, when, SITE))
news_html = "".join(scards)

rail_html = []
for i, (ic, lab, hint, url) in enumerate(RAIL, 1):
    rail_html.append(
        '<a role="listitem" class="su-cat c%d" href="%s">%s<b>%s</b><small>%s</small></a>'
        % (i, url, '<span class="su-cat-ic" aria-hidden="true">%s</span>' % icon(ic, 24), lab, hint))

used_html = []
for ic, lab, hint, cls in USED:
    if cls == "su-used-breaking":
        used_html.append(
            '<a class="su-used-breaking" href="#"><span class="ui ui--breaking">%s</span>'
            '<div class="su-ub-body"><div class="su-ub-top"><span class="su-ub-tag">'
            '<span class="su-pulse-dot"></span> LIVE FLASH</span><b>Breaking News</b></div>'
            '<small>Latest notifications · hall tickets &amp; exam alerts</small></div>'
            '<em class="ucount ucount--brk">Flash Updates →</em></a>' % icon("bolt", 20))
    else:
        used_html.append(
            '<a class="%s" href="#"><span class="ui">%s</span><div><b>%s</b>'
            '<small>%s</small></div><em class="ucount">12 updates</em></a>'
            % (cls, icon(ic, 22), lab, hint))

drawer_rows = [
    ("home", "Home", ""), ("bank", "TS Govt Jobs", ""),
    ("city", "AP Govt Jobs", "APPSC · DSC · Secretariat"), ("flag", "Central Jobs", "SSC · UPSC · RRB · Banks"),
    ("walk", "Walk-in Jobs", "This week drives · venues"), ("laptop", "Software Jobs", "IT · developer · support"),
    ("building", "Private Jobs", "Off-campus · fresher drives"), ("ticket", "Hall Tickets", "Admit card download"),
    ("award", "Results", "Marks · cutoff · answer key"), ("bolt", "Breaking News", "Live verified updates"),
    ("chart", "Daily Quiz", "Fresh questions every day"),
]
drawer_html = "".join(
    '<a class="su-mmain-a%s" href="#">%s<span class="su-mmain-t">%s%s</span>%s</a>'
    % (" su-mmain-brk" if r[0] == "bolt" else "", icon(r[0], 18), r[1],
       ("<small>%s</small>" % r[2]) if r[2] else "", icon("chevron", 14))
    for r in drawer_rows)

critical = (THEME / "assets" / "css" / "critical-home.min.css").read_text(encoding="utf-8")

html = """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>StudentUp v255 — phone fix preview (open on phone &amp; laptop)</title>
<style>/* production first-paint layer (inline, exactly like WP) */
%(critical)s</style>
<link rel="stylesheet" href="../../wordpress-theme/studentup/style.min.css">
<link rel="stylesheet" href="../../wordpress-theme/studentup/assets/css/premium.min.css?v=264">
<link rel="stylesheet" href="../../wordpress-theme/studentup/assets/css/worldclass.min.css?v=264">
<link rel="stylesheet" href="../../wordpress-theme/studentup/assets/css/delight.min.css?v=264">
</head>
<body>
<header class="header">
  <div class="wrap headrow">
    <a class="logo" href="#"><svg width="30" height="30" viewBox="0 0 24 24" fill="#2563eb"><path d="%(logo)s"></path></svg>
      <span><span class="brand">Student<span style="color:var(--orange)">Up</span></span></span></a>
    <nav class="nav" aria-label="Primary"><ul class="menu-primary">
      <li class="menu-item"><a href="#">TS Govt Jobs</a></li>
      <li class="menu-item"><a href="#">AP Govt Jobs</a></li>
      <li class="menu-item"><a href="#">Central Jobs</a></li>
      <li class="menu-item"><a href="#">Hall Tickets</a></li>
      <li class="menu-item"><a href="#">Results</a></li>
    </ul></nav>
    <div class="headactions">
      <button type="button" class="iconbtn" aria-label="Search">%(search)s</button>
      <button type="button" class="iconbtn" id="menubtn" aria-label="Menu">%(menu)s</button>
    </div>
  </div>
</header>

<section class="su-hero" aria-label="StudentUp search and quick links">
  <div class="wrap su-hero-in">
    <h1 class="su-hero-title">Government Jobs, Results &amp; Notifications</h1>
    <div class="su-search-wrap">
      <form class="su-hero-search" role="search">
        <span class="su-hs-ico">%(search)s</span>
        <input id="su-q" type="search" placeholder="Search StudentUp — jobs, hall tickets, results…">
        <button type="submit">Search</button>
      </form>
    </div>

    <section class="su-catwrap is-static" aria-label="Browse by section">
      <div class="su-cathead"><b>Browse by section</b><a class="su-viewall" href="#">All sections &rarr;</a></div>
      <div class="su-catbox">
        <div class="su-catrail" role="list">%(rail)s</div>
      </div>
    </section>

    <div class="su-hero-acts">
      <a class="su-hact su-hact--breaking" href="#">%(bolt)s Breaking News</a>
      <a class="su-hact" href="#">%(board)s Latest Jobs</a>
    </div>
  </div>
</section>

<section class="usedwrap" aria-label="Most searched by students">
  <div class="wrap">
    <div class="usedhead"><b>Most searched by students</b></div>
    <div class="usedgrid">%(used)s</div>
  </div>
</section>

<section class="su-slider-sec" aria-label="Latest notifications" style="margin:22px 0">
  <div class="wrap">
    <div class="su-slider-head">
      <div class="su-slider-title-wrap">
        <span class="su-slider-badge"><i aria-hidden="true"></i> LIVE</span>
        <h2>Latest Notifications</h2>
      </div>
      <a class="su-viewall" href="%(site)s/latest-jobs/">View all &rarr;</a>
    </div>
    <div class="su-slider-viewport" tabindex="0" role="region" aria-label="Scrolling latest jobs">
      <div class="su-slider-track">%(news)s</div>
    </div>
  </div>
</section>

<section class="su-quiz" id="daily-quiz" aria-label="Daily quiz" style="margin:22px 0">
  <div class="wrap"><div class="su-quiz-card">
    <div class="su-quiz-head">
      <div><p class="su-quiz-kick">DAILY QUIZ</p><h2>Roju 5 questions — 2 minutes chaalu</h2></div>
      <div class="su-quiz-score" role="status"><b id="qscore">0</b><span>/ 3</span></div>
    </div>
    <div class="su-quiz-bar"><i id="qbar" style="width:0%%"></i></div>
    <fieldset class="su-q" data-c="1"><legend class="su-q-title"><span class="su-q-n">1</span> Quantitative Aptitude: A train 240 m long crosses a telegraph pole in 12 seconds. Speed in km/h?</legend>
      <div class="su-q-opts"><button type="button" class="su-q-opt">60 km/h</button><button type="button" class="su-q-opt">72 km/h</button><button type="button" class="su-q-opt">54 km/h</button><button type="button" class="su-q-opt">80 km/h</button></div></fieldset>
    <fieldset class="su-q" data-c="1"><legend class="su-q-title"><span class="su-q-n">2</span> Logical Reasoning: If 'PAPER' is coded as 'QBQFS', how is 'OFFICE' coded?</legend>
      <div class="su-q-opts"><button type="button" class="su-q-opt">PGGIDF</button><button type="button" class="su-q-opt">PGGJDF</button><button type="button" class="su-q-opt">NFFHBD</button><button type="button" class="su-q-opt">QHHJEG</button></div></fieldset>
    <fieldset class="su-q" data-c="0"><legend class="su-q-title"><span class="su-q-n">3</span> Indian Polity: Under which Article can a citizen approach the Supreme Court directly for enforcement of Fundamental Rights?</legend>
      <div class="su-q-opts"><button type="button" class="su-q-opt">Article 32</button><button type="button" class="su-q-opt">Article 226</button><button type="button" class="su-q-opt">Article 131</button><button type="button" class="su-q-opt">Article 143</button></div></fieldset>
  </div></div>
</section>
<script>
document.querySelectorAll(".su-q").forEach(function (q) {
  var c = +q.getAttribute("data-c");
  q.querySelectorAll(".su-q-opt").forEach(function (b, i) {
    b.addEventListener("click", function () {
      if (q.getAttribute("data-done")) return;
      q.setAttribute("data-done", "1");
      q.querySelectorAll(".su-q-opt").forEach(function (o, j) {
        if (j === c) o.classList.add("ok"); else if (j === i) o.classList.add("bad");
        o.disabled = true;
      });
      if (i === c) window.__qs = (window.__qs || 0) + 1;
      var done = document.querySelectorAll(".su-q[data-done]").length;
      document.getElementById("qscore").textContent = window.__qs || 0;
      document.getElementById("qbar").style.width = Math.round(((window.__qs || 0) / 3) * 100) + "%%";
    });
  });
});
</script>

<footer class="footer">
  <div class="wrap">
    <div class="footer-grid">
      <div><h3>StudentUp</h3><p>Jobs, scholarships, results and exam updates for students.</p></div>
      <div><h3>Categories</h3><ul>
        <li><a href="#">TS Govt Jobs</a></li><li><a href="#">AP Govt Jobs</a></li>
        <li><a href="#">Central Jobs</a></li><li><a href="#">Hall Tickets</a></li>
      </ul></div>
      <div><h3>Follow us</h3>
        <div class="su-ft-soc">
          <a class="su-socb-wa" href="#" aria-label="WhatsApp">%(wa)s</a>
          <a class="su-socb-tg" href="#" aria-label="Telegram">%(tg)s</a>
          <a class="su-socb-ig" href="#" aria-label="Instagram">%(ig)s</a>
          <a class="su-socb-yt" href="#" aria-label="YouTube">%(yt)s</a>
        </div>
        <p>Daily updates free ga — join avvandi.</p></div>
      <div><h3>Other links</h3>
        <ul class="menu">
          <li class="menu-item"><a href="#">Home</a></li>
          <li class="menu-item"><a href="#">Telangana Jobs</a></li>
          <li class="menu-item"><a href="#">AP Jobs</a></li>
          <li class="menu-item"><a href="#">Central Jobs</a></li>
          <li class="menu-item"><a href="#">Results</a></li>
          <li class="menu-item"><a href="#">Hall Tickets</a></li>
          <li class="menu-item"><a href="#">Scholarships</a></li>
        </ul>
        <ul>
          <li><a href="#">Telegram channel</a></li>
          <li><a href="#">Privacy policy</a></li>
          <li><a href="#">About us</a></li>
          <li><a href="#">Contact</a></li>
        </ul>
      </div>
    </div>
    <div class="footer-bottom"><span>© 2026 StudentUp — All rights reserved.</span></div>
  </div>
</footer>

<nav class="su-social" id="surail" aria-label="Social media">
  <button type="button" class="su-close" aria-label="Hide social icons">%(close)s</button>
  <a class="su-soc su-socb-wa" href="#" aria-label="WhatsApp">%(wa)s</a>
  <a class="su-soc su-socb-tg" href="#" aria-label="Telegram">%(tg)s</a>
  <a class="su-soc su-socb-ig" href="#" aria-label="Instagram">%(ig)s</a>
  <a class="su-soc su-socb-yt" href="#" aria-label="YouTube">%(yt)s</a>
</nav>

<div class="mbackdrop" id="mbackdrop" aria-hidden="true"></div>
<div class="mpanel" id="mpanel" role="dialog" aria-label="Site menu" aria-hidden="true">
  <div class="mpanel-head"><strong>StudentUp</strong>
    <button type="button" id="mpanelclose" aria-label="Close menu">%(close2)s</button></div>
  <div class="mlabel">Main menu</div>
  <nav class="su-mmain">%(drawer)s</nav>
  <div class="mlabel">More</div>
  <ul class="menu">
    <li class="menu-item"><a href="#">Home</a></li>
    <li class="menu-item"><a href="#">Telangana Jobs</a></li>
    <li class="menu-item"><a href="#">AP Jobs</a></li>
    <li class="menu-item"><a href="#">Central Jobs</a></li>
    <li class="menu-item"><a href="#">Results</a></li>
    <li class="menu-item"><a href="#">Hall Tickets</a></li>
    <li class="menu-item"><a href="#">Scholarships</a></li>
  </ul>
  <div class="mlabel">Social</div>
  <a class="su-msoc su-msoc-wa" href="#">%(wa2)s WhatsApp</a>
  <a class="su-msoc su-msoc-tg" href="#">%(tg2)s Telegram</a>
  <a class="su-msoc su-msoc-ig" href="#">%(ig2)s Instagram</a>
  <a class="su-msoc su-msoc-yt" href="#">%(yt2)s YouTube</a>
</div>

<script>
(function(){
  var btn=document.getElementById('menubtn'),panel=document.getElementById('mpanel'),
      close=document.getElementById('mpanelclose'),back=document.getElementById('mbackdrop');
  function open(){panel.classList.add('open');back.classList.add('open');}
  function shut(){panel.classList.remove('open');back.classList.remove('open');}
  btn&&btn.addEventListener('click',open);
  close&&close.addEventListener('click',shut);
  back&&back.addEventListener('click',shut);
})();
</script>
<script src="../../wordpress-theme/studentup/assets/js/studentup-premium.js?v=264"></script>
</body>
</html>
""" % {
    "critical": critical,
    "logo": ui["school"],
    "search": icon("search", 17),
    "menu": icon("menu", 22),
    "bolt": icon("bolt", 15),
    "board": icon("board", 15),
    "rail": "".join(rail_html),
    "news": news_html,
    "site": SITE,
    "used": "".join(used_html),
    "chart": icon("chart", 13), "card": icon("card", 13), "board2": icon("board", 13),
    "ticket": icon("ticket", 13), "doc": icon("doc", 13), "book": icon("book", 13),
    "close": icon("close", 15), "close2": icon("close", 20),
    "wa": socicon("whatsapp"), "tg": socicon("telegram"), "ig": socicon("instagram"), "yt": socicon("youtube"),
    "wa2": socicon("whatsapp", 16), "tg2": socicon("telegram", 16),
    "ig2": socicon("instagram", 16), "yt2": socicon("youtube", 16),
    "drawer": drawer_html,
}

OUT.parent.mkdir(parents=True, exist_ok=True)
OUT.write_text(html, encoding="utf-8")
print("preview written:", OUT, len(html), "bytes")
