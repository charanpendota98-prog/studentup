"""v376: de-copy pass + thin-page source filter."""
from pathlib import Path
from autoblog import sources

SRC = (Path(__file__).resolve().parents[1] / "autoblog" / "pipeline.py").read_text()


def test_thin_gallery_urls_rejected():
    assert not sources.is_valid_source_url("https://telugu.news18.com/photogallery/telangana/x-2026")
    assert not sources.is_valid_source_url("https://site.com/web-stories/abc/")
    assert sources.is_valid_source_url("https://www.tspsc.gov.in/notifications/group2.pdf")


def test_decopy_pass_runs_before_gate():
    i_decopy = SRC.index("v376 DE-COPY PASS")
    i_gate = SRC.index('"COPY-RISK",\n                f"originality=')
    assert i_decopy < i_gate
    body = SRC[i_decopy:i_gate]
    assert "refine_article(article, decopy" in body
    assert "len(ov2) <= len(overlaps) and or2 >= originality" in body
