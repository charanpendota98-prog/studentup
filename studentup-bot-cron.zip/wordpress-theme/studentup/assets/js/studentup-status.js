/* v282 — Quiz → WhatsApp Status share card.
   Flow: finish quiz → "Share your score to WhatsApp Status" → ask name once (saved) →
   canvas score card (1080×1920, status ratio) with "Hey <name>! You scored X/Y" + quiz link →
   phone: navigator.share({files}) → WhatsApp → "My status". Fallback: wa.me text + Download card.
   No personal data leaves the device (name = localStorage only). GA4: quiz_status_share. */
(function () {
  "use strict";
  var KEY = "su_quiz_name";
  function esc(s) { return String(s).replace(/[&<>"]/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]; }); }
  function ev(name, p) { try { if (window.gtag) gtag("event", name, p || {}); } catch (e) {} }
  function savedName() { try { return (localStorage.getItem(KEY) || "").trim(); } catch (e) { return ""; } }
  function saveName(n) { try { localStorage.setItem(KEY, n); } catch (e) {} }
  function title(pct) { return pct >= 100 ? "Topper 🏆" : pct >= 80 ? "Champion ⭐" : pct >= 60 ? "Rising Star 🚀" : pct >= 40 ? "Good Start 💪" : "Warming Up 🔥"; }
  function roundRect(c, x, y, w, h, r) { c.beginPath(); c.moveTo(x + r, y); c.arcTo(x + w, y, x + w, y + h, r); c.arcTo(x + w, y + h, x, y + h, r); c.arcTo(x, y + h, x, y, r); c.arcTo(x, y, x + w, y, r); c.closePath(); }
  function fitText(c, t, maxW, start, min) { var s = start; do { c.font = "800 " + s + "px system-ui, -apple-system, Segoe UI, Roboto, sans-serif"; if (c.measureText(t).width <= maxW) break; s -= 4; } while (s > min); return s; }

  function drawCard(o) {
    var W = 1080, H = 1920, cv = document.createElement("canvas"); cv.width = W; cv.height = H;
    var c = cv.getContext("2d"), pct = Math.round((o.score / o.total) * 100);
    var g = c.createLinearGradient(0, 0, W, H); g.addColorStop(0, "#1e1b4b"); g.addColorStop(.55, "#4f46e5"); g.addColorStop(1, "#06b6d4");
    c.fillStyle = g; c.fillRect(0, 0, W, H);
    // soft glow orbs
    c.globalAlpha = .18; c.fillStyle = "#fff";
    c.beginPath(); c.arc(140, 300, 260, 0, 7); c.fill(); c.beginPath(); c.arc(980, 1600, 320, 0, 7); c.fill(); c.globalAlpha = 1;
    // brand
    c.fillStyle = "rgba(255,255,255,.92)"; c.textAlign = "center"; c.textBaseline = "middle";
    c.font = "900 54px system-ui, -apple-system, Segoe UI, Roboto, sans-serif"; c.fillText("StudentUp", W / 2, 230);
    c.font = "700 34px system-ui, sans-serif"; c.fillStyle = "rgba(255,255,255,.72)"; c.fillText("DAILY QUIZ  ·  " + o.date, W / 2, 292);
    // card
    roundRect(c, 90, 420, W - 180, 1040, 56); c.fillStyle = "rgba(255,255,255,.96)"; c.shadowColor = "rgba(0,0,0,.28)"; c.shadowBlur = 60; c.shadowOffsetY = 24; c.fill(); c.shadowColor = "transparent";
    // greeting
    c.fillStyle = "#0f172a"; var hey = "Hey " + o.name + "! 👋"; fitText(c, hey, W - 300, 66, 40); c.fillText(hey, W / 2, 545);
    c.font = "700 40px system-ui, sans-serif"; c.fillStyle = "#475569"; c.fillText("Your score today", W / 2, 625);
    // ring
    var cx = W / 2, cy = 880, R = 185;
    c.lineWidth = 34; c.lineCap = "round"; c.strokeStyle = "#e2e8f0"; c.beginPath(); c.arc(cx, cy, R, 0, Math.PI * 2); c.stroke();
    var rg = c.createLinearGradient(cx - R, cy, cx + R, cy); rg.addColorStop(0, "#22c55e"); rg.addColorStop(1, "#06b6d4");
    c.strokeStyle = rg; c.beginPath(); c.arc(cx, cy, R, -Math.PI / 2, -Math.PI / 2 + Math.PI * 2 * (o.score / o.total)); c.stroke();
    c.fillStyle = "#0f172a"; c.font = "900 150px system-ui, sans-serif"; c.fillText(o.score + "/" + o.total, cx, cy - 10);
    c.font = "800 44px system-ui, sans-serif"; c.fillStyle = "#16a34a"; c.fillText(pct + "%", cx, cy + 95);
    // title pill
    var t = title(pct); c.font = "800 46px system-ui, sans-serif"; var tw = c.measureText(t).width + 90;
    roundRect(c, cx - tw / 2, 1120, tw, 92, 46); c.fillStyle = "#eef2ff"; c.fill(); c.fillStyle = "#4338ca"; c.fillText(t, cx, 1168);
    // challenge
    c.fillStyle = "#0f172a"; c.font = "800 50px system-ui, sans-serif"; c.fillText("Can you beat my score? 🎯", cx, 1300);
    c.fillStyle = "#475569"; c.font = "700 36px system-ui, sans-serif"; c.fillText("5 easy reasoning & aptitude questions · 2 minutes", cx, 1365);
    // link button
    roundRect(c, 190, 1540, W - 380, 118, 59); var bg = c.createLinearGradient(190, 0, W - 190, 0); bg.addColorStop(0, "#22c55e"); bg.addColorStop(1, "#16a34a");
    c.fillStyle = bg; c.shadowColor = "rgba(0,0,0,.3)"; c.shadowBlur = 30; c.shadowOffsetY = 12; c.fill(); c.shadowColor = "transparent";
    c.fillStyle = "#fff"; c.font = "900 44px system-ui, sans-serif"; c.fillText("▶  Play now · " + o.linkShort, cx, 1600);
    c.fillStyle = "rgba(255,255,255,.75)"; c.font = "700 32px system-ui, sans-serif"; c.fillText("New quiz every day  ·  TS & AP students", cx, 1740);
    return cv;
  }

  function message(o) {
    return "🎯 Hey, I'm " + o.name + " — I scored " + o.score + "/" + o.total + " (" + Math.round((o.score / o.total) * 100) + "%) on today's StudentUp Daily Quiz!\n" +
      title(Math.round((o.score / o.total) * 100)) + "\n\nCan you beat me? Play now 👉 " + o.link;
  }

  function mount(o) {
    var host = o.mount; if (!host || host.querySelector(".su-status")) return;
    var box = document.createElement("div"); box.className = "su-status";
    var name = o.name || savedName();
    box.innerHTML =
      '<button type="button" class="su-status-btn"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 0 1-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 0 1-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 0 1 2.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0 0 12.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 0 0 5.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 0 0-3.48-8.413Z"/></svg><span>Share your score to WhatsApp Status</span></button>' +
      '<form class="su-status-name" hidden><input type="text" maxlength="24" autocomplete="given-name" inputmode="text" placeholder="Your name" aria-label="Your name" required><button type="submit">Create my card →</button></form>' +
      '<div class="su-status-out" hidden><img alt="Your StudentUp quiz score card" decoding="async"><div class="su-status-acts">' +
      '<button type="button" class="su-status-post">Post to Status</button>' +
      '<a class="su-status-wa" target="_blank" rel="noopener">Send on WhatsApp</a>' +
      '<a class="su-status-dl" download="studentup-quiz-score.png">Download card</a>' +
      '<button type="button" class="su-status-edit" aria-label="Change name">✎</button></div></div>';
    host.appendChild(box);
    var btn = box.querySelector(".su-status-btn"), form = box.querySelector(".su-status-name"), inp = form.querySelector("input"),
        out = box.querySelector(".su-status-out"), img = out.querySelector("img"), post = out.querySelector(".su-status-post"),
        wa = out.querySelector(".su-status-wa"), dl = out.querySelector(".su-status-dl"), edit = out.querySelector(".su-status-edit");
    var blob = null, cur = null;

    function build(n) {
      cur = { name: n, score: o.score, total: o.total, link: o.link, linkShort: o.link.replace(/^https?:\/\//, "").replace(/\/$/, ""), date: o.date || new Date().toLocaleDateString("en-IN", { day: "numeric", month: "short" }) };
      var cv = drawCard(cur), url = cv.toDataURL("image/png");
      img.src = url; dl.href = url; wa.href = "https://wa.me/?text=" + encodeURIComponent(message(cur));
      blob = null; if (cv.toBlob) cv.toBlob(function (b) { blob = b; }, "image/png");
      form.hidden = true; btn.hidden = true; out.hidden = false;
      var canFiles = !!(navigator.canShare && window.File); post.hidden = !navigator.share;
      post.textContent = canFiles ? "Post to Status" : "Share";
      ev("quiz_status_card", { score: o.score, total: o.total });
      try { out.scrollIntoView({ behavior: "smooth", block: "nearest" }); } catch (e) {}
    }
    btn.addEventListener("click", function () {
      if (name) { build(name); return; }
      form.hidden = false; btn.hidden = true; try { inp.focus(); } catch (e) {}
    });
    form.addEventListener("submit", function (e) {
      e.preventDefault(); var n = inp.value.replace(/\s+/g, " ").trim(); if (!n) { inp.focus(); return; }
      n = n.charAt(0).toUpperCase() + n.slice(1); name = n; saveName(n); build(n);
    });
    edit.addEventListener("click", function () { out.hidden = true; form.hidden = false; inp.value = name; inp.focus(); });
    post.addEventListener("click", function () {
      var data = { title: "StudentUp Daily Quiz", text: message(cur) };
      try {
        if (blob && navigator.canShare && window.File) {
          var f = new File([blob], "studentup-quiz-score.png", { type: "image/png" });
          if (navigator.canShare({ files: [f] })) data = { files: [f], title: data.title, text: data.text };
        }
      } catch (e) {}
      ev("quiz_status_share", { method: data.files ? "native_image" : "native_text" });
      if (navigator.share) navigator.share(data).catch(function () {}); else window.open(wa.href, "_blank", "noopener");
    });
    wa.addEventListener("click", function () { ev("quiz_status_share", { method: "whatsapp_text" }); });
    dl.addEventListener("click", function () { ev("quiz_status_share", { method: "download" }); });
  }
  window.suStatusShare = mount;
})();
