"""Configuration loader for the studentup.in auto-blogger.

Reads settings from a .env file in the project root (see .env.example)
with sensible defaults. Every value can be overridden via environment
variables too.
"""

import os
import re
from pathlib import Path
from typing import List

BASE_DIR = Path(__file__).resolve().parent.parent


def _strip_inline_comment(value: str) -> str:
    """Return the real value of a quoted/unquoted .env entry.

    dotenv semantics, so `.env.example` lines such as
    `RADAR_INTERVAL_HOURS=6   # roju 4x scan` no longer reach `int()`
    verbatim (that used to kill the whole config import):

    * quoted value -> text between the quotes, anything after is a comment
    * unquoted     -> cut at the first `#` that starts the value or is
      preceded by whitespace, so `https://x.in/page#top` survives
    """
    value = value.strip()
    if value[:1] in ('"', "'"):
        quote = value[0]
        end = value.find(quote, 1)
        return value[1:end] if end != -1 else value[1:].strip()
    match = re.search(r"(?:^|\s)#", value)
    return value[: match.start()].rstrip() if match else value


def _load_env_file(path: Path) -> None:
    """Tiny .env parser (no external dependency needed)."""
    if not path.exists():
        return
    for raw in path.read_text(encoding="utf-8").splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, value = line.partition("=")
        os.environ.setdefault(key.strip(), _strip_inline_comment(value))


_load_env_file(BASE_DIR / ".env")


def _get(name: str, default: str = "") -> str:
    return os.environ.get(name, default)


# --- WordPress -----------------------------------------------------------
WP_SITE = _get("WP_SITE", "https://studentup.in").rstrip("/")
WP_USERNAME = _get("WP_USERNAME", "")
WP_APP_PASSWORD = _get("WP_APP_PASSWORD", "")

# "draft" = review flow (Telegram lo approve cheyandi tarvata publish).
# "publish" = posts direct ga live avtavvi.
DEFAULT_POST_STATUS = _get("DEFAULT_POST_STATUS", "draft")

# --- v197 AUTO-PUBLISH LANE -------------------------------------------------
# "daily ga draft chesi post chesthu vundali" — kaani **gate tho mattrame**.
# 0 = drafts ne untayi (owner WordPress lo publish chestadu).
# 1 = evening lane gate-passed drafts ni automatic ga publish chestundi
#     (source URL + 700 words + Rank Math >= 80 + fresh + no placeholders).
AUTO_PUBLISH_DAILY = _get("AUTO_PUBLISH_DAILY", "0")
AUTO_PUBLISH_MIN_SCORE = _get("AUTO_PUBLISH_MIN_SCORE", "80")
AUTO_PUBLISH_MIN_WORDS = _get("AUTO_PUBLISH_MIN_WORDS", "700")
AUTO_PUBLISH_MAX = _get("AUTO_PUBLISH_MAX", "3")
AUTO_PUBLISH_MAX_AGE_DAYS = _get("AUTO_PUBLISH_MAX_AGE_DAYS", "1")
# Daily quiz + poll push (theme options) — "quiz polls daily advanced ga"
DAILY_ENGAGE = _get("DAILY_ENGAGE", "1")
# Automated discovery/research always creates a review draft. Publishing is a
# separate owner action in WordPress; changing DEFAULT_POST_STATUS alone cannot
# accidentally bypass this protection.
AUTOMATION_DRAFT_ONLY = _get("AUTOMATION_DRAFT_ONLY", "1") not in ("0", "false", "no")

# --- Notifications -------------------------------------------------------
TELEGRAM_BOT_TOKEN = _get("TELEGRAM_BOT_TOKEN", "")
TELEGRAM_CHAT_ID = _get("TELEGRAM_CHAT_ID", "")  # empty = /start <TELEGRAM_SETUP_TOKEN> required (v401d)
# v401d (audit S-1): ownership is never granted to "whoever messages first".
# With TELEGRAM_CHAT_ID empty, the owner must send `/start <token>` where
# token == TELEGRAM_SETUP_TOKEN; anything else is ignored.
TELEGRAM_SETUP_TOKEN = _get("TELEGRAM_SETUP_TOKEN", "")
# Publish ayyaka auto-post to mi Telegram CHANNEL (optional — channel chat id,
# example -1001234... ; channel lo bot admin ga add cheyandi)
TELEGRAM_CHANNEL_CHAT_ID = _get("TELEGRAM_CHANNEL_CHAT_ID", "")
TELEGRAM_API_BASE = _get("TELEGRAM_API_BASE", "https://api.telegram.org")
# Daily forward-ready list: owner chat only, never auto-published to the
# public channel. The live WordPress board itself updates on every request.
OPPORTUNITY_DIGEST_ENABLED = _get("OPPORTUNITY_DIGEST_ENABLED", "1") not in ("0", "false", "no")
OPPORTUNITY_DIGEST_HOUR = int(_get("OPPORTUNITY_DIGEST_HOUR", "8") or 8)
OPPORTUNITY_DIGEST_PER_SECTION = int(_get("OPPORTUNITY_DIGEST_PER_SECTION", "6") or 6)
# Optional Bitly/Short.io/is.gd adapter for owner-forwarded StudentUp links.
# Disabled by default until the owner configures a provider. Failure always
# falls back to a native StudentUp link; no dead short link is ever sent.
SHORTLINK_ENABLED = _get("SHORTLINK_ENABLED", "0") not in ("0", "false", "no")
SHORTLINK_PROVIDER = _get("SHORTLINK_PROVIDER", "wordpress").strip().lower()
SHORTLINK_API_TOKEN = _get("SHORTLINK_API_TOKEN", "").strip()
SHORTLINK_DOMAIN = _get("SHORTLINK_DOMAIN", "").strip()
SHORTLINK_TIMEOUT = int(_get("SHORTLINK_TIMEOUT", "12") or 12)
SHORTLINK_CACHE = Path(_get("SHORTLINK_CACHE", str(BASE_DIR / "logs" / "shortlinks.json")))
# IndexNow instant indexing (Bing/Yandex) — key file site root lo host cheyandi
INDEXNOW_KEY = _get("INDEXNOW_KEY", "")
# Upload ayyaka local featured image file ni delete (disk full avvakunda)
KEEP_IMAGES = _get("KEEP_IMAGES", "0") not in ("0", "false", "no")
# Scheduler watchdog: itne hours run ledu ante Telegram lo alert
WATCHDOG_HOURS = int(_get("WATCHDOG_HOURS", "26"))
# Quality-first publishing: fewer, source-backed drafts beat scaled thin pages.
# These are draft slots by default; a human still decides what becomes public.
LISTICLES_PER_DAY = int(_get("LISTICLES_PER_DAY", "1"))
# Daily auto-refresh: prathi roju intha purana posts ni refresh chestundi
AUTO_REFRESH_PER_DAY = int(_get("AUTO_REFRESH_PER_DAY", "1"))
AUTO_REFRESH_MIN_AGE_DAYS = int(_get("AUTO_REFRESH_MIN_AGE_DAYS", "30"))
AUTO_REFRESH_HOUR = int(_get("AUTO_REFRESH_HOUR", "21"))
# Same official source → refresh the existing post in place, not a duplicate.
# A failed lookup never deletes the incoming source; normal draft generation
# remains the safe fallback.
AUTO_UPDATE_SAME_SOURCE = _get("AUTO_UPDATE_SAME_SOURCE", "1") not in ("0", "false", "no")
# v101 DECEPTIVE-FRESHNESS GUARD (Google Aug-2026 spam update).
# Refresh lo content ee % kanna takkuva marithe dateModified bump KAADU —
# "dateModified bumped with no real change" = named spam signal.
FRESHNESS_MIN_CHANGE_PCT = float(_get("FRESHNESS_MIN_CHANGE_PCT", "8"))
# Ee % kanna takkuva marithe WP write motham skip (pointless revision).
FRESHNESS_MIN_PUBLISH_PCT = float(_get("FRESHNESS_MIN_PUBLISH_PCT", "2"))
# In-content ad shortcode (site lo ad plugin active unte; empty = off)
# Example: AD_SHORTCODE=[quads id=1]  or  [advanced_ads_severities]
AD_SHORTCODE = _get("AD_SHORTCODE", "")
# Page ki intha ad slots (3 default; long articles ki 4-5 news standard)
MAX_AD_SLOTS = int(_get("MAX_AD_SLOTS", "3"))
# Ad space min-height tho reserve (CLS/layout-shift radu — CWV + viewability)
AD_CLS_WRAPPER = _get("AD_CLS_WRAPPER", "1") not in ("0", "false", "no")
# v43 AD MANAGER — owner ads (college banners, shop, services). Inventory:
# ads/inventory.json (repo lo). Empty/missing inventory = no-op (safe).
# ADSENSE_APPROVED=1 unte personal ad cap auto 1 ki drop avtundi (AdSense safe).
# v340: promo/ad blocks are rendered by the theme (ONE house box at the end).
# Baking them into post_content made every post carry 3 "SPONSORED" boxes forever.
AD_MANAGER_ENABLED = _get("AD_MANAGER_ENABLED", "0") not in ("0", "false", "no")
# Post lo max personal ad slots (AdSense slots ki separate — ee varam matrame)
MAX_PERSONAL_AD_SLOTS = int(_get("MAX_PERSONAL_AD_SLOTS", "2"))
# v48: category match lekapoyina okka ad slot miss avvakunda fallback (round-robin).
# AD_FALLBACK_ALWAYS=0 → peddaga strict: category match unte ne ad vestundi.
AD_FALLBACK_ALWAYS = _get("AD_FALLBACK_ALWAYS", "0") not in ("0", "false", "no")  # v322: strict
# Inventory path override (default: repo ads/inventory.json)
ADS_INVENTORY_PATH = _get("ADS_INVENTORY_PATH", "")
# v52: house ads — StudentUp sonta promos. Sponsor ad lekapoyinappudu slot
# khali ga undakunda ivi rotation lo vastayi (SPONSORED label veyyamu).
# v322: default OFF — theme already renders house/AdSense slots; bot-side blocks
# duplicated them inside the article (2x quiz box, 4 promos per post).
HOUSE_AD_ENABLED = _get("HOUSE_AD_ENABLED", "0") not in ("0", "false", "no")
HOUSE_ADS_PATH = _get("HOUSE_ADS_PATH", "")
# --- v57: ad advisor (network eligibility ni automatic ga track + suggest) ---
AD_ADVISOR_ENABLED = _get("AD_ADVISOR_ENABLED", "1") not in ("0", "false", "no")
AD_ADVISOR_HOUR = int(_get("AD_ADVISOR_HOUR", "10") or 10)
AD_TRAFFIC_PATH = _get("AD_TRAFFIC_PATH", str(BASE_DIR / "logs" / "traffic.json"))
AD_ADVISOR_STATE = _get("AD_ADVISOR_STATE", str(BASE_DIR / "logs" / "ad_advisor_state.json"))
AD_MONTHLY_VIEWS = int(_get("AD_MONTHLY_VIEWS", "0") or 0)
AD_MONTHLY_SESSIONS = int(_get("AD_MONTHLY_SESSIONS", "0") or 0)
AD_TIER1_SHARE = float(_get("AD_TIER1_SHARE", "0") or 0)
HOUSE_ADS_PATH = _get("HOUSE_ADS_PATH", "")
# v44 DEEP POST ENGINE — deep analyse + cross-source verification.
# ≥ DEEP_MIN_SOURCES sources unna posts ki "In-Depth Analysis" section +
# perfect gate (conflicts/stale dates live publish lo block; drafts lo flags).
DEEP_POST_ENABLED = _get("DEEP_POST_ENABLED", "1") not in ("0", "false", "no")
DEEP_MIN_SOURCES = int(_get("DEEP_MIN_SOURCES", "2"))
# v217 ADVANCED SOURCING: okka site nunchi copy kaakunda, **independent
# domains** nunchi cross-verify chesi ne rayali. 2 pages okate domain
# (example.com/a + example.com/b) = 1 domain ga counting.
DEEP_MIN_DOMAINS = int(_get("DEEP_MIN_DOMAINS", "2"))
# Live publish ki minimum deep-research confidence (0-100).
DEEP_MIN_CONFIDENCE = int(_get("DEEP_MIN_CONFIDENCE", "60"))
# 0 = deep gate off (drafts + live rendu lo ledu)
DEEP_GATE_STRICT = _get("DEEP_GATE_STRICT", "1") not in ("0", "false", "no")
# Source-derived live posts: independent evidence + at least one official source.
SOURCE_REQUIRED_ALL = _get("SOURCE_REQUIRED_ALL", "1") not in ("0", "false", "no")
# Scheduled bot waits for a source-backed candidate instead of inventing a topic.
AUTO_SOURCE_ONLY = _get("AUTO_SOURCE_ONLY", "1") not in ("0", "false", "no")
# v316: source lekapoina plan slot ki review DRAFT rayali (publish eppudu kaadu).
AUTO_DRAFT_FALLBACK = _get("AUTO_DRAFT_FALLBACK", "1") not in ("0", "false", "no")
SOURCE_MIN_LIVE = int(_get("SOURCE_MIN_LIVE", "3"))
SOURCE_MIN_OFFICIAL = int(_get("SOURCE_MIN_OFFICIAL", "1"))
SOURCE_CONFIDENCE_MIN = int(_get("SOURCE_CONFIDENCE_MIN", "65"))
SOURCE_AUDIT_BLOCK = _get("SOURCE_AUDIT_BLOCK", "1") not in ("0", "false", "no")
# Source-derived posts are not even saved as drafts until the fetched source
# set, official evidence, numeric/date facts and claim ledger pass preflight.
SOURCE_PREFLIGHT_REQUIRED = _get("SOURCE_PREFLIGHT_REQUIRED", "1") not in ("0", "false", "no")
# v319: gates block LIVE publish only; for review DRAFTS they become ⚠️ warnings
# on the Telegram card (owner decides). Set 0 to restore block-before-draft.
GATE_DRAFT_WARN_ONLY = _get("GATE_DRAFT_WARN_ONLY", "1") not in ("0", "false", "no")
# v319: extra owner chats (comma separated) besides TELEGRAM_CHAT_ID — e.g. DM + group
TELEGRAM_ADMIN_IDS = [x.strip() for x in _get("TELEGRAM_ADMIN_IDS", "").split(",") if x.strip()]
# Read-only official-source freshness monitor. It alerts the owner when a
# source-backed published post's source text changes; it never auto-edits copy.
SOURCE_MONITOR_ENABLED = _get("SOURCE_MONITOR_ENABLED", "1") not in ("0", "false", "no")
SOURCE_MONITOR_MAX_POSTS = int(_get("SOURCE_MONITOR_MAX_POSTS", "120"))
SOURCE_MONITOR_HOUR = int(_get("SOURCE_MONITOR_HOUR", "6") or 6)
SOURCE_MONITOR_STATE = Path(_get("SOURCE_MONITOR_STATE", str(BASE_DIR / "logs" / "source-monitor.json")))
# Published opportunity lifecycle checks. This is a bounded, read-only review
# queue: dead links, redirects, PDF/HTML replacements and expiry are never
# silently written back to WordPress.
OPPORTUNITY_MONITOR_ENABLED = _get("OPPORTUNITY_MONITOR_ENABLED", "1") not in ("0", "false", "no")
OPPORTUNITY_MONITOR_MAX_POSTS = int(_get("OPPORTUNITY_MONITOR_MAX_POSTS", "180"))
OPPORTUNITY_MONITOR_HOUR = int(_get("OPPORTUNITY_MONITOR_HOUR", "6") or 6)
OPPORTUNITY_MONITOR_NEAR_DAYS = int(_get("OPPORTUNITY_MONITOR_NEAR_DAYS", "3") or 3)
OPPORTUNITY_MONITOR_STATE = Path(_get("OPPORTUNITY_MONITOR_STATE", str(BASE_DIR / "logs" / "opportunity-monitor.json")))
# Repetition/filler audit is separate from Rank Math and blocks low-value prose.
CONTENT_QUALITY_BLOCK = _get("CONTENT_QUALITY_BLOCK", "1") not in ("0", "false", "no")
# Public posts should read like StudentUp's own editorial work. Provenance,
# source hashes and review diagnostics remain in the private ledger, but
# automation/source-count boilerplate is not inserted into reader-facing copy.
# Set PUBLIC_EDITORIAL_CLEAN=0 only for an internal audit/debug export.
PUBLIC_EDITORIAL_CLEAN = _get("PUBLIC_EDITORIAL_CLEAN", "1") not in ("0", "false", "no")
# E-E-A-T: Article schema publisher logo (rich results kosam; optional)
SITE_LOGO_URL = _get("SITE_LOGO_URL", "")
# Google Discover: per-post robots lo max-image-preview:large (RM meta)
DISCOVER_META_ENABLED = _get("DISCOVER_META_ENABLED", "1") not in ("0", "false", "no")
# Google Trends daily RSS nunchi trending education topics (India)
USE_TRENDS = _get("USE_TRENDS", "1") not in ("0", "false", "no")
TRENDS_RSS = _get("TRENDS_RSS", "https://trends.google.com/trending/trendingsearches/daily/rss?geo=IN")
# Revenue: prathi post end lo Telegram channel CTA (repeat traffic engine)
TELEGRAM_CHANNEL_URL = _get("TELEGRAM_CHANNEL_URL", "")
# Affiliate links: 'label|url|keywords' okka line okati (empty = off)
# keywords optional — post title/category match aithe matrame vastundi
# Example: Free Resume Builder|https://example.com/?ref=studentup|internship,job
AFFILIATE_LINKS = _get("AFFILIATE_LINKS", "")
# High-CPC content: roju intha posts high-CPC topics meeda (30% default)
HIGH_CPC_SHARE = int(_get("HIGH_CPC_SHARE", "30"))
# CallMeBot free WhatsApp alerts (text only):
# https://api.callmebot.com/whatsapp.php?phone=+91XXXX&apikey=XXXX
WHATSAPP_CALLMEBOT_URL = _get("WHATSAPP_CALLMEBOT_URL", "")

# --- v15: District Breaking-News Radar + Channel Watch -------------------
RADAR_ENABLED = _get("RADAR_ENABLED", "1") not in ("0", "false", "no")
RADAR_HOUR = int(_get("RADAR_HOUR", "7"))               # first radar slot (IST)
RADAR_INTERVAL_HOURS = int(_get("RADAR_INTERVAL_HOURS", "6"))  # 4x/day scan
RADAR_DISTRICTS_PER_RUN = int(_get("RADAR_DISTRICTS_PER_RUN", "15"))  # v321
RADAR_SOURCES_PER_RUN = int(_get("RADAR_SOURCES_PER_RUN", "20"))  # v321: wider sweep
# Strictly source-backed review drafts per radar day. Increase from the old
# 2-post cap so discovered job opportunities are not silently left unprepared;
# the evidence/preflight gates still block unsupported or stale notices.
RADAR_POSTS_PER_DAY = int(_get("RADAR_POSTS_PER_DAY", "24"))  # v375
# v320: every hourly run (ACTIVE hours) drains the verified-source queue into
# review drafts — not only the 3-5 plan slots. Backlog never piles up.
QUEUE_DRAIN_PER_HOUR = int(_get("QUEUE_DRAIN_PER_HOUR", "3"))
# v375 fast lane (`run.py --fast-drain`, cron */10): drafts per 10-min run + watch refresh cadence
FAST_DRAIN_PER_RUN = int(_get("FAST_DRAIN_PER_RUN", "2"))
FAST_WATCH_MINUTES = int(_get("FAST_WATCH_MINUTES", "30"))
# v381: direct watch list is ~65 URLs; each sweep scans a rotating slice so a
# slow .gov.in page never blocks the 10-minute fast lane. Full list covered
# every ~4 sweeps (~2 hours).
WATCH_PER_SWEEP = int(_get("WATCH_PER_SWEEP", "24"))  # v402: 83 URLs, conditional GET makes unchanged pages ~free
# v383: stale source gate — expired events never become drafts.
STALE_GATE_ENABLED = _get("STALE_GATE_ENABLED", "1") not in ("0", "false", "no")
SOURCE_MAX_AGE_DAYS = int(_get("SOURCE_MAX_AGE_DAYS", "21"))      # news desks
OFFICIAL_MAX_AGE_DAYS = int(_get("OFFICIAL_MAX_AGE_DAYS", "60"))  # *.gov.in notices
EVENT_GRACE_DAYS = int(_get("EVENT_GRACE_DAYS", "2"))
WATCH_FETCH_TIMEOUT = int(_get("WATCH_FETCH_TIMEOUT", "12"))
QUEUE_DRAFTS_PER_DAY = int(_get("QUEUE_DRAFTS_PER_DAY", "60"))  # v375: fast lane
# v354: breaking items (radar sweep) → immediate original-rewrite WP DRAFTS
BREAKING_DRAFTS_ENABLED = _get("BREAKING_DRAFTS_ENABLED", "1") not in ("0", "false", "no")
BREAKING_DRAFTS_PER_SWEEP = int(_get("BREAKING_DRAFTS_PER_SWEEP", "3"))
BREAKING_DRAFTS_PER_DAY = int(_get("BREAKING_DRAFTS_PER_DAY", "12"))

# v59: site బ్రేకింగ్ న్యూస్ feed (radar → preview/data/breaking.json → ticker)
BREAKING_ENABLED = _get("BREAKING_ENABLED", "1") not in ("0", "false", "no")
BREAKING_MAX = int(_get("BREAKING_MAX", "8"))
BREAKING_KEEP_HOURS = float(_get("BREAKING_KEEP_HOURS", "18"))

# v60: SITE GUARDIAN — roju okkasari system motham check + Telegram alert
GUARDIAN_ENABLED = _get("GUARDIAN_ENABLED", "1") not in ("0", "false", "no")
GUARDIAN_HOUR = int(_get("GUARDIAN_HOUR", "20"))          # IST — raatri report
GUARDIAN_STATE = Path(_get("GUARDIAN_STATE", str(BASE_DIR / "logs" / "guardian.json")))
GUARDIAN_FEED_MAX_AGE = float(_get("GUARDIAN_FEED_MAX_AGE", "26"))  # breaking feed staleness (h)
BREAKING_FEED_PATH = Path(_get(
    "BREAKING_FEED_PATH", str(BASE_DIR / "preview" / "data" / "breaking.json")))
# comma-separated: https://t.me/s/yourchannel,https://site.com/feed
WATCH_SOURCES = _get("WATCH_SOURCES", "")
# v373: built-in DIRECT watch list (official boards + education desks) so the
# auto lane does not depend on Google News alone. Covers every site section:
# TS/AP state jobs, central jobs, results, hall tickets, admissions,
# scholarships. Owner's WATCH_SOURCES are merged on top; set
# OFFICIAL_WATCH_BUILTIN=0 to disable the built-ins.
OFFICIAL_WATCH_BUILTIN = _get("OFFICIAL_WATCH_BUILTIN", "1") not in ("0", "false", "no")
OFFICIAL_WATCH_DEFAULT = [
    # --- Telangana ---
    "https://www.tspsc.gov.in/",                      # TSPSC notifications
    "https://www.tgpsc.gov.in/",                      # renamed portal
    "https://bse.telangana.gov.in/",                  # SSC board results/hall tickets
    "https://tgbie.cgg.gov.in/",                      # Inter board
    "https://telanganaepass.cgg.gov.in/",             # ePASS scholarships
    "https://schooledu.telangana.gov.in/",            # DSC / school edu
    "https://www.tslprb.in/",                         # police recruitment
    # --- Andhra Pradesh ---
    "https://psc.ap.gov.in/",                         # APPSC
    "https://www.bse.ap.gov.in/",                     # SSC board
    "https://bie.ap.gov.in/",                         # Inter board
    "https://jnanabhumi.ap.gov.in/",                  # scholarships
    "https://apdsc.apcfss.in/",                       # DSC
    "https://slprb.ap.gov.in/",                       # police
    "https://cets.apsche.ap.gov.in/",                 # EAPCET etc.
    # --- Central ---
    "https://ssc.gov.in/",
    "https://upsc.gov.in/whats-new",
    "https://www.rrbcdg.gov.in/",
    "https://www.ibps.in/",
    "https://sbi.co.in/web/careers/current-openings",
    "https://scholarships.gov.in/",
    "https://www.nta.ac.in/",
    "https://joinindianarmy.nic.in/",
    # --- v381: more official boards (owner: TS + AP + Central ANNI kavali) ---
    # Telangana
    "https://www.scclmines.com/",                     # Singareni (SCCL) jobs
    "https://mhsrb.telangana.gov.in/",                # TS Medical & Health recruitment board
    "https://tshc.gov.in/",                           # TS High Court recruitment
    "https://www.tsrtc.telangana.gov.in/",            # TSRTC
    "https://tgtransco.cgg.gov.in/",                  # TGTRANSCO
    "https://www.tgnpdcl.in/",                        # NPDCL
    "https://tgcet.cgg.gov.in/",                      # TG CET / Gurukul
    # Andhra Pradesh
    "https://aphc.gov.in/",                           # AP High Court
    "https://gramawardsachivalayam.ap.gov.in/",       # AP Grama/Ward Sachivalayam
    "https://apsrtc.ap.gov.in/",                      # APSRTC
    "https://apgenco.gov.in/",                        # APGENCO
    "https://apsche.ap.gov.in/",                      # APSCHE (CETs, SET)
    "https://aptet.apcfss.in/",                       # APTET
    "https://apmsrb.ap.gov.in/",                      # AP Medical Services Recruitment Board
    # Central (Hyderabad/AP-heavy employers + national boards)
    "https://www.rrbapply.gov.in/",                   # RRB central apply portal
    "https://www.indiapost.gov.in/",                  # India Post / GDS
    "https://indiapostgdsonline.gov.in/",
    "https://www.ecil.co.in/",                        # ECIL Hyderabad
    "https://bdl-india.in/",                          # BDL Hyderabad
    "https://www.isro.gov.in/Careers.html",           # ISRO
    "https://rac.gov.in/",                            # DRDO RAC
    "https://www.drdo.gov.in/drdo/careers",
    "https://www.joinindiannavy.gov.in/",
    "https://agnipathvayu.cdac.in/",                  # IAF Agniveer
    "https://joinindiancoastguard.cdac.in/",
    "https://opportunities.rbi.org.in/",              # RBI
    "https://www.nabard.org/careers-notices.aspx",
    "https://licindia.in/careers",
    "https://www.esic.gov.in/recruitments",
    "https://www.epfindia.gov.in/site_en/Recruitments.php",
    "https://navodaya.gov.in/",                       # NVS
    "https://kvsangathan.nic.in/",                    # KVS
    "https://www.aiimsexams.ac.in/",
    "https://www.ncs.gov.in/",                        # National Career Service
    "https://www.employmentnews.gov.in/",
    # --- v402 results / hall tickets (per-exam portals, not only boards) ---
    "https://www.tspsc.gov.in/results",               # TSPSC results listing
    "https://www.tspsc.gov.in/halltickets",           # TSPSC hall tickets listing
    "https://psc.ap.gov.in/Results",                  # APPSC results
    "https://results.cgg.gov.in/",                    # TS results portal (DSC/TET/CETs)
    "https://cets.apsche.ap.gov.in/",                 # AP CETs (EAPCET/ICET/ECET/PGECET)
    "https://www.manabadi.co.in/",                    # results aggregator (leads only; official link required downstream)
    "https://www.schools9.com/",                      # results aggregator (leads only)
    # --- v402 private / software / walk-in (geo_gate keeps Hyderabad/TS/AP only) ---
    "https://www.freshersworld.com/jobs/jobsearch/walkin-jobs-in-hyderabad",
    "https://www.freshersworld.com/jobs/jobsearch/it-software-jobs-in-hyderabad",
    "https://www.freshersworld.com/jobs/jobsearch/jobs-in-vijayawada",
    "https://www.freshersworld.com/jobs/jobsearch/jobs-in-visakhapatnam",
    "https://internshala.com/internships/internship-in-hyderabad/",
    "https://internshala.com/jobs/fresher-jobs-in-hyderabad/",
    "https://task.telangana.gov.in/",                 # TG skill & knowledge — job melas
    "https://apssdc.in/",                             # AP skill development — job melas
    "https://www.tcs.com/careers",                    # company careers (best-effort; JS-heavy pages yield few links)
    "https://www.infosys.com/careers/",
    "https://careers.wipro.com/",
    "https://www.hcltech.com/careers",
    "https://careers.cognizant.com/",
    "https://careers.capgemini.com/",
    # --- v402 schemes (TS/AP/Central) ---
    "https://www.myscheme.gov.in/",
    "https://pib.gov.in/allRel.aspx",
    # --- education desks with RSS (rewritten in original Telugu, never copied) ---
    "https://www.freejobalert.com/feed/",
    "https://www.sakshieducation.com/rss/latest.xml",
    "https://www.jagranjosh.com/rss/josh/government-jobs.xml",
]


def watch_sources() -> list:
    """Merged watch list: built-ins (unless disabled) + owner WATCH_SOURCES."""
    out = list(OFFICIAL_WATCH_DEFAULT) if OFFICIAL_WATCH_BUILTIN else []
    for u in [x.strip() for x in WATCH_SOURCES.split(",") if x.strip()]:
        if u not in out:
            out.append(u)
    return out

# --- v16: Viral stories + tips share (%) in listicle rotation -------------
VIRAL_LISTICLE_SHARE = int(_get("VIRAL_LISTICLE_SHARE", "30"))
TIPS_SHARE = int(_get("TIPS_SHARE", "15"))

# --- v17: Keyword Dominance Engine ---------------------------------------
KEYWORD_DAILY_QUEUE = int(_get("KEYWORD_DAILY_QUEUE", "4"))
# custom autocomplete seeds (comma); empty = top exams auto
KEYWORD_SUGGEST_SEEDS = _get("KEYWORD_SUGGEST_SEEDS", "")

# --- AI providers --------------------------------------------------------
# Gemini remains the default, but article/quiz generation can fail over to
# OpenAI-compatible APIs.  Keep keys in .env or the server secret store only;
# never commit them or paste them into Telegram.
AI_PROVIDER = _get("AI_PROVIDER", "gemini").strip().lower()
AI_FALLBACK_PROVIDERS = [
    p.strip().lower()
    for p in _get(
        "AI_FALLBACK_PROVIDERS",
        "groq,openrouter,cerebras,together,mistral,openai,custom",
    ).split(",")
    if p.strip()
]
AI_MAX_OUTPUT_TOKENS = int(_get("AI_MAX_OUTPUT_TOKENS", "8192"))

# Gemini (native Google generateContent API)
GEMINI_API_BASE = _get(
    "GEMINI_API_BASE", "https://generativelanguage.googleapis.com/v1beta"
)
GEMINI_API_KEY = _get("GEMINI_API_KEY", "")
GEMINI_MODEL = _get("GEMINI_MODEL", "gemini-3.8-flash")
GEMINI_FALLBACK_MODELS = [
    m.strip()
    for m in _get(
        "GEMINI_FALLBACK_MODELS", "gemini-flash-latest,gemini-3-flash-preview,gemini-2.5-flash-lite"
    ).split(",")
    if m.strip()
]
GEMINI_MAX_RETRIES = int(_get("GEMINI_MAX_RETRIES", "3"))
# v17.1: Telugu JSON 8192 tokens lo truncate avveti — big cap + env tunable
GEMINI_MAX_OUTPUT_TOKENS = int(_get("GEMINI_MAX_OUTPUT_TOKENS", "32768"))
# v401d (audit PR-5): hard daily cap on AI model calls (all providers, all
# keys). 0 = off. Default 500 ≈ 24 hourly runs × (draft + refine + retries) with
# generous headroom; crossing it raises GeminiError so the run stops cleanly
# instead of silently burning quota/money.
AI_DAILY_CALL_CAP = int(os.getenv("AI_DAILY_CALL_CAP", "500") or 0)
# v18: Multiple Gemini keys — 429 quota rotation (comma-separated okka line)
GEMINI_API_KEYS = [
    k.strip() for k in _get("GEMINI_API_KEYS", "").split(",") if k.strip()
]

# OpenAI-compatible providers. Models are deliberately environment-overridable
# because free-tier model names and availability change frequently.
GROQ_API_BASE = _get("GROQ_API_BASE", "https://api.groq.com/openai/v1").rstrip("/")
GROQ_API_KEY = _get("GROQ_API_KEY", "")
GROQ_API_KEYS = [k.strip() for k in _get("GROQ_API_KEYS", "").split(",") if k.strip()]
GROQ_MODEL = _get("GROQ_MODEL", "llama-3.3-70b-versatile")
GROQ_FALLBACK_MODELS = [m.strip() for m in _get("GROQ_FALLBACK_MODELS", "").split(",") if m.strip()]

OPENROUTER_API_BASE = _get("OPENROUTER_API_BASE", "https://openrouter.ai/api/v1").rstrip("/")
OPENROUTER_API_KEY = _get("OPENROUTER_API_KEY", "")
OPENROUTER_API_KEYS = [k.strip() for k in _get("OPENROUTER_API_KEYS", "").split(",") if k.strip()]
OPENROUTER_MODEL = _get("OPENROUTER_MODEL", "openrouter/free")
OPENROUTER_FALLBACK_MODELS = [m.strip() for m in _get("OPENROUTER_FALLBACK_MODELS", "").split(",") if m.strip()]

CEREBRAS_API_BASE = _get("CEREBRAS_API_BASE", "https://api.cerebras.ai/v1").rstrip("/")
CEREBRAS_API_KEY = _get("CEREBRAS_API_KEY", "")
CEREBRAS_API_KEYS = [k.strip() for k in _get("CEREBRAS_API_KEYS", "").split(",") if k.strip()]
CEREBRAS_MODEL = _get("CEREBRAS_MODEL", "llama-3.3-70b")
CEREBRAS_FALLBACK_MODELS = [m.strip() for m in _get("CEREBRAS_FALLBACK_MODELS", "").split(",") if m.strip()]

TOGETHER_API_BASE = _get("TOGETHER_API_BASE", "https://api.together.xyz/v1").rstrip("/")
TOGETHER_API_KEY = _get("TOGETHER_API_KEY", "")
TOGETHER_API_KEYS = [k.strip() for k in _get("TOGETHER_API_KEYS", "").split(",") if k.strip()]
TOGETHER_MODEL = _get("TOGETHER_MODEL", "meta-llama/Llama-3.3-70B-Instruct-Turbo")
TOGETHER_FALLBACK_MODELS = [m.strip() for m in _get("TOGETHER_FALLBACK_MODELS", "").split(",") if m.strip()]

MISTRAL_API_BASE = _get("MISTRAL_API_BASE", "https://api.mistral.ai/v1").rstrip("/")
MISTRAL_API_KEY = _get("MISTRAL_API_KEY", "")
MISTRAL_API_KEYS = [k.strip() for k in _get("MISTRAL_API_KEYS", "").split(",") if k.strip()]
MISTRAL_MODEL = _get("MISTRAL_MODEL", "mistral-small-latest")
MISTRAL_FALLBACK_MODELS = [m.strip() for m in _get("MISTRAL_FALLBACK_MODELS", "").split(",") if m.strip()]

# Generic custom OpenAI-compatible endpoint: useful for any other provider
# without another code change (e.g. a self-hosted gateway).
OPENAI_API_BASE = _get("OPENAI_API_BASE", "https://api.openai.com/v1").rstrip("/")
OPENAI_API_KEY = _get("OPENAI_API_KEY", "")
OPENAI_API_KEYS = [k.strip() for k in _get("OPENAI_API_KEYS", "").split(",") if k.strip()]
OPENAI_MODEL = _get("OPENAI_MODEL", "gpt-4o-mini")
OPENAI_FALLBACK_MODELS = [m.strip() for m in _get("OPENAI_FALLBACK_MODELS", "").split(",") if m.strip()]

CUSTOM_API_BASE = _get("CUSTOM_API_BASE", "").rstrip("/")
CUSTOM_API_KEY = _get("CUSTOM_API_KEY", "")
CUSTOM_API_KEYS = [k.strip() for k in _get("CUSTOM_API_KEYS", "").split(",") if k.strip()]
CUSTOM_MODEL = _get("CUSTOM_MODEL", "")
CUSTOM_FALLBACK_MODELS = [m.strip() for m in _get("CUSTOM_FALLBACK_MODELS", "").split(",") if m.strip()]


_PROVIDER_NAMES = ("gemini", "groq", "openrouter", "cerebras", "together", "mistral", "openai", "custom")


def ai_provider_keys(provider: str) -> List[str]:
    """Return the primary key plus optional rotated keys for a provider."""
    name = (provider or "").strip().lower()
    prefix = name.upper()
    primary = globals().get(f"{prefix}_API_KEY", "")
    extras = globals().get(f"{prefix}_API_KEYS", []) or []
    keys = list(extras)
    if primary and primary not in keys:
        keys.insert(0, primary)
    placeholders = {
        "your_gemini_api_key", "key2_here", "key3_here", "key4_here",
        "your_api_key", "your_provider_key",
    }
    return [
        str(k).strip()
        for k in keys
        if str(k).strip() and str(k).strip().lower() not in placeholders
    ]


def ai_provider_configured(provider: str) -> bool:
    return bool(ai_provider_keys(provider))


def configured_ai_providers() -> List[str]:
    return [p for p in _PROVIDER_NAMES if ai_provider_configured(p)]


def ai_configured() -> bool:
    """Whether at least one configured provider can serve draft generation."""
    return bool(configured_ai_providers())


def gemini_configured() -> bool:
    """Backward-compatible name used by older code; now means any AI provider."""
    return ai_configured()


GEMINI_RPD_PER_KEY = int(_get("GEMINI_RPD_PER_KEY", "1400"))
# v18: Rank Math STRICT gate (real panel checks) — target + refine rounds
RM_TARGET = int(_get("RM_TARGET", "100"))   # v64: 100 target (Rank Math)
# Direct live publishing requires the actual score read back from WordPress.
# Missing Rank Math/plugin readback stays a draft; no local estimate can unlock it.
RM_REQUIRE_LIVE_SCORE = _get("RM_REQUIRE_LIVE_SCORE", "1") not in ("0", "false", "no")
# Practical live threshold: aim for 100, accept only real Rank Math scores
# >=80 for owner-approved publishing. Missing score never passes.
RM_LIVE_MIN_SCORE = max(0, min(100, int(_get("RM_LIVE_MIN_SCORE", "80") or 80)))
# Independent rendered-HTML audit threshold; this is not a Rank Math score.
LIVE_SEO_MIN_COVERAGE = max(0, min(100, float(_get("LIVE_SEO_MIN_COVERAGE", "80") or 80)))
# Rank Math's regular-post content check is a 600-word recommendation. Keep
# this separate from the optional long-form/top-post quality target so the bot
# does not add filler merely to satisfy an internal 1500-word rule.
# v391: 600 → 450. Exam-date / hall-ticket / short-notice stories are complete
# at ~400 useful words; the owner rule is "never pad" (v383), so the gate floor
# follows the content, not Rank Math's 600 vanity number (worth 1–2 RM points).
RM_MIN_WORDS = int(_get("RM_MIN_WORDS", "450"))
# v95: in-body contextual internal links (paragraph lopala) max count
CONTEXTUAL_LINKS_MAX = int(_get("CONTEXTUAL_LINKS_MAX", "3"))
RM_REFINE_ROUNDS = int(_get("RM_REFINE_ROUNDS", "2"))  # v64: 2 rounds
# v355: FINAL POLISH — "100 times check" loop (RM strict + pin-gate → LLM refine)
FINAL_POLISH_ENABLED = _get("FINAL_POLISH_ENABLED", "1") not in ("0", "false", "no")
FINAL_POLISH_ROUNDS = int(_get("FINAL_POLISH_ROUNDS", "2"))
DRAFT_RECHECK_HOUR = int(_get("DRAFT_RECHECK_HOUR", "21"))      # daily WP draft re-check
DRAFT_RECHECK_LIMIT = int(_get("DRAFT_RECHECK_LIMIT", "10"))
DRAFT_RECHECK_APPLY = _get("DRAFT_RECHECK_APPLY", "1") not in ("0", "false", "no")
# v18: AdSense-safe originality floor — ee % kindha post publish cheyyadu.
# 80 keeps a paraphrase-heavy rewrite in review instead of presenting it as
# StudentUp's own article; the exact-overlap guard below remains mandatory.
ORIG_HARD_FLOOR = float(_get("ORIG_HARD_FLOOR", "80"))
# Mobile lo headings peddaga unte — responsive clamp CSS add (1=on)
# v388: default OFF — the theme (1.9.x) already loads Noto Sans Telugu + sets
# heading sizes; a per-post <style> with a Google Fonts @import was a
# render-blocking request on EVERY article (CWV) and duplicated theme CSS.
MOBILE_HEADLINE_TUNE = _get("MOBILE_HEADLINE_TUNE", "0") not in ("0", "false", "no")

# v19 (playbook alignment): Google Jobs schema, deadline countdown, dup guard
SUPPORT_EMAIL = _get("SUPPORT_EMAIL", "studentupinformative@gmail.com")

# Real bylines (Google News + E-E-A-T require): "Name:Role;Name:Role"
AUTHOR_TEAM = []
# Never claim a human review that did not happen. Set this only after a named
# editor has actually checked the draft and its official sources.
EDITORIAL_REVIEWER = _get("EDITORIAL_REVIEWER", "").strip()
for _a in _get(
    "AUTHOR_TEAM",
    "Charan Pendota:Founder & Content Writer",
).split(";"):
    if ":" in _a:
        _n, _r = _a.split(":", 1)
        AUTHOR_TEAM.append((_n.strip(), _r.strip()))
    elif _a.strip():
        AUTHOR_TEAM.append((_a.strip(), "Editorial Team"))

# Authority hub pages (playbook: exam hubs = session depth + internal links)
HUB_EXAMS = [x.strip() for x in _get(
    "HUB_EXAMS",
    "SSC CGL,SSC CHSL,SSC MTS,RRB Group D,RRB ALP,TET,TS DSC,"
    "TSPSC Group 2,APPSC Group 2,ICET,TS Police Constable,SBI PO,"
    "IBPS Clerk,Scholarships").split(",") if x.strip()]
# v96: district job hubs (TS 33 + AP 26) — thin-page guard threshold.
# Ee count kanna takkuva posts unna district ki page create AVVADU
# (Google scaled-content / AdSense low-value rules — khali shelves vaddu).
DISTRICT_HUB_MIN_POSTS = int(_get("DISTRICT_HUB_MIN_POSTS", "3") or "3")
# Sponsored/featured listing CTA (AdSense disclosure REQUIRED with it)
FEATURED_CTA_HTML = _get("FEATURED_CTA_HTML", "")
JOB_SCHEMA_ENABLED = _get("JOB_SCHEMA_ENABLED", "1") not in ("0", "false", "no")
# Google "scaled content abuse" rule — mana previous post tho ee threshold
# dabbi dup ante source post SKIP avuthundi
DUP_JACCARD_SKIP = float(_get("DUP_JACCARD_SKIP", "0.62"))

# v21 FACT GUARD: article lo unna dates/numbers source lo verify ayyi unali
# (fake deadline = Google News/AdSense ki chamathaga chaduvuna paadu)
FACT_STRICT = _get("FACT_STRICT", "1") not in ("0", "false", "no")

# --- Schedule ------------------------------------------------------------
# Draft-first quality default: do not create a scaled-content firehose.
GEO_GATE = _get("GEO_GATE", "1") not in ("0", "false", "no")  # v401 TS/AP/Central only
DRAFTS_SLO = int(_get("DRAFTS_SLO", "2"))      # v399: alert if fewer drafts by 14:00 IST
DAILY_MIN = int(_get("DAILY_MIN", "3"))      # min draft slots per day
DAILY_MAX = int(_get("DAILY_MAX", "5"))      # max draft slots per day
ACTIVE_HOUR_START = int(_get("ACTIVE_HOUR_START", "6"))   # first posting hour (local)
ACTIVE_HOUR_END = int(_get("ACTIVE_HOUR_END", "22"))      # last posting hour (local)
TIMEZONE = _get("TIMEZONE", "Asia/Kolkata")

# --- Content -------------------------------------------------------------
_CATEGORY_ALIASES = {
    # Older .env files used these broad labels. Normalize them at startup so
    # they cannot create duplicate WordPress archives beside the canonical map.
    "govt jobs": "Central Govt Jobs",
    "education news": "Current Affairs",
    "exam updates": "Upcoming Exams",
    "admissions": "Online Education",
    "study tips": "Exam Tips",
}
_raw_categories = _get(
    "CATEGORIES",
    # LIVE SITE categories (studentup.in wp-json lo unnavi — exact match,
    # bot duplicate categories create cheyadu, existing IDs reuse avtayi)
    "Scholarships,Central Govt Jobs,TS Govt Jobs,AP Govt Jobs,"
    "Private Jobs,Software Jobs,Part Time Jobs,Walkin Jobs,"
    "Outsourcing Jobs,Hall Tickets,Results,Internships,Online Education,"
    "Current Affairs,Exam Tips,Upcoming Exams,Abroad Jobs,Success Stories,"
    # v221: viral local streams — welfare schemes + TS/AP district news.
    "Govt Schemes,District News",
).split(",")
CATEGORIES = []
for _category in _raw_categories:
    _category = _category.strip()
    if not _category:
        continue
    _canonical = _CATEGORY_ALIASES.get(_category.lower(), _category)
    if _canonical not in CATEGORIES:
        CATEGORIES.append(_canonical)

# Category priority — ee canonical categories ki extra tickets (revenue
# strategy: job/exam intent gets demand, but classification stays editorial).
# Format: "Central Govt Jobs:4,Results:3,Current Affairs:2" (0 = no boost)
CATEGORY_PRIORITY = {}
for _pair in _get("CATEGORY_PRIORITY",
                  "Central Govt Jobs:4,TS Govt Jobs:4,AP Govt Jobs:3,"
                  "Results:3,Software Jobs:2,Private Jobs:2,"
                  "Upcoming Exams:4,Outsourcing Jobs:3,Current Affairs:3,"
                  "Scholarships:3,Exam Tips:2,"
                  # v58: విదేశీ ఉద్యోగాలు — Gulf/NRI audience + high-CPC
                  # (IELTS, visa, education loan, consultancy)
                  "Abroad Jobs:4,"
                  # v221: schemes/district news = high-volume viral demand
                  "Govt Schemes:4,District News:3").split(","):
    if ":" in _pair:
        _k, _v = _pair.split(":", 1)
        try:
            CATEGORY_PRIORITY[_k.strip()] = int(_v.strip())
        except ValueError:
            pass

# --- v28: safe site operations --------------------------------------------
# Only this small, reviewed allow-list can ever be installed by the bot.
# WordPress still decides whether the authenticated user has install_plugins /
# activate_plugins capability; failures are reported, never hidden.
PLUGIN_AUTO_INSTALL = _get("PLUGIN_AUTO_INSTALL", "1") not in ("0", "false", "no")
PLUGIN_AUTO_ACTIVATE = _get("PLUGIN_AUTO_ACTIVATE", "1") not in ("0", "false", "no")
# Comma-separated slugs. Keep this allow-list deliberately boring and small.
AUTO_INSTALL_PLUGINS = [
    p.strip().lower()
    for p in _get(
        "AUTO_INSTALL_PLUGINS",
        "rank-math,redirection,updraftplus,wp-super-cache",
    ).split(",")
    if p.strip()
]
# AdSense Auto Ads loader is never emitted with an empty/invalid id.
ADSENSE_ENABLED = _get("ADSENSE_ENABLED", "1") not in ("0", "false", "no")
ADSENSE_AUTO_ADS = _get("ADSENSE_AUTO_ADS", "1") not in ("0", "false", "no")
# Hard gate: before Google approves the account, neither ad slots nor the
# Auto Ads loader can be emitted even if a client id is accidentally present.
ADSENSE_APPROVED = _get("ADSENSE_APPROVED", "0") not in ("0", "false", "no")
ADSENSE_CLIENT_ID = _get("ADSENSE_CLIENT_ID", "").strip()
# v64: website options (.env nunchi theme ki push avutayi — --push-theme-data)
SOCIAL_WHATSAPP = _get("SOCIAL_WHATSAPP", "").strip()
SOCIAL_TELEGRAM = _get("SOCIAL_TELEGRAM", "").strip()
SOCIAL_INSTAGRAM = _get("SOCIAL_INSTAGRAM", "").strip()
SOCIAL_YOUTUBE = _get("SOCIAL_YOUTUBE", "").strip()
CONTACT_EMAIL = _get("CONTACT_EMAIL", "").strip()
STICKY_AD = _get("STICKY_AD", "").strip()
# v65: pin-to-pin gate + Google trends capture
PIN_GATE_BLOCK = _get("PIN_GATE_BLOCK", "1") not in ("0", "false", "no")
TRENDS_GEO = _get("TRENDS_GEO", "IN").strip() or "IN"
# v97: real-time keyword verification (Google Autocomplete = live demand).
# KW_VERIFY=0 → off (offline/CI). TTL = same prefix ni malli fetch cheyyakunda.
KW_VERIFY = _get("KW_VERIFY", "1") not in ("0", "false", "no")
KW_VERIFY_TTL = int(_get("KW_VERIFY_TTL", "3600") or 3600)
TRENDS_ENABLED = _get("TRENDS_ENABLED", "1") not in ("0", "false", "no")
# Consent is a deployment responsibility, not something the bot can fake.
# Set a real Google-certified CMP/provider in production and verify its UI.
ADSENSE_CONSENT_PROVIDER = _get("ADSENSE_CONSENT_PROVIDER", "").strip()
# Optional measurement; never emitted unless an explicit GA4 id is supplied.
GA4_ENABLED = _get("GA4_ENABLED", "0") not in ("0", "false", "no")
GA4_MEASUREMENT_ID = _get("GA4_MEASUREMENT_ID", "").strip()

# --- v223: auto-config — .env nunchi theme options direct ga set avutai -----
# Idanta `--go-live --apply` lo automatic ga WordPress ki push avutundi.
# AdSense slot IDs (approval taruvata AdSense dashboard nunchi copy chesi ikkada pettandi)
ADSENSE_SLOTS = {
    key: _get("ADSENSE_SLOT_" + key.upper(), "").strip()
    for key in (
        "top_leaderboard", "sidebar", "anchor", "mid", "mid_b",
        "below_content", "below_content_b", "in_feed", "video", "multiplex",
    )
}
# Search Console / Bing verification meta tokens (one-time copy from the console)
GSC_VERIFY_TOKEN = _get("GSC_VERIFY_TOKEN", "").strip()
BING_VERIFY_TOKEN = _get("BING_VERIFY_TOKEN", "").strip()
# Consent (EEA/UK) — Google-certified CMP
CONSENT_MODE = _get("CONSENT_MODE", "1") not in ("0", "false", "no")
CONSENT_REGIONS = _get("CONSENT_REGIONS", "EEA,UK").strip()
CONSENT_CMP_ID = _get("CONSENT_CMP_ID", "").strip()
# Cache purge after a theme/option change
CLOUDFLARE_API_TOKEN = _get("CLOUDFLARE_API_TOKEN", "").strip()
CLOUDFLARE_ZONE_ID = _get("CLOUDFLARE_ZONE_ID", "").strip()

# --- v224: money autopilot -------------------------------------------------
# Weekly (Sunday) daily-run lo taane run avutundi. 0 pedithe off.
MONEY_AUTOPILOT = _get("MONEY_AUTOPILOT", "1")
# AdSense/GA4 earnings CSV path — unte RPM report + slot lab kooda automatic.
REVENUE_CSV = _get("REVENUE_CSV", "").strip()
# v226: Microsoft Clarity project id (heatmaps + session recordings)
CLARITY_ID = _get("CLARITY_ID", "").strip()

# --- v31: Student Internet Center service workflow ------------------------
SERVICE_CENTER_ENABLED = _get("SERVICE_CENTER_ENABLED", "1") not in ("0", "false", "no")
SERVICE_CENTER_NAME = _get("SERVICE_CENTER_NAME", "StudentUp Internet Center").strip()
SERVICE_CENTER_PHONE = _get("SERVICE_CENTER_PHONE", "").strip()
SERVICE_CENTER_WHATSAPP = _get("SERVICE_CENTER_WHATSAPP", "").strip()
SERVICE_CENTER_EMAIL = _get("SERVICE_CENTER_EMAIL", "").strip()
SERVICE_CENTER_CITY = _get("SERVICE_CENTER_CITY", "Hyderabad").strip()
# v226: LocalBusiness schema (#19) — address unte matrame schema emit avutundi
SERVICE_CENTER_ADDRESS = _get("SERVICE_CENTER_ADDRESS", "").strip()
SERVICE_CENTER_PAGE_SLUG = _get("SERVICE_CENTER_PAGE_SLUG", "student-services")
# Prefer a private upload portal or staff-issued one-time link. Empty means
# the public page tells callers to request a secure link instead of collecting
# raw documents in an open form.
SERVICE_CENTER_UPLOAD_URL = _get("SERVICE_CENTER_UPLOAD_URL", "").strip()
SERVICE_CENTER_DB = Path(_get("SERVICE_CENTER_DB", str(BASE_DIR / "service_center.db")))
SERVICE_RETENTION_DAYS = int(_get("SERVICE_RETENTION_DAYS", "30"))

# --- Verified Success Stories ---------------------------------------------
# Public intake is optional and never auto-publishes. The editor selects up to
# three verified TS/AP stories per ISO week after consent and evidence review.
SUCCESS_STORIES_ENABLED = _get("SUCCESS_STORIES_ENABLED", "1") not in ("0", "false", "no")
SUCCESS_STORY_FORM_URL = _get("SUCCESS_STORY_FORM_URL", "").strip()
SUCCESS_STORY_WEEKLY_MAX = max(1, min(7, int(_get("SUCCESS_STORY_WEEKLY_MAX", "3") or "3")))
SUCCESS_STORY_QUEUE = Path(_get("SUCCESS_STORY_QUEUE", str(BASE_DIR / "output" / "success-stories-review.json")))

# --- v33: Google-facing public page audit ---------------------------------
PAGESPEED_API_KEY = _get("PAGESPEED_API_KEY", "").strip()
GOOGLE_AUDIT_TIMEOUT = int(_get("GOOGLE_AUDIT_TIMEOUT", "90"))

# --- v38: Top Post Dominance Engine ---------------------------------------
# Blueprint → write → score → harden → gate. "Top post" = measured, not claimed.
TOP_POST_ENGINE = _get("TOP_POST_ENGINE", "1") not in ("0", "false", "no")
# Live publish ki minimum Top Post Score (drafts eppudu allow).
TOP_POST_MIN_SCORE = int(_get("TOP_POST_MIN_SCORE", "78"))
# Direct live publish lo score < target unte block (draft-first lo enforce kaadu).
TOP_POST_STRICT = _get("TOP_POST_STRICT", "1") not in ("0", "false", "no")
# Word target (score check) + over-optimization ceiling for keyword density.
TOP_POST_WORDS_TARGET = int(_get("TOP_POST_WORDS_TARGET", "1500"))
TOP_POST_MAX_DENSITY = float(_get("TOP_POST_MAX_DENSITY", "0.03"))
# Dominance calendar default length (days) — `--top-post-plan`
TOP_POST_PLAN_DAYS = int(_get("TOP_POST_PLAN_DAYS", "90"))

# --- v26: Daily Quiz Engine (exam-style interactive quizzes) --------------
# Daily output is always a review draft. If no AI provider is configured,
# create a deterministic sample draft rather than silently skipping the slot.
QUIZ_ENABLED = _get("QUIZ_ENABLED", "1") not in ("0", "false", "no")
QUIZ_SAMPLE_FALLBACK = _get("QUIZ_SAMPLE_FALLBACK", "1") not in ("0", "false", "no")
QUIZ_CATEGORY = _get("QUIZ_CATEGORY", "Daily Quiz")
# v402: daily current affairs (Telugu) — category + optional extra RSS feeds
CA_CATEGORY = _get("CA_CATEGORY", "Current Affairs")
CA_FEEDS = _get("CA_FEEDS", "")
# v402: composite daily category quota (planner) — "Category:N,..." ; carry-over of
# yesterday's shortfall is automatic. DAILY_PLANNER_ENABLED=0 → old weighted pick.
SIMILARITY_SYNC_HOURS = float(_get("SIMILARITY_SYNC_HOURS", "24"))
DAILY_QUOTA = _get("DAILY_QUOTA", "")
DAILY_PLANNER_ENABLED = _get("DAILY_PLANNER_ENABLED", "1") not in ("0", "false", "no")
QUIZ_HOUR = int(_get("QUIZ_HOUR", "8"))          # morning study time
QUIZ_QUESTIONS = int(_get("QUIZ_QUESTIONS", "10"))
QUIZ_SUNDAY_QUESTIONS = int(_get("QUIZ_SUNDAY_QUESTIONS", "20"))  # weekly mega mock
QUIZ_TIME_PER_Q = int(_get("QUIZ_TIME_PER_Q", "60"))   # seconds/question (exam mode)
QUIZ_NEGATIVE_MARK = _get("QUIZ_NEGATIVE_MARK", "1") not in ("0", "false", "no")
# auto = day-of-week difficulty ramp (Mon L1 ... Sun Top-Level); 1-4 = fixed
QUIZ_LEVEL = _get("QUIZ_LEVEL", "auto")
# Quiz JSON cache (server-side analytics kosam; empty = off)
QUIZ_LANGUAGE = _get("QUIZ_LANGUAGE", "te-en")   # bilingual Telugu+English

# --- Images --------------------------------------------------------------
IMAGE_ENABLED = _get("IMAGE_ENABLED", "1") not in ("0", "false", "no")
IMAGE_WIDTH = int(_get("IMAGE_WIDTH", "1200"))
IMAGE_HEIGHT = int(_get("IMAGE_HEIGHT", "675"))
SITE_BRAND = _get("SITE_BRAND", "studentup.in")

# --- Paths / network -----------------------------------------------------
STATE_PATH = Path(_get("STATE_PATH", str(BASE_DIR / "state.db")))
LOG_DIR = Path(_get("LOG_DIR", str(BASE_DIR / "log")))
OUTPUT_DIR = Path(_get("OUTPUT_DIR", str(BASE_DIR / "output")))

# v183: daily WhatsApp-forward list (plain text) — output/forward-list.txt
FORWARD_LIST_PATH = Path(_get("FORWARD_LIST_PATH", str(OUTPUT_DIR / "forward-list.txt")))
FORWARD_LIST_STATE_PATH = Path(_get("FORWARD_LIST_STATE_PATH",
                                    str(OUTPUT_DIR / "forward-list-state.json")))
# v184: deadline cheppakapoyina 120+ rojula puratana posts active list nunchi out
# (0 = off). Site board (theme) kuda ide window vaadutundi.
OPPORTUNITY_STALE_DAYS = int(_get("OPPORTUNITY_STALE_DAYS", "120") or 0)

# v186: live site audit (deploy tarvata HTTP verification)
LIVE_AUDIT_PATH = Path(_get("LIVE_AUDIT_PATH", str(OUTPUT_DIR / "live-audit.json")))
LIVE_AUDIT_POSTS = int(_get("LIVE_AUDIT_POSTS", "5") or 5)
LIVE_AUDIT_TIMEOUT = int(_get("LIVE_AUDIT_TIMEOUT", "20") or 20)

# v187: multi-link intake (oka list links → prathi okkati veru draft)
LINK_INTAKE_MAX = int(_get("LINK_INTAKE_MAX", "10") or 10)
# v220: rendu drafts madhya pause (seconds). "Neat ga time thiskoni draft
# cheyyali" — provider rate-limits ni daatakunda, prathi article ki pooriti
# research time istundi. 0 pedithe pause ledu (tests / manual rush).
LINK_INTAKE_DELAY = float(_get("LINK_INTAKE_DELAY", "20") or 0)
# Limit daatina links ikkada queue avutayi (tarvata run lo teeskovachu).
LINK_INTAKE_QUEUE = Path(_get("LINK_INTAKE_QUEUE", str(LOG_DIR / "link-queue.txt")))
LINK_INTAKE_REPORT = Path(_get("LINK_INTAKE_REPORT", str(OUTPUT_DIR / "link-intake.json")))

# --- v181: growth loops (reader demand · rank trend · sponsor pipeline) ---
# 1) On-site search demand → content gap queue (theme logs terms; bot reads)
SEARCH_DEMAND_QUEUE = Path(_get("SEARCH_DEMAND_QUEUE",
                                str(BASE_DIR / "output" / "search-demand-queue.json")))
SEARCH_DEMAND_MAX_TERMS = max(20, min(1000, int(_get("SEARCH_DEMAND_MAX_TERMS", "200") or "200")))
# 2) GSC time-series → decay detection → refresh queue
RANK_HISTORY_PATH = Path(_get("RANK_HISTORY_PATH",
                              str(BASE_DIR / "logs" / "rank-history.json")))
RANK_REFRESH_QUEUE = Path(_get("RANK_REFRESH_QUEUE",
                               str(BASE_DIR / "output" / "refresh-queue.json")))
RANK_HISTORY_MAX_SNAPSHOTS = max(10, min(400, int(_get("RANK_HISTORY_MAX_SNAPSHOTS", "120") or "120")))
# 3) Direct-sales sponsor pipeline (highest revenue lever, manual by design)
SPONSOR_PIPELINE_PATH = Path(_get("SPONSOR_PIPELINE_PATH",
                                  str(BASE_DIR / "ads" / "sponsors.json")))
SPONSOR_OUTREACH_PER_DAY = max(1, min(10, int(_get("SPONSOR_OUTREACH_PER_DAY", "2") or "2")))
SPONSOR_FOLLOWUP_STALE_DAYS = max(1, min(30, int(_get("SPONSOR_FOLLOWUP_STALE_DAYS", "3") or "3")))
# Daily hook (hourly cron lo okkasari): search demand + sponsor plan automatic
GROWTH_LOOPS_ENABLED = _get("GROWTH_LOOPS_ENABLED", "1") not in ("0", "false", "no")
GROWTH_LOOPS_HOUR = max(0, min(23, int(_get("GROWTH_LOOPS_HOUR", "9") or "9")))

# --- v182: editorial calendar · revenue loop · backlink authority -----------
EDITORIAL_CALENDAR_PATH = Path(_get("EDITORIAL_CALENDAR_PATH",
                                    str(BASE_DIR / "output" / "editorial-calendar.json")))
EDITORIAL_CALENDAR_DAYS = max(7, min(365, int(_get("EDITORIAL_CALENDAR_DAYS", "90") or "90")))
EDITORIAL_CALENDAR_PER_DAY = max(1, min(6, int(_get("EDITORIAL_CALENDAR_PER_DAY", "3") or "3")))
CALENDAR_APPLY_LIMIT = max(1, min(40, int(_get("CALENDAR_APPLY_LIMIT", "12") or "12")))
REVENUE_INSIGHTS_PATH = Path(_get("REVENUE_INSIGHTS_PATH",
                                  str(BASE_DIR / "output" / "revenue-insights.json")))
REVENUE_LOOP_MIN_IMPRESSIONS = max(10, min(100000,
    int(_get("REVENUE_LOOP_MIN_IMPRESSIONS", "50") or "50")))
BACKLINK_PIPELINE_PATH = Path(_get("BACKLINK_PIPELINE_PATH",
                                   str(BASE_DIR / "output" / "backlink-pipeline.json")))
BACKLINK_FOLLOWUP_DAYS = max(1, min(30, int(_get("BACKLINK_FOLLOWUP_DAYS", "7") or "7")))
RESEARCH_BRIEF_DIR = Path(_get("RESEARCH_BRIEF_DIR", str(OUTPUT_DIR / "research")))
# Save a private NotebookLM-ready evidence bundle for real source candidates.
# This prepares sources; it never pretends to access a private NotebookLM account.
NOTEBOOKLM_AUTO_BUNDLE = _get("NOTEBOOKLM_AUTO_BUNDLE", "1") not in ("0", "false", "no")
# Require a validated cited NotebookLM brief only when the owner explicitly enables it.
NOTEBOOKLM_REQUIRED = _get("NOTEBOOKLM_REQUIRED", "0") not in ("0", "false", "no")
HTTP_TIMEOUT = int(_get("HTTP_TIMEOUT", "90"))

# --- Sources (URL -> original rewrite) ------------------------------------
SOURCES_QUEUE_PATH = Path(_get("SOURCES_QUEUE_PATH", str(BASE_DIR / "sources_queue.txt")))
# Multi-source research: internet lo same topic articles search chesi
# extra facts teesukuni article ni super-complete chestundi (no API key)
RESEARCH_ENABLED = _get("RESEARCH_ENABLED", "1") not in ("0", "false", "no")
RESEARCH_MAX_SOURCES = int(_get("RESEARCH_MAX_SOURCES", "5"))
SEARCH_ENDPOINT = _get("SEARCH_ENDPOINT", "https://html.duckduckgo.com/html/")
SEARCH_FALLBACK_ENDPOINT = _get(
    "SEARCH_FALLBACK_ENDPOINT", "https://lite.duckduckgo.com/lite/"
)
# v103: live originality. Google CSE credentials unte actual Google result
# pages; lekapothe configured fallback engine tho transparent best-effort.
ORIG_LIVE_CHECK = _get("ORIG_LIVE_CHECK", "1") not in ("0", "false", "no")
ORIG_LIVE_PHRASES = int(_get("ORIG_LIVE_PHRASES", "3"))
ORIG_LIVE_REQUIRED = _get("ORIG_LIVE_REQUIRED", "0") not in ("0", "false", "no")
# v104: original practical value + claim provenance ledger.
EDITORIAL_VALUE_MIN = int(_get("EDITORIAL_VALUE_MIN", "55"))
EDITORIAL_VALUE_BLOCK = _get("EDITORIAL_VALUE_BLOCK", "1") not in ("0", "false", "no")
GOOGLE_CSE_API_KEY = _get("GOOGLE_CSE_API_KEY", "")
GOOGLE_CSE_ID = _get("GOOGLE_CSE_ID", "")
# v107: optional direct Google Search Console API (service account access).
GSC_SITE_URL = _get("GSC_SITE_URL", WP_SITE)
QUIZ_PAGE_URL = _get("QUIZ_PAGE_URL", "")  # v286: dedicated quiz page (empty = home #daily-quiz)
GSC_SERVICE_ACCOUNT_FILE = _get("GSC_SERVICE_ACCOUNT_FILE", "")
GSC_SERVICE_ACCOUNT_JSON = _get("GSC_SERVICE_ACCOUNT_JSON", "")
# v109: PageSpeed Insights / Lighthouse field audit.
PAGESPEED_API_KEY = _get("PAGESPEED_API_KEY", "")
# v113: deduplicated control-center Telegram alerts.
OPS_ALERTS_ENABLED = _get("OPS_ALERTS_ENABLED", "1") not in ("0", "false", "no")
# v114: once-daily API maintenance; missing credentials = non-fatal skip.
GSC_AUTO_SYNC = _get("GSC_AUTO_SYNC", "1") not in ("0", "false", "no")
GSC_SYNC_HOUR = int(_get("GSC_SYNC_HOUR", "6"))
# Rank Math meta dwara set cheyadam (plugin active unte automatic)
RANK_MATH_META_ENABLED = _get("RANK_MATH_META_ENABLED", "1") not in ("0", "false", "no")
# A low score may still be saved as a draft for human editing, but direct live
# publishing is blocked. This is a local quality gate, not a Google score.
PUBLISH_QA_MIN_SCORE = int(_get("PUBLISH_QA_MIN_SCORE", "80"))
PUBLISH_ORIGINALITY_MIN = float(_get("PUBLISH_ORIGINALITY_MIN", "72"))
SEO_SCHEMA_ENABLED = _get("SEO_SCHEMA_ENABLED", "1") not in ("0", "false", "no")
# v99: FAQPage schema. Google 7-May-2026 nunchi FAQ RICH RESULT teesesindi,
# kaani Bing/Copilot/Perplexity lanti AI retrieval systems inka parse
# chestayi (+ Google content understanding). Nijamaina visible Q&A
# unnappudu MATRAME emit avutundi (2+ questions). 0 pedithe off.
FAQ_SCHEMA_ENABLED = _get("FAQ_SCHEMA_ENABLED", "1") not in ("0", "false", "no")
# v100: weekly maintenance automation (cron flow lopala — CLI gurtu pettukovalsina
# avasaram ledu). Hub rebuild jarige weekly slot lo ne ivi kuda run avutayi.
DISTRICT_HUBS_AUTO = _get("DISTRICT_HUBS_AUTO", "1") not in ("0", "false", "no")
LINK_GRAPH_AUTO = _get("LINK_GRAPH_AUTO", "1") not in ("0", "false", "no")
LINK_GRAPH_LIMIT = int(_get("LINK_GRAPH_LIMIT", "100") or 100)

# v322: "Related Questions" block repeated the article's own sections — off by default.
RELATED_QUESTIONS_BLOCK = _get("RELATED_QUESTIONS_BLOCK", "0") not in ("0", "false", "no")

# v323 owner rule: article prose must be Telugu (English only for standard
# labels). Gate: share of words carrying Telugu script in the body.
TELUGU_MIN_SHARE = float(_get("TELUGU_MIN_SHARE", "0.55"))

# v324: nightly read-only live SEO verification of today's published posts → Telegram.
LIVE_SEO_DAILY = _get("LIVE_SEO_DAILY", "1") not in ("0", "false", "no")
LIVE_SEO_DAILY_HOUR = int(_get("LIVE_SEO_DAILY_HOUR", "20"))
LIVE_SEO_DAILY_LIMIT = int(_get("LIVE_SEO_DAILY_LIMIT", "5"))
TAKEAWAYS_BOX = _get("TAKEAWAYS_BOX", "0") in ("1", "true", "yes")
