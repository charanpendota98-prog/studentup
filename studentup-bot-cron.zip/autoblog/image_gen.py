"""Featured-image generator using Pillow (no external API needed).

v24 CROP-PROOF: theme cards crop to ANY aspect (mobile square ≈ center
56% width!). ALL text now lives in x∈[0.21w, 0.79w] center band — even the
worst object-fit crop cannot cut a single letter. Layouts center-aligned.

v15 PRO design (top-website level) + v16 3-layout rotation — post-to-post
okke pattern kanipinchadu, prathi okaati fresh (copy feel raadu):
  "left"   → left dark scrim + left-aligned title (news-site standard)
  "bottom" → bottom dark band, clean gradient top
  "right"  → right dark panel, left gradient art
Category pill, big bold wrapped title with shadow, accent underline bar,
brand pill + year chip — Adda247/Sakshi thumbnail style, mana own rendering.
"""

import logging
import random
import re
from datetime import date
from pathlib import Path
from typing import Optional

from PIL import Image, ImageDraw, ImageFilter, ImageFont

from . import config

log = logging.getLogger("autoblog.image")

PALETTES = [
    ((37, 27, 89), (87, 65, 175)),     # deep purple
    ((9, 47, 86), (25, 120, 166)),     # ocean blue
    ((6, 65, 61), (22, 138, 116)),     # teal green
    ((96, 34, 12), (211, 108, 39)),    # orange
    ((68, 16, 58), (163, 44, 110)),    # magenta
    ((20, 40, 80), (70, 130, 60)),     # blue-green mix
]

# kotha image prathi sari veedu marali — vanda posts lo okka color repeat avvakunda
_LAST_PALETTE = {"i": -1}

# v16 rotation → v24: center-safe layouts (bottom band / center panel / top pill)
VARIANTS = ["bottom", "center", "top"]
_LAST_VARIANT = {"i": -1}

ACCENT = (255, 138, 42)          # orange accent (brand energy)
DARK = (10, 12, 30)             # panel/scrim base

FONT_CANDIDATES = [
    "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
    "/usr/share/fonts/dejavu/DejaVuSans-Bold.ttf",
    "/usr/share/fonts/TTF/DejaVuSans-Bold.ttf",
    "/System/Library/Fonts/Supplemental/Arial Bold.ttf",
    "C:/Windows/Fonts/arialbd.ttf",
]


# WP/theme card thumbnails crop avuthayi — anni text center-safe ga undali.
# v2.1: 7.5% safe margins + short category labels (crop lo "VATE JOBS" lanti
# clipping raadu).
CAT_SHORT = {
    "Central Govt Jobs": "GOVT JOBS", "TS Govt Jobs": "TS GOVT JOBS",
    "AP Govt Jobs": "AP GOVT JOBS", "Online Education": "EDUCATION",
    "Part Time Jobs": "PART-TIME", "Walkin Jobs": "WALK-IN JOBS",
    "Hall Tickets": "HALL TICKET", "Private Jobs": "PRIVATE JOBS",
    "Software Jobs": "SOFTWARE JOBS", "Scholarships": "SCHOLARSHIPS",
    "Results": "RESULTS", "Internships": "INTERNSHIPS",
    "Outsourcing Jobs": "OUTSOURCING", "Current Affairs": "CURRENT AFFAIRS",
    "Exam Tips": "EXAM TIPS", "Upcoming Exams": "UPCOMING EXAMS",
}


def _pill_label(category: str, banner_text: str = "") -> str:
    cat = (category or "").strip()
    bt_lower = str(banner_text or "").lower()

    # Guard: Software / IT MNC jobs must NEVER display "GOVT JOBS"
    sw_signals = (
        "software", "developer", "programmer", "frontend", "backend",
        "full stack", "fullstack", "data analyst", "data scientist",
        "devops", "cloud engineer", "system engineer", "it job", "it jobs",
        "infor", "oracle", "sap", "salesforce", "servicenow", "capgemini",
        "tech mahindra", "genpact", "virtusa", "hexaware", "zoho",
        "freshworks", "ibm", "సాఫ్ట్‌వేర్", "ఇంజనీర్", "డెవలపర్",
    )
    pvt_signals = (
        "tcs", "infosys", "wipro", "hcl", "cognizant", "accenture",
        "deloitte", "private job", "private jobs", "mnc", "off campus",
        "campus hiring", "fresher hiring", "ప్రైవేట్",
    )
    govt_signals = (
        "ssc", "upsc", "rrb", "railway", "ibps", "sbi", "drdo", "isro",
        "police", "tspsc", "appsc", "dsc",
    )
    has_govt = any(g in bt_lower for g in govt_signals)
    if any(s in bt_lower for s in sw_signals) and not has_govt:
        cat = "Software Jobs"
    elif any(p in bt_lower for p in pvt_signals) and not has_govt:
        if cat in ("Central Govt Jobs", "Govt Jobs", "Online Education", ""):
            cat = "Private Jobs"

    label = CAT_SHORT.get(cat, cat.upper())
    return label[:16].strip() if len(label) > 16 else label


def _load_font(size: int) -> ImageFont.FreeTypeFont:
    for path in FONT_CANDIDATES:
        try:
            return ImageFont.truetype(path, size)
        except OSError:
            continue
    log.warning("No TrueType font found; using default bitmap font")
    return ImageFont.load_default()


# v87: Telugu → Latin (PIL has no Indic shaping — no raqm on server —
# Telugu renders as tofu boxes □□□. Transliterated bold Latin = readable
# thumbnails everywhere, deterministic local == server).
_TE_VOWELS = {"అ": "a", "ఆ": "aa", "ఇ": "i", "ఈ": "ee", "ఉ": "u", "ఊ": "oo",
              "ఋ": "ru", "ౠ": "roo", "ఎ": "e", "ఏ": "e", "ఐ": "ai", "ఒ": "o",
              "ఓ": "o", "ఔ": "au"}
_TE_CONS = {"క": "k", "ఖ": "kh", "గ": "g", "ఘ": "gh", "ఙ": "n", "చ": "ch",
            "ఛ": "chh", "జ": "j", "ఝ": "jh", "ఞ": "n", "ట": "t", "ఠ": "th",
            "డ": "d", "ఢ": "dh", "ణ": "n", "త": "t", "థ": "th", "ద": "d",
            "ధ": "dh", "న": "n", "ప": "p", "ఫ": "ph", "బ": "b", "భ": "bh",
            "మ": "m", "య": "y", "ర": "r", "ల": "l", "వ": "v", "శ": "sh",
            "ష": "sh", "స": "s", "హ": "h", "ళ": "l", "ఱ": "r", "క్ష": "ksh"}
_TE_MATRAS = {"ా": "aa", "ి": "i", "ీ": "ee", "ు": "u", "ూ": "oo",
              "ృ": "ru", "ౄ": "roo", "ె": "e", "ే": "e", "ై": "ai",
              "ొ": "o", "ో": "o", "ౌ": "au", "ం": "m", "ః": "h"}
_TE_DIGITS = {"౦": "0", "౧": "1", "౨": "2", "౩": "3", "౪": "4",
              "౫": "5", "౬": "6", "౭": "7", "౮": "8", "౯": "9"}
_TE_VIRAMA = "్"


# v401: thumbnails read as English, never as transliterated Telugu ("500
# postulu" on live cards looked broken). Common notice words map to their
# English equivalents; any other Telugu word is dropped from the banner.
_TE_BANNER_WORDS = [
    ("చివరి తేదీ", "Last Date"), ("ఆఖరి తేదీ", "Last Date"), ("హాల్ టికెట్", "Hall Ticket"),
    ("అడ్మిట్ కార్డ్", "Admit Card"), ("ఎంపిక జాబితా", "Select List"), ("మెరిట్ జాబితా", "Merit List"),
    ("పోస్టులకు", "Posts"), ("పోస్టుల", "Posts"), ("పోస్టులు", "Posts"), ("పోస్టు", "Post"),
    ("ఖాళీలు", "Vacancies"), ("ఉద్యోగాలు", "Jobs"), ("ఉద్యోగాల", "Jobs"), ("నోటిఫికేషన్", "Notification"),
    ("ఫలితాలు", "Results"), ("ఫలితం", "Result"), ("విడుదల", "Out"), ("దరఖాస్తు", "Apply"),
    ("పరీక్ష తేదీ", "Exam Date"), ("పరీక్ష", "Exam"), ("వివరాలు", "Details"), ("పూర్తి", "Full"),
    ("అర్హత", "Eligibility"), ("జీతం", "Salary"), ("సిలబస్", "Syllabus"), ("ప్రవేశాలు", "Admissions"),
    ("స్కాలర్‌షిప్", "Scholarship"), ("వాక్-ఇన్", "Walk-in"), ("తెలంగాణ", "Telangana"), ("ఆంధ్రప్రదేశ్", "AP"),
    ("జిల్లా", "District"), ("భర్తీ", "Recruitment"), ("నియామకాలు", "Recruitment"), ("వైద్యుల", "Doctor"),
    ("ఉపాధ్యాయ", "Teacher"), ("టీచర్", "Teacher"), ("పోలీస్", "Police"), ("కానిస్టేబుల్", "Constable"),
    ("బ్యాంక్", "Bank"), ("రైల్వే", "Railway"), ("ఇంటర్వ్యూ", "Interview"), ("కౌన్సెలింగ్", "Counselling"),
    ("హైదరాబాద్", "Hyderabad"), ("విశాఖపట్నం", "Visakhapatnam"), ("విజయవాడ", "Vijayawada"),
]


def banner_english(text: str) -> str:
    """Telugu banner → English banner (known words translated, rest dropped)."""
    t = text or ""
    for te, en in _TE_BANNER_WORDS:
        t = t.replace(te, " " + en + " ")
    t = re.sub(r"[\u0c00-\u0c7f\u200c\u200d]+", " ", t)      # leftover Telugu → out
    t = re.sub(r"\s*([:–—-])\s*(?=[:–—-])", "", t)             # ": –" doubles
    t = re.sub(r"\s+([,:;])", r"\1", t)
    t = re.sub(r"\s{2,}", " ", t).strip(" :–—-,·")
    return t or telugu_to_latin(text)


def telugu_to_latin(text: str) -> str:
    """Telugu runs → readable Latin (banner thumbnails kosam)."""
    out: list = []
    i, n = 0, len(text)
    while i < n:
        ch = text[i]
        if ch in _TE_CONS:
            base = _TE_CONS[ch]
            j = i + 1
            while j + 1 < n and text[j] == _TE_VIRAMA \
                    and text[j + 1] in _TE_CONS:
                base += _TE_CONS[text[j + 1]]
                j += 2
            if j < n and text[j] == _TE_VIRAMA:
                out.append(base)
                i = j + 1
                continue
            if j < n and text[j] in _TE_MATRAS:
                out.append(base + _TE_MATRAS[text[j]])
                i = j + 1
                continue
            out.append(base + "a")
            i = j
            continue
        if ch in _TE_VOWELS:
            out.append(_TE_VOWELS[ch])
        elif ch in _TE_DIGITS:
            out.append(_TE_DIGITS[ch])
        else:
            out.append(ch)
        i += 1
    return "".join(out)


def _split_word(draw, word: str, font, max_width: int) -> list:
    """v87: max_width kanna pedda single token → mid-word hard-break
    (URL/long-compound canvas overflow fix)."""
    if draw.textlength(word, font=font) <= max_width:
        return [word]
    parts, cur = [], ""
    for ch in word:
        if cur and draw.textlength(cur + ch, font=font) > max_width:
            parts.append(cur)
            cur = ch
        else:
            cur += ch
    if cur:
        parts.append(cur)
    return parts or [word]


def _wrap(draw: ImageDraw.ImageDraw, text: str, font, max_width: int,
           max_lines: int = 3) -> list:
    words: list = []
    for tok in text.split():
        words.extend(_split_word(draw, tok, font, max_width))
    lines, cur = [], ""
    for word in words:
        trial = (cur + " " + word).strip()
        if draw.textlength(trial, font=font) <= max_width:
            cur = trial
        else:
            if cur:
                lines.append(cur)
            cur = word
    if cur:
        lines.append(cur)
    if len(lines) > max_lines:
        # last line ellipsis
        lines = lines[:max_lines]
        # v386: ellipsis drops a whole word, never half a word ("2026 A ...")
        ws = lines[-1].split()
        lines[-1] = (" ".join(ws[:-1]) if len(ws) > 1 else lines[-1]) + " …"
    # v386: BALANCE — no orphan ("… 2026 – 120" / "Posts"). While the last line
    # is much shorter than the previous one, pull the previous line's last word
    # down if both still fit. Makes headline blocks look designed, not wrapped.
    for _ in range(4):
        if len(lines) < 2:
            break
        prev, last = lines[-2].split(), lines[-1].split()
        if len(prev) < 2 or draw.textlength(lines[-1], font=font) >= draw.textlength(lines[-2], font=font) * 0.6:
            break
        cand_prev = " ".join(prev[:-1])
        cand_last = " ".join([prev[-1]] + last)
        if draw.textlength(cand_last, font=font) > max_width:
            break
        lines[-2], lines[-1] = cand_prev, cand_last
    return lines


def _pill(draw: ImageDraw.ImageDraw, xy, text: str, font, fill, text_fill,
          radius=None):
    x0, y0 = xy
    tw = draw.textlength(text, font=font)
    pad = int(font.size * 0.45)
    box = [x0, y0, x0 + tw + pad * 2, y0 + font.size + pad * 2]
    draw.rounded_rectangle(box,
                           radius=radius if radius is not None
                           else (font.size + pad * 2) // 2,
                           fill=fill)
    draw.text((x0 + pad, y0 + pad - int(font.size * 0.08)), text,
              font=font, fill=text_fill)
    return box


def _shadow_text(draw: ImageDraw.ImageDraw, xy, text: str, font,
                 fill=(255, 255, 255)):
    x, y = xy
    draw.text((x + 3, y + 3), text, font=font, fill=(0, 0, 0, 130))
    draw.text((x, y), text, font=font, fill=fill)


def _center_pill(draw, text, font, fill, text_fill, y0, w):
    """Horizontally-centered pill — crop-proof by construction."""
    tw = draw.textlength(text, font=font)
    pad = int(font.size * 0.45)
    x0 = (w - (tw + pad * 2)) // 2
    return _pill(draw, (x0, y0), text, font, fill, text_fill)


def _center_lines(draw, lines, font, w, y0, lh, fill=(255, 255, 255)):
    for line in lines:
        lw = draw.textlength(line, font=font)
        _shadow_text(draw, ((w - lw) / 2, y0), line, font, fill=fill)
        y0 += lh
    return y0


def _fit_banner(draw, text: str, size: int, max_w: int, max_h: int,
                lh_pad: int = 12):
    """v87: text box loki fit — shrink until lines*height fits
    (3-line bottom overflow → footer collide fix)."""
    size = max(28, size)
    while size > 28:
        font = _load_font(size)
        # v386: never accept a truncated ("2026 A ...") headline while a smaller
        # size can still show every word — wrap uncapped, accept only if ≤3 lines.
        lines = _wrap(draw, text, font, max_w, max_lines=99)
        if len(lines) <= 3 and len(lines) * (size + lh_pad) <= max_h:
            return font, lines
        size -= 4
    font = _load_font(size)
    return font, _wrap(draw, text, font, max_w, max_lines=3)



def _pro_polish(img: "Image.Image", w: int, h: int) -> "Image.Image":
    """v244 — advanced thumbnail polish layer (top-website look).

    Text band (x 21%..79%) ni touch cheyyadu — kabatti ye crop lo kuda
    oka letter kuda poodu. Ikkada add ayyedi: diagonal stripe texture,
    corner glow, left accent bar, bottom shadow fade, vignette.
    """
    lay = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    d = ImageDraw.Draw(lay)

    # 1. diagonal stripe texture (top-right corner only)
    for i in range(-2, 26):
        x = int(w * 0.62) + i * 26
        d.line([(x, -40), (x - 190, h + 40)], fill=(255, 255, 255, 12), width=7)

    # 2. corner glow (top-left) — depth
    glow = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    gd = ImageDraw.Draw(glow)
    gd.ellipse([-int(w * 0.22), -int(h * 0.38), int(w * 0.34), int(h * 0.30)],
               fill=(255, 255, 255, 30))
    glow = glow.filter(ImageFilter.GaussianBlur(70))
    lay = Image.alpha_composite(lay, glow)
    d = ImageDraw.Draw(lay)

    # 3. left accent bar (brand signature)
    d.rectangle([0, 0, int(w * 0.012), h], fill=ACCENT + (235,))

    # 4. bottom shadow fade — text ki contrast
    fade = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    fd = ImageDraw.Draw(fade)
    for i in range(int(h * 0.30)):
        y = h - 1 - i
        a = int(70 * (1 - i / (h * 0.30)))
        fd.line([(0, y), (w, y)], fill=(5, 7, 20, a))
    lay = Image.alpha_composite(lay, fade)

    # 5. vignette — edges darken, center pops
    vig = Image.new("L", (w, h), 0)
    ImageDraw.Draw(vig).ellipse(
        [-int(w * 0.18), -int(h * 0.18), int(w * 1.18), int(h * 1.18)], fill=255)
    vig = vig.filter(ImageFilter.GaussianBlur(120))
    dark = Image.new("RGBA", (w, h), (0, 0, 0, 90))
    dark.putalpha(Image.eval(vig, lambda v: 90 - int(v * 90 / 255)))
    lay = Image.alpha_composite(lay, dark)

    return Image.alpha_composite(img, lay)


def _draw_layout(img: Image.Image, draw: ImageDraw.ImageDraw, w: int, h: int,
                 banner_text: str, category: str, variant: str) -> None:
    """v24 layouts — every glyph centered inside the safe band."""
    year = str(date.today().year)
    label_font = _load_font(int(h * 0.044))
    brand_font = _load_font(int(h * 0.036))
    label = banner_english(_pill_label(category, banner_text))
    brand = config.SITE_BRAND
    text = banner_english(banner_text)[:64]
    base_size = int(h * 0.098)

    if variant == "center":
        # soft full-width card behind centered text (magazine style)
        card = [int(w * 0.10), int(h * 0.13), int(w * 0.90), int(h * 0.87)]
        draw.rounded_rectangle(card, radius=26, fill=DARK + (150,))
        draw.rounded_rectangle(card, radius=26, outline=ACCENT + (200,), width=3)
        _center_pill(draw, label, label_font, ACCENT + (250,), (20, 20, 30),
                     int(h * 0.185), w)
        y = int(h * 0.33)
        tf, lines = _fit_banner(draw, text, base_size, int(w * 0.54),
                                int(h * 0.755) - 30 - y)
        y = _center_lines(draw, lines, tf, w, y, tf.size + 12)
        draw.rectangle([w / 2 - 70, y + 14, w / 2 + 70, y + 20], fill=ACCENT)
        _center_lines(draw, [f"{brand}  \u00b7  {year}"], brand_font, w,
                      int(h * 0.755), brand_font.size, fill=(255, 255, 255, 235))
        return

    if variant == "top":
        # top white pill-row over gradient, centered title mid, no band
        _center_pill(draw, f"{label}  \u00b7  {year}", label_font,
                     (255, 255, 255, 240), (25, 25, 45), int(h * 0.085), w)
        y = int(h * 0.32)
        tf, lines = _fit_banner(draw, text, base_size, int(w * 0.54),
                                int(h * 0.80) - 30 - y)
        y = _center_lines(draw, lines, tf, w, y, tf.size + 12)
        draw.rectangle([w / 2 - 80, y + 12, w / 2 + 80, y + 18], fill=ACCENT)
        _center_pill(draw, brand, brand_font, (10, 12, 30, 150),
                     (255, 255, 255, 235), int(h * 0.80), w)
        return

    # ---- default "bottom": gradient top, dark band bottom, ALL centered ----
    panel_y0 = int(h * 0.52)
    draw.rectangle([0, panel_y0, w, h], fill=DARK + (220,))
    draw.line([0, panel_y0, w, panel_y0], fill=ACCENT + (255,), width=4)
    _center_pill(draw, label, label_font, (255, 255, 255, 235),
                 (25, 25, 45), int(h * 0.07), w)
    y0 = panel_y0 + int(h * 0.075)
    tf, lines = _fit_banner(draw, text, base_size, int(w * 0.54),
                            int(h * 0.905) - 30 - y0, lh_pad=10)
    y = _center_lines(draw, lines, tf, w, y0, tf.size + 10)
    draw.rectangle([w / 2 - 70, y + 12, w / 2 + 70, y + 18], fill=ACCENT)
    _center_lines(draw, [f"{brand}  \u00b7  {year}"], brand_font, w,
                  int(h * 0.905), brand_font.size, fill=(255, 255, 255, 210))


def generate_featured_image(
    banner_text: str,
    category: str,
    out_path: Path,
    variant: str = "",
) -> Optional[Path]:
    """Render a 1200x675 featured image. Returns path or None on failure.

    variant: "bottom" | "center" | "top" — empty = auto-rotate (v24).
    """
    try:
        w, h = config.IMAGE_WIDTH, config.IMAGE_HEIGHT
        idx = (_LAST_PALETTE["i"] + 1 + random.randint(0, len(PALETTES) - 2)) % len(PALETTES)
        _LAST_PALETTE["i"] = idx
        c1, c2 = PALETTES[idx]

        if variant not in VARIANTS:
            _LAST_VARIANT["i"] = (_LAST_VARIANT["i"] + 1) % len(VARIANTS)
            variant = VARIANTS[_LAST_VARIANT["i"]]

        base = Image.new("RGB", (w, h))
        px = base.load()
        for y in range(h):
            t = y / (h - 1)
            r = int(c1[0] + (c2[0] - c1[0]) * t)
            g = int(c1[1] + (c2[1] - c1[1]) * t)
            b = int(c1[2] + (c2[2] - c1[2]) * t)
            for x in range(0, w, 4):
                for k in range(4):
                    px[x + k, y] = (r, g, b)

        # decorative translucent circles on an RGBA overlay
        overlay = Image.new("RGBA", (w, h), (0, 0, 0, 0))
        odraw = ImageDraw.Draw(overlay)
        for _ in range(8):
            rad = random.randint(70, 280)
            cx = random.randint(-100, w + 100)
            cy = random.randint(-100, h + 100)
            alpha = random.randint(10, 32)
            odraw.ellipse(
                [cx - rad, cy - rad, cx + rad, cy + rad],
                fill=(255, 255, 255, alpha),
            )
        overlay = overlay.filter(ImageFilter.GaussianBlur(2))
        img = Image.alpha_composite(base.convert("RGBA"), overlay)
        img = _pro_polish(img, w, h)
        draw = ImageDraw.Draw(img)

        _draw_layout(img, draw, w, h, banner_text, category, variant)

        out_path.parent.mkdir(parents=True, exist_ok=True)
        # v81 (§22): format follows extension — .webp (small) default for
        # new posts, explicit .jpg callers (tests/variants) keep JPEG.
        if str(out_path).lower().endswith(".webp"):
            img.convert("RGB").save(str(out_path), "WEBP", quality=82,
                                   method=6)
        else:
            img.convert("RGB").save(str(out_path), "JPEG", quality=86,
                                   optimize=True, progressive=True)
        return out_path
    except Exception:
        log.exception("Featured image generation failed — continuing without image")
        return None
