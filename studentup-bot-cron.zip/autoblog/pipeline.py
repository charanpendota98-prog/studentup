"""Shared publish pipeline — run.py & Telegram approval bot okari okaru vadatam.

publish_article(): SEO enhance + internal links + featured image +
Rank Math meta + WP create + state + notification.
create_from_source(url): fetch source -> Gemini 100% original rewrite -> publish.
"""

import hashlib
import json
import logging
import re
from datetime import date
from html import unescape
from pathlib import Path
from typing import Dict, Optional
from urllib.parse import urlparse

import requests

from . import (config, content_quality, gemini_client, google_quality, image_gen,
               notifier, post_gate, qual, research, rm100, seo, sources, state,
               validator)
from .notifier import esc, send_telegram
from .wordpress_client import WordPressClient

log = logging.getLogger("autoblog.pipeline")


def _save_provenance(article: Dict) -> None:
    """Store source URLs and hashes, never raw/private source text."""
    urls = list(article.get("_source_urls") or [])
    texts = list(article.get("_source_texts") or [])
    if not urls:
        return
    records = []
    for index, url in enumerate(urls):
        text = texts[index] if index < len(texts) else ""
        records.append({
            "id": f"S{index + 1}",
            "url": url,
            "sha256": hashlib.sha256(text.encode("utf-8", "ignore")).hexdigest(),
            "characters": len(text),
        })
    path = config.OUTPUT_DIR / "provenance"
    path.mkdir(parents=True, exist_ok=True)
    (path / f"{article.get('slug', 'post')}.json").write_text(
        json.dumps({
            "title": article.get("title", ""),
            "created": date.today().isoformat(),
            "notebooklm_claims": article.get("_notebooklm_claims", 0),
            "sources": records,
            "official_link_audit": article.get("_official_link_audit", {}),
        }, ensure_ascii=False, indent=2), encoding="utf-8")


def _source_identity_meta(article: Dict) -> Dict[str, str]:
    """Small registered WP meta used for duplicate/update detection.

    Raw evidence stays private. Only normalized URLs, a check date and count
    are exposed so a future source update can locate the same article safely.
    """
    urls = [str(url).strip() for url in (article.get("_source_urls") or []) if str(url).strip()]
    primary = str(article.get("source_url") or (urls[0] if urls else "")).strip()
    if not primary and not urls:
        return {}
    out = {"studentup_source_checked": date.today().isoformat()}
    if primary:
        out["studentup_source_url"] = primary
    if urls:
        out["studentup_source_urls"] = json.dumps(urls[:6], ensure_ascii=False)
    # These fields are written only after _append_official_sources has built a
    # verified evidence map. Never persist the model's raw recruitment URL.
    apply_url = str(article.get("application_url") or "").strip()
    org_url = str(article.get("verified_org_url") or "").strip()
    if sources.is_valid_source_url(apply_url):
        out["studentup_apply_url"] = apply_url
    if sources.is_valid_source_url(org_url):
        out["studentup_org_url"] = org_url
    return out


# ---------------------------------------------------------------- auto category

CATEGORY_RULES = [
    # live-site categories (v14) — specific rules first (tie-break priority)
    # v58: విదేశీ ఉద్యోగాలు — Gulf/abroad jobs, visa, IELTS/PTE, NRI.
    # List MODATI rule (telugu "ఉద్యోగాలు" generic word Central ki vellakudadu;
    # "గల్ఫ్ ఉద్యోగాలు" → Abroad Jobs). Phrases ki 2x weight, Telugu ki 2x.
    ("Abroad Jobs", ["gulf job", "gulf jobs", "abroad job", "abroad jobs",
                     "overseas job", "overseas jobs", "work visa", "visa slot",
                     "visa appointment", "study abroad", "ielts exam", "ielts test",
                     "pte exam", "toefl", "green card", "h1b", "h-1b", "e-migrate",
                     "గల్ఫ్ ఉద్యోగాలు", "విదేశీ ఉద్యోగాలు", "విదేశీ ఉద్యోగ",
                     "దుబాయ్", "సౌదీ", "కువైట్", "ఖతార్", "ఒమన్", "బహ్రెయిన్",
                     "abroad", "overseas", "gulf", "dubai", "abu dhabi", "saudi",
                     "qatar", "kuwait", "oman", "bahrain", "uae", "sharjah",
                     "singapore", "malaysia", "japan", "south korea", "germany",
                     "canada", "australia", "uk ", "usa ", "ielts", "pte",
                     "emigrate", "nri", "passport", "oci", "visa",
                     "విదేశీ", "గల్ఫ్", "వీసా", "ఐఎల్‌టీఎస్", "ప్రవాస"]),
    ("TS Govt Jobs", ["tspsc", "telangana", "ts police", "ts genco", "transco",
                      "తెలంగాణ", "gurukul", "tgpsc"]),
    ("AP Govt Jobs", ["appsc", "andhra", "ap police", "apsrtc", "ap genco",
                      "ఆంధ్రప్రదేశ్", "ap dsc", "grama sachivalayam"]),
    ("Central Govt Jobs", ["ssc", "upsc", "rrb", "ibps", "sbi po", "sbi clerk",
                           "india post", "agniveer", "drdo", "isro", "railway",
                           "central govt", "central government",
                           "కేంద్ర ప్రభుత్వం", "కేంద్ర ఉద్యోగ", "si ", "constable"]),
    ("Software Jobs", ["software", "developer", "engineer", "it jobs",
                       "coding", "full stack", "data analyst", "devops",
                       "testing", "infor", "oracle", "sap", "salesforce",
                       "servicenow", "capgemini", "tech mahindra", "genpact",
                       "virtusa", "hexaware", "zoho", "freshworks", "ibm",
                       "సాఫ్ట్‌వేర్", "సాఫ్ట్‌వేర్ ఇంజనీర్", "సాఫ్ట్‌వేర్ డెవలపర్",
                       "సాఫ్ట్‌వేర్ జాబ్స్", "ఇంజనీర్", "డెవలపర్"]),
    ("Private Jobs", ["tcs", "infosys", "wipro", "hcl", "cognizant",
                      "accenture", "amazon", "deloitte", "microsoft",
                      "fresher", "off campus", "private", "mnc",
                      "ప్రైవేట్ ఉద్యోగ", "ప్రైవేట్ జాబ్స్", "ప్రైవేట్ కంపెనీ", "ప్రైవేట్"]),
    ("Part Time Jobs", ["part time", "part-time", "work from home",
                        "freelance", "data entry", "tutor"]),
    ("Walkin Jobs", ["walkin", "walk-in", "walk in", "direct interview",
                     "job mela", "job fair", "rojgar mela", "జాబ్ మేళా", "వాక్ ఇన్", "రోజ్‌గార్ మేళా"]),
    ("Outsourcing Jobs", ["outsourcing", "contract basis", "contractual",
                          "కాంట్రాక్ట్", "అవుట్‌సోర్సింగ్", "ఔట్‌సోర్సింగ్", "crc", "outsourced",
                          "guest faculty", "honorarium", "తాత్కాలిక ఉద్యోగాలు"]),
    ("Success Stories", ["success story", "success stories", "achiever", "topper",
                         "ranker", "selected candidate", "selected students",
                         "విజయగాథ", "సాధించిన", "టాపర్"]),
    ("Current Affairs", ["current affairs", "జాతీయ", "ప్రస్తుతాంశాలు",
                         "pib", "press release", "news today", "daily news",
                         "government order", "government notification", "scheme",
                         "welfare", "budget", "pm kisan", "kisan", "farmer",
                         "agriculture", "rythu", "women welfare", "mahila",
                         "self help", "pension", "subsidy", "job fair",
                         "కరెంట్ అఫైర్స్", "studytoday news", "పథకం", "రైతు",
                         "మహిళ", "వ్యవసాయం"]),
    ("Upcoming Exams", ["upcoming exam", "exam calendar", "notification coming",
                        "రానున్న పరీక్షలు", "exam schedule", "tentative schedule",
                        "recruitment calendar", "పరీక్షల క్యాలెండర్"]),
    ("Exam Tips", ["exam tips", "preparation strategy", "study plan", "revision",
                   "పరీక్షా చిట్కాలు", "సన్నద్ధత", "how to prepare", "time table",
                   "model paper", "model papers", "previous papers", "mock test",
                   "study material", "materials", "material pdf", "question papers",
                   "స్టడీ మెటీరియల్", "మోడల్ పేపర్లు", "మునుపటి పేపర్లు"]),
    ("Hall Tickets", ["admit card", "admit cards", "hall ticket", "hall tickets", "హాల్ టికెట్", "హాల్ టికెట్లు", "call letter", "పరీక్ష హాల్ టికెట్"]),
    ("Scholarships", ["scholarship", "scholarships", "fellowship", "nsp", "fee reimbursement",
                      "స్కాలర్", "స్కాలర్‌షిప్", "రుసుము", "రుసుము రీయింబర్స్‌మెంట్", "pragati", "saksham", "yasasvi", "epass", "jnanabhumi", "విద్యా దీవెన"]),
    ("Results", ["result", "results", "ఫలిత", "ఫలితాలు", "marks list", "manabadi", "grade",
                 "cutoff", "cut-off", "answer key", "university results", "యూనివర్సిటీ ఫలితాలు", "semester results", "డిగ్రీ ఫలితాలు", "కీలు"]),
    ("Internships", ["internship", "internships", "apprenticeship", "ఇంటర్న్"]),
    ("Online Education", ["admission", "admissions", "counselling", "counseling", "web options",
                          "dost", "eamcet", "eapcet", "icet", "pgecet", "neet counselling", "ప్రవేశ",
                          "ప్రవేశ పరీక్ష", "కౌన్సిలింగ్", "అడ్మిషన్లు", "సీట్ల కేటాయింపు", "seat allotment",
                          "entrance exam", "online mba", "online degree", "course", "syllabus",
                          "preparation", "study plan", "exam date", "పరీక్ష"]),
]


# Generic job words are deliberately *not* enough to decide a taxonomy. A
# headline containing only "job", "vacancy" or "notification" must never
# become Central Govt Jobs. That was the source of the Software → Central bug.
_RULE_GENERIC = {"job", "jobs", "vacancy", "vacancies", "posts", "notification",
                 "recruitment", "bharti", "hiring", "apply", "apply online"}

# These are organisation/exam signals, not generic words. Keep this list
# conservative: a false Central/State label is worse than a manual review.
_CENTRAL_SIGNALS = (
    "ssc", "upsc", "rrb", "railway", "ibps", "sbi po", "sbi clerk",
    "india post", "agniveer", "drdo", "isro", "esic", "epfo", "lic",
    "air force", "airforce", "army", "army public school", "navy", "coast guard", "defence",
    "fddi", "central government", "central govt", "కేంద్ర ప్రభుత్వం", "కేంద్ర ఉద్యోగ",
    # v386: central PSUs / autonomous bodies (live misclassified ECIL as Online Education)
    "ecil", "bdl", "bel ", "bhel", "hal ", "hindustan aeronautics", "ntpc", "ongc", "sail",
    "gail", "iocl", "indian oil", "bpcl", "hpcl", "nmdc", "nlc", "coal india", "barc",
    "npcil", "aai", "airports authority", "rbi", "nabard", "sidbi", "nhai", "nhpc",
    "powergrid", "rites", "ircon", "rvnl", "dmrc", "metro rail", "aiims", "esic", "kvs",
    "kendriya vidyalaya", "navodaya", "nvs", "cisf", "crpf", "bsf", "itbp", "ssb", "capf",
    "nia", "ib acio", "intelligence bureau", "cbi", "ed ", "customs", "income tax",
    "indian bank", "canara bank", "union bank", "bank of baroda", "pnb", "bank of india",
    "central bank of india", "uco bank", "idbi", "nainital bank", "ordnance factory",
    "railway recruitment", "rrc ", "ntpc cbt", "post office", "gds", "employment news",
)
_TS_SIGNALS = (
    "tspsc", "telangana", "ts police", "tg police", "ts genco", "tstransco",
    "transco", "gurukul", "tgpsc", "telangana government", "ts govt",
    "తెలంగాణ", "టీఎస్పీఎస్సీ", "తెలంగాణ ప్రభుత్వం",
    # v386 state corporations/boards
    "singareni", "sccl", "tsrtc", "tgsrtc", "tsnpdcl", "tgnpdcl", "tsspdcl", "tgspdcl",
    "mhsrb", "ts high court", "telangana high court", "tslprb", "tgprb", "tg set", "tgset",
    "ts dsc", "tg dsc", "osmania", "kakatiya university", "ghmc", "hmda", "hyderabad metro water",
    "tgcet", "tsrjc", "tgrjc", "ts model school", "tg model school",
)
_AP_SIGNALS = (
    "appsc", "andhra pradesh", "andhra", "ap police", "apsrtc", "ap genco",
    "aptransco", "ap dsc", "grama sachivalayam", "ap govt", "ఆంధ్రప్రదేశ్",
    "ఏపీపీఎస్సీ", "ఆంధ్రప్రదేశ్ ప్రభుత్వం",
    # v386 state corporations/boards
    "apgenco", "ap high court", "aphc", "apmsrb", "apsche", "aptet", "ap tet", "apcob",
    "apspdcl", "apepdcl", "apcpdcl", "ap srtc", "andhra university", "svu ", "sv university",
    "ap set", "apset", "ward sachivalayam", "apssdc", "ap model school", "aprjc",
)
_SOFTWARE_SIGNALS = (
    "software developer", "software engineer", "frontend", "front-end",
    "backend", "back-end", "full stack", "full-stack", "web developer",
    "data analyst", "data scientist", "machine learning", "devops", "qa tester",
    "software testing", "automation tester", "programmer", "coding job",
    "it job", "it jobs", "python developer", "java developer", "android developer",
    "software trainee", "associate engineer", "cloud engineer", "system engineer",
    "software", "infor", "oracle", "sap", "salesforce", "servicenow",
    "capgemini", "tech mahindra", "genpact", "virtusa", "hexaware", "zoho",
    "freshworks", "ibm", "ltimindtree", "mphasis", "birlasoft",
    # v386: IT services / product companies are Software Jobs (live had TCS/Wipro in Private)
    "tcs", "infosys", "wipro", "hcl", "hcltech", "cognizant", "accenture", "global logic",
    "globallogic", "optum", "deloitte", "microsoft", "google", "amazon sde", "meta ",
    "adobe", "intuit", "nvidia", "qualcomm", "micron", "amd ", "intel ", "cisco", "dell",
    "hp ", "hewlett", "vmware", "broadcom", "uber", "ola ", "swiggy", "zomato", "flipkart",
    "paytm", "phonepe", "razorpay", "cred ", "zeta", "juspay", "mindtree", "persistent",
    "cyient", "coforge", "nagarro", "epam", "ust global", "dxc", "ntt data", "kpit",
    "tata elxsi", "l&t technology", "ltts", "sonata", "mastek", "happiest minds",
    "tcs nqt", "nqt", "wipro elite", "nth ", "infytq", "accenture ase", "capgemini exceller",
    "hackathon", "sde", "sdet", "ui developer", "react developer", "node developer",
    "data engineer", "ai engineer", "ml engineer", "cybersecurity", "network engineer",
    "ఫుల్ స్టాక్", "డెవలపర్", "సాఫ్ట్‌వేర్", "సాఫ్ట్‌వేర్ ఉద్యోగ",
    "సాఫ్ట్‌వేర్ ఇంజనీర్", "సాఫ్ట్‌వేర్ డెవలపర్", "సాఫ్ట్‌వేర్ జాబ్స్", "ఇంజనీర్",
)
_PRIVATE_SIGNALS = (
    "tcs", "infosys", "wipro", "hcl", "cognizant", "accenture", "amazon",
    "deloitte", "microsoft", "google careers", "private company", "private job",
    "mnc", "off campus", "campus hiring", "fresher hiring", "infor", "oracle",
    "sap", "salesforce", "servicenow", "capgemini", "tech mahindra", "genpact",
    "virtusa", "hexaware", "zoho", "freshworks", "ibm", "private",
    "ప్రైవేట్ ఉద్యోగ", "ప్రైవేట్ జాబ్స్", "ప్రైవేట్ కంపెనీ", "ప్రైవేట్",
)
_JOB_CONTEXT = (
    "job", "jobs", "vacancy", "vacancies", "recruitment", "notification",
    "hiring", "career", "careers", "opening", "role", "roles", "apply",
    "salary", "walk-in", "walkin", "engineer", "developer", "trainee",
    "fresher", "drive", "భర్తీ", "ఉద్యోగ", "నియామక", "ఖాళీ",
    "ఇంజనీర్", "డెవలపర్", "సాఫ్ట్‌వేర్", "టెక్",
)


def _has_any(blob: str, signals: tuple[str, ...]) -> bool:
    return any(signal.lower() in blob for signal in signals)


def _rule_weight(word: str) -> float:
    """Keyword specificity for the conservative fallback scorer."""
    w = word.strip().lower()
    if w in _RULE_GENERIC:
        return 0.25
    if " " in w or "-" in w:
        return 2.0
    if not w.isascii():
        return 2.0
    return 1.0


from . import regions  # v221: districts + scheme vocabulary


def classify_category(title: str, text: str = "") -> str:
    """Return one canonical live-site category for a title/source.

    Classification is intent-first, not keyword-count-first:
    - software roles stay in Software Jobs unless an explicit government
      organisation/exam proves that the post belongs in TS/AP/Central;
    - Central Govt Jobs requires an actual central exam/organisation signal;
    - generic words such as *notification* and *vacancy* never create a
      government category by themselves;
    - exam status (calendar, result, hall ticket) and scholarships outrank a
      broad jobs label where that is the reader's real task.
    """
    blob = re.sub(r"\s+", " ", f"{title} {title} {text[:900]}".lower()).strip()
    has_job = _has_any(blob, _JOB_CONTEXT)
    has_software = _has_any(blob, _SOFTWARE_SIGNALS)
    has_central = _has_any(blob, _CENTRAL_SIGNALS)
    has_ts = _has_any(blob, _TS_SIGNALS)
    has_ap = _has_any(blob, _AP_SIGNALS)

    # High-precision non-job intents first. This avoids an "SSC calendar"
    # becoming Central Govt Jobs and an "NSP last date" becoming a job post.
    if _has_any(blob, ("gulf", "abroad", "overseas", "work visa", "visa appointment",
                       "ielts", "pte", "toefl", "emigrate", "nri", "passport",
                       "saudi", "uae", "dubai", "qatar", "kuwait", "oman",
                       "bahrain", "విదేశీ", "గల్ఫ్", "వీసా")):
        return "Abroad Jobs"
    # A press release/current-affairs story about a scholarship is not a
    # scholarship application guide. Keep the six daily-current streams in
    # Current Affairs; actual eligibility/apply/last-date pieces go below.
    if _has_any(blob, ("current affairs", "daily news", "press release", "pib",
                       "government order", "budget", "ప్రస్తుతాంశాలు", "కరెంట్ అఫైర్స్")) and not has_job:
        return "Current Affairs"
    # v221 VIRAL STREAMS — welfare schemes + TS/AP district news.
    # Ivi job notifications kaavu, kaani readers ki chala peddha demand.
    # Job signal unte (recruitment/vacancy/posts) regions.is_scheme() False
    # istundi — so "Rythu Bharosa DEO recruitment" job ge untundi.
    if regions.is_scheme(blob):
        return "Govt Schemes"
    if regions.is_district_news(blob) and not has_job:
        return "District News"
    if _has_any(blob, ("scholarship", "fellowship", "nsp", "pragati", "saksham",
                       "yasasvi", "fee reimbursement", "epass", "e-pass", "స్కాలర్")):
        return "Scholarships"
    if _has_any(blob, ("success story", "success stories", "achiever", "topper",
                       "ranker", "selected candidate", "విజయగాథ", "టాపర్")):
        return "Success Stories"
    if _has_any(blob, ("outsourcing", "contract basis", "contractual", "outsourced",
                       "guest faculty", "honorarium", "అవుట్‌సోర్సింగ్", "కాంట్రాక్ట్")):
        return "Outsourcing Jobs"
    if _has_any(blob, ("walk-in", "walk in", "walkin", "direct interview", "job mela", "job fair", "employment fair", "వాక్-ఇన్")):
        return "Walkin Jobs"
    if _has_any(blob, ("part time", "part-time", "work from home", "freelance",
                       "data entry", "online tutor")):
        return "Part Time Jobs"
    if _has_any(blob, ("supplementary exam", "supplementary exams", "supply exam",
                       "advanced supplementary", "supplementary fee", "సప్లిమెంటరీ")):
        if _has_any(blob, ("supplementary result", "supply result", "ఫలిత")):
            return "Results"
        return "Upcoming Exams"
    if _has_any(blob, ("coming soon", "exam coming", "notification soon", "exam date",
                       "upcoming exam", "upcoming exams", "exam calendar",
                       "exam schedule", "recruitment calendar", "tentative schedule",
                       "రానున్న పరీక్షలు", "పరీక్షల క్యాలెండర్")) and _has_any(blob, ("exam", "పరీక్ష")):
        return "Upcoming Exams"
    if _has_any(blob, ("exam tips", "preparation strategy", "study plan", "revision",
                       "previous papers", "mock test", "how to prepare", "time table",
                       "fitness", "physical test", "ఎలా సిద్ధం", "ఫిట్‌నెస్", "ప్రిపరేషన్",
                       "పరీక్షా చిట్కాలు", "సన్నద్ధత")) and not has_software:
        return "Exam Tips"
    if _has_any(blob, ("hall ticket", "hall tickets", "admit card", "call letter",
                       "హాల్ టికెట్", "అడ్మిట్ కార్డ్")):
        # Recruitment-board admit cards can stay with the state/central jobs
        # archive (the existing site contract); generic exam/university cards
        # use the dedicated Hall Tickets archive.
        if has_ts and _has_any(blob, ("tspsc", "tgpsc", "ts police", "gurukul")):
            return "TS Govt Jobs"
        if has_ap and _has_any(blob, ("appsc", "ap police", "ap dsc", "apsrtc")):
            return "AP Govt Jobs"
        if has_central and _has_any(blob, ("ssc", "upsc", "rrb", "ibps", "sbi", "railway")):
            return "Central Govt Jobs"
        return "Hall Tickets"
    if _has_any(blob, ("result", "results", "scorecard", "merit list", "answer key",
                       "cut-off", "cutoff", "ఫలిత")):
        return "Results"
    if _has_any(blob, ("internship", "internships", "apprenticeship", "apprentice", "ఇంటర్న్", "అప్రెంటిస్")):
        return "Internships"

    # A software role is its own job intent. Government signals are allowed to
    # override it only when the organisation/exam is explicit (e.g. DRDO
    # Software Engineer), never because the text says "notification".
    if has_software:
        explicit_govt = any(g in blob for g in ("drdo", "isro", "bel ", "bhel",
                                                "tspsc", "appsc", "upsc", "ssc",
                                                "rrb", "railway", "ibps", "sbi"))
        if explicit_govt:
            if has_ts and not has_ap and not has_central:
                return "TS Govt Jobs"
            if has_ap and not has_ts and not has_central:
                return "AP Govt Jobs"
            if has_central and not has_ts and not has_ap:
                return "Central Govt Jobs"
        return "Software Jobs"

    # Generic government employment is classified only by a verifiable
    # organisation/exam or an explicit state/central label.
    if has_ts and has_job and not has_ap:
        return "TS Govt Jobs"
    if has_ap and has_job and not has_ts:
        return "AP Govt Jobs"
    if has_central and has_job:
        return "Central Govt Jobs"
    if _has_any(blob, ("current affairs", "daily news", "press release", "pib",
                       "government order", "scheme", "welfare", "budget", "farmer",
                       "agriculture", "women welfare", "ప్రస్తుతాంశాలు", "కరెంట్ అఫైర్స్",
                       "పథకం", "రైతు", "మహిళ")) and not has_job:
        return "Current Affairs"
    if (has_job or _has_any(blob, ("hiring", "drive", "careers", "fresher", "recruit"))) and _has_any(blob, _PRIVATE_SIGNALS):
        return "Private Jobs"

    # v386: anything that is clearly a JOB but matched no organisation goes to
    # Private Jobs — never "Online Education" (live: "Startup Jobs 2026",
    # "ECIL Recruitment" landed there).
    if has_job and _has_any(blob, ("recruitment", "jobs", "job", "vacanc", "hiring", "openings",
                                   "startup", "fresher", "ఉద్యోగ", "నియామక", "భర్తీ", "ఖాళీ")):
        if _has_any(blob, ("govt", "government", "ప్రభుత్వ", "sarkari")):
            if has_ts and not has_ap:
                return "TS Govt Jobs"
            if has_ap and not has_ts:
                return "AP Govt Jobs"
            if has_central or _has_any(blob, ("central", "కేంద్ర")):
                return "Central Govt Jobs"
        return "Private Jobs"

    # Conservative compatibility fallback for older sources. It cannot select
    # Central Govt Jobs from generic words because those were removed from the
    # central rule above.
    best, best_score = "Online Education", 0.0
    for cat, words in CATEGORY_RULES:
        if cat == "Central Govt Jobs":
            words = [w for w in words if w not in _RULE_GENERIC and w not in
                     {"si ", "constable"}]
        score = sum(_rule_weight(w) for w in words if w in blob)
        if score > best_score:
            best, best_score = cat, score
    return best


def classify_source_category(url: str, title: str = "", text: str = "") -> str:
    """Classify a URL-backed article using domain signals before model labels.

    Official TS/AP/central domains are stronger evidence than a generic word
    such as ``notification``. Aggregator URLs fall back to the title/body
    classifier, so a third-party post is never called government merely because
    its publisher is a jobs blog. This is also used when a Telegram URL is
    supplied directly by the owner.
    """
    parsed = urlparse(str(url or ""))
    host = (parsed.netloc or "").lower().replace("www.", "")
    path = (parsed.path or "").lower().replace("-", " ").replace("_", " ")
    url_blob = f"{host} {path}"
    body_blob = f"{title} {text[:1800]}".lower()
    has_job = _has_any(body_blob + " " + url_blob, _JOB_CONTEXT)

    # Specific non-job portals must win before broad government signals.
    if any(x in url_blob for x in ("scholarships.gov.in", "nsp.gov.in", "telanganaepass",
                                   "jnanabhumi", "epass.cgg.gov.in")):
        return "Scholarships"
    if any(x in url_blob for x in ("tspsc.gov.in", "tgpsc.gov.in", "tgdsc",
                                   "tslprb", "tgprb", "tsgenco", "tstransco",
                                   "telangana.gov.in")) and has_job:
        return "TS Govt Jobs"
    if any(x in url_blob for x in ("psc.ap.gov.in", "ap.gov.in", "apprb",
                                   "apcfss", "apsrtc", "aptransco")) and has_job:
        return "AP Govt Jobs"
    if any(x in url_blob for x in ("ssc.gov.in", "upsc.gov.in", "rrb", "indianrailways",
                                   "indiapost.gov.in", "drdo.gov.in", "isro.gov.in",
                                   "fddiindia.com", "fddi.gov.in", "ncs.gov.in")) and has_job:
        return "Central Govt Jobs"
    if _has_any(url_blob, ("job mela", "job fair", "walk in", "walkin", "rojgar mela")):
        return "Walkin Jobs"
    if _has_any(url_blob, ("outsourcing", "contract", "guest faculty")):
        return "Outsourcing Jobs"
    if _has_any(url_blob, ("infor.com", "careers.", "jobs.", "tcs.com", "infosys.com",
                           "wipro.com", "cognizant.com", "accenture.com")) and has_job:
        return "Software Jobs" if _has_any(body_blob, _SOFTWARE_SIGNALS) else "Private Jobs"
    return classify_category(f"{title} {url}", text)


def reconcile_category(article: Dict) -> Dict:
    """Repair a model/category mismatch before taxonomy terms are created.

    A requested source-grid category is authoritative and is handled by the
    caller. For model-generated articles we use the title/focus/source title as
    the classification evidence. In particular, a software role must not be
    silently filed under Central Govt Jobs merely because its title contains
    "notification" or "vacancy".
    """
    proposed = str(article.get("category") or "").strip()
    probe = " ".join(str(article.get(k) or "") for k in
                     ("title", "focus_keyword", "source_title"))
    inferred = classify_source_category(str(article.get("source_url") or ""), probe,
                                        str(article.get("content_html") or ""))
    if not proposed:
        article["category"] = inferred
        return article
    if inferred not in config.CATEGORIES:
        article["category"] = proposed
        return article
    if proposed not in config.CATEGORIES:
        # Migrate only known legacy labels; preserve a deliberate custom term
        # instead of inventing a new WordPress archive.
        legacy = {
            "govt jobs": "Central Govt Jobs",
            "education news": "Current Affairs",
            "exam updates": "Upcoming Exams",
            "admissions": "Online Education",
            "study tips": "Exam Tips",
        }
        alias = legacy.get(proposed.lower())
        if alias:
            article["category"] = inferred if inferred != "Online Education" else alias
        return article
    # v386: the rule classifier is authoritative whenever it is confident
    # (anything but the generic "Online Education" fallback). Live channel
    # showed the model's label surviving against clear evidence: "UFC fitness
    # guide" and "Govt internships" filed under Central Govt Jobs, IT company
    # recruitments under Central Govt Jobs.
    if inferred != "Online Education" and inferred != proposed:
        log.info("CATEGORY FIX: model said %r → rules say %r (%s)", proposed, inferred,
                 str(article.get("title") or "")[:60])
        article["_category_model"] = proposed
        article["category"] = inferred
        return article
    # v391: admissions / counselling stories are NOT jobs (live: "AP PG Medical
    # Admissions 2026 కన్వీనర్ కోటా" filed under Central Govt Jobs).
    _t = str(article.get("title") or "")
    if "Jobs" in proposed and re.search(
            r"admission|counsell?ing|web options|seat allot|కౌన్సెలింగ్|ప్రవేశాలు|ప్రవేశ|సీట్ల కేటాయింపు", _t, re.I) \
            and not re.search(r"recruit|notification.*post|vacanc|ఉద్యోగ|పోస్టుల", _t, re.I):
        log.info("CATEGORY FIX: admissions story %r → Online Education", _t[:60])
        article["_category_model"] = proposed
        article["category"] = "Online Education"
    return article


# v15 tag hygiene: brand/junk tags create cheyakudadu (SEO value undadu)
JUNK_TAGS = {"studentup", "studentup.in", "studentupin", "news", "latest",
             "update", "updates", "breaking", "breaking news", "viral",
             "trending", "2026", "2025", "students", "telugu news"}


def suggest_tags(article: Dict) -> list:
    """v78: keyword-derived auto-tags (5-8 guarantee ki base).

    LLM tags marchipoina/2-3 iste: focus_keyword + secondary + category +
    title acronyms (TSPSC/APPSC/SI...) nunchi build. Junk/dedupe/cap =
    _hygiene tarvata handle (existing rules — no junk tags).
    """
    tags = [str(t).strip() for t in (article.get("tags") or []) if str(t).strip()]
    cands = []
    if article.get("focus_keyword"):
        cands.append(str(article["focus_keyword"]).strip())
    cands += [str(k).strip() for k in (article.get("secondary_keywords") or [])[:4]]
    if article.get("category"):
        cands.append(str(article["category"]).strip())
    title = str(article.get("title") or "")
    cands += re.findall(r"\b[A-Z]{2,}(?:\s*\d+)?\b", title)
    cands += re.findall(r"\b(?:Group|Grade|Level)\s+\d+\b", title, flags=re.I)
    for c in cands:
        if c and c not in tags:
            tags.append(c)
    return tags


def clean_title_text(title: str) -> str:
    """Clean artificial suffixes, unescape entities, and normalize whitespace."""
    if not title:
        return ""
    import html as _html
    t = _html.unescape(_html.unescape(str(title).strip()))   # v391: "&amp;#8211;" live title
    t = t.replace("\u2013", "–").replace("\u2014", "—")
    # Strip artificial promotional/guide suffixes: "— Best Guide", "– Complete Guide", etc.
    t = re.sub(r"\s*(?:[—–-]\s*)?(?:Best|Complete|Ultimate|A to Z|Full)\s+(?:Guide|Details|Update|Information)\b", "", t, flags=re.I)
    t = re.sub(r"\s*[—–-]\s*$", "", t).strip()
    # v383: orphan power-word tails the model bolts onto the H1 to satisfy the
    # Rank Math test — "… 1300 పోస్టులు Official జాబ్", "… Latest", "… (Official)".
    # Live draft 2026-10-20 showed exactly this. The SEO title keeps its power
    # word (rm100.fix_title); the visible headline must read naturally.
    t = re.sub(r"\s*(?:[—–:-]\s*)?\(?\b(?:Official|Latest|New|Direct Link|Latest Update)\)?"
               r"(?:\s+(?:జాబ్|జాబ్స్|అప్‌డేట్|అప్డేట్|Job|Jobs|Update|News))?\s*$", "", t, flags=re.I)
    # v386: no hype in headlines (live: "అద్భుత అవకాశం!", "బంగారు అవకాశం!",
    # "— Complete Details"). Exclamation marks go; clickbait tails go.
    t = re.sub(r"(?:\s*[:—–-])?\s+(?:అద్భుత(?:మైన)? అవకాశం|బంగారు అవకాశం|భారీ అవకాశం|గొప్ప అవకాశం|సువర్ణావకాశం|Complete Details|Full Details|Best Guide|Complete Guide)\s*!*\s*$", "", t, flags=re.I)
    t = re.sub(r"!+", "", t)
    t = re.sub(r"\s*[—–:-]\s*$", "", t).strip()
    return re.sub(r"\s+", " ", t).strip()


def _hygiene(article: Dict) -> Dict:
    """Chinna chinna quality fixes publish mundhe."""
    reconcile_category(article)
    article["tags"] = suggest_tags(article)  # v78 auto-tags (hygiene dedupes)

    # Clean artificial filler suffixes from titles
    title = clean_title_text(article.get("title", ""))
    seo_title = clean_title_text(article.get("seo_title", ""))
    # title too long -> seo_title use cheyi (Rank Math 60-75 chars ideal)
    if len(title) > 85 and seo_title and 20 <= len(seo_title) <= 85:
        article["title"] = seo_title
    else:
        article["title"] = title
    if seo_title:
        article["seo_title"] = seo_title
    # tags: remove a different canonical category tag (e.g. Central Govt Jobs
    # accidentally returned for a Software Jobs article), then dedupe/cap.
    # Category and tags serve different jobs: keep the selected category tag,
    # but never create a second contradictory archive signal.
    category = str(article.get("category") or "").strip().lower()
    canonical_categories = {str(c).strip().lower() for c in config.CATEGORIES}
    conflicting_categories = canonical_categories - ({category} if category else set())
    seen, tags = set(), []
    for t in article.get("tags", []):
        t = str(t).strip()[:32]
        low = t.lower()
        if (not t or low in JUNK_TAGS or low in seen or
                (low in conflicting_categories and category in canonical_categories)):
            continue
        seen.add(low)
        tags.append(t)
    if not tags:
        tags = [article.get("category", "Students"), str(date.today().year)]
    article["tags"] = tags[:8]
    # v87: focus_keyword empty (LLM omit) → title nunchi derive
    # (lekapothe 41-score draft + rm100 kw-fixers anni skip!)
    if not (article.get("focus_keyword") or "").strip():
        toks = [t for t in re.sub(r"[^a-zA-Z0-9 ]", " ", title).split()
                if len(t) > 2][:4]
        article["focus_keyword"] = " ".join(toks) or title[:60]
    # v97: REAL-TIME keyword verification. LLM invent chesina keyword ki
    # (e.g. "... complete details telugu") search demand undakapovachu —
    # Google Autocomplete tho live verify chesi, demand unna phrase tho
    # replace chestam. Network ledu ⇒ verdict "unknown", post block avvadu.
    if getattr(config, "KW_VERIFY", False):
        try:
            from . import keyword_verify

            keyword_verify.verify_and_fix(article)
        except Exception as exc:  # noqa: BLE001 — advisory, never blocks
            log.debug("kw verify skip: %s", exc)
    # Senior-editor SEO hygiene: keep a useful 5–8 phrase keyword family even
    # when Gemini returns too few phrases. These are query intents, not claims,
    # and are never inserted into the article as repetitive filler.
    focus = (article.get("focus_keyword") or "").strip()
    secondary = []
    seen_secondary = set()
    for value in article.get("secondary_keywords") or []:
        phrase = " ".join(str(value).split()).strip()
        key = phrase.casefold()
        if phrase and key != focus.casefold() and key not in seen_secondary:
            seen_secondary.add(key)
            secondary.append(phrase[:90])
    if focus:
        for suffix in ("eligibility", "apply online", "official notification",
                       "documents", "selection process"):
            phrase = f"{focus} {suffix}".strip()
            key = phrase.casefold()
            if len(secondary) >= 8:
                break
            if key not in seen_secondary:
                seen_secondary.add(key)
                secondary.append(phrase[:90])
    article["secondary_keywords"] = secondary[:8]
    # meta description fallback: quick_answer or first para nunchi
    md = (article.get("meta_description") or "").strip()
    if len(md) < 120:
        base = article.get("quick_answer") or validator.strip_tags(
            article.get("content_html", ""))
        base = " ".join(base.split())
        article["meta_description"] = (base[:155].rsplit(" ", 1)[0]) if base else md
    return article


_PG_PUBLISH_TIME_CHECKS = {
    "media", "media_size", "media_alt", "content_image", "img_host",
    "ad_present", "house_ratio",
    "ad_after_para", "ads_txt", "internal_links", "external_auth", "sponsored_label",
    "schema_article", "schema_breadcrumb", "schema_job", "schema_org_link",
    "no_duplicate", "indexnow", "deadline_valid",
}


def _rankmath_gate(article: dict, category: str) -> dict:
    """v64: Rank Math 100 gate — DETERMINISTIC rm100 fixes + LLM refine rounds.

    Flow: rm100.apply (title/meta/slug/TOC/table/FAQ/links/density/transitions)
       → score check → RM_REFINE_ROUNDS varaku LLM refine (content depth, list items)
       → prathi refine tarvata rm100 malli (rewrite structure break cheyyakunda)
       → final score article["_rm100"] lo private preflight ga store chestamu.
         WordPress Rank Math score ni eppudu fabricate/write cheyyamu.

    Mock/no-key flows skip (silently) — score inka compute avutundi.
    """
    if article.get("_mock"):
        try:  # v384: deterministic fixes (dates/headings/FAQ dupes/meta CTA) before RM pass
            from . import det_fix as _df
            _df.apply(article)
        except Exception as _exc:  # noqa: BLE001
            log.debug("det_fix skip: %s", _exc)
        article["_rm100"] = rm100.apply(article) if not article.get("_no_rm100") else None
        return article
    # v65: iterative deterministic passes (score → fix → score) — real-time check
    opt = rm100.optimize(article, target=int(getattr(config, "RM_TARGET", 100) or 100),
                         max_passes=2)
    res = {"after": opt["score"], "before": opt["before"],
           "applied": (opt["passes"][-1]["applied"] if opt["passes"] else [])}
    article["_rm100"] = {"score": res["after"], "before": res["before"],
                         "applied": res["applied"], "passes": len(opt["passes"])}
    article["_rm_pre"] = res["before"]
    target = int(getattr(config, "RM_TARGET", 100) or 100)
    rounds = int(getattr(config, "RM_REFINE_ROUNDS", 2) or 0)
    strict = analyze_rm(article)
    if not config.ai_configured():
        # AI provider key ledu → LLM refine ledu; deterministic rm100 score mattrame
        article["_rm"] = strict
        return article
    for rnd in range(1, rounds + 1):
        if strict["score"] >= target and not strict["fixes"]:
            break
        facts_before: list = []
        if getattr(config, "FACT_STRICT", True) and article.get("_source_texts"):
            facts_before = validator.fact_guard(
                article.get("content_html", ""), article["_source_texts"])
            if facts_before:
                log.warning("FACT GUARD: %d unverified data item(s): %s",
                            len(facts_before), "; ".join(str(x) for x in facts_before[:3]))
        # SUSPECT (data accuracy) fixes eppudu mundu — v66 gate hints venaka
        fixes = [f"SUSPECT data remove/verify cheyandi — {x}" for x in facts_before] + \
                list(strict["fixes"])
        # v66: pin-gate (68 checks) failures ni kuda refine hint ga ivvadam —
        # "blog rasthunnapudu inka chala check cheyali" → writing loop lo ne fix avvali.
        try:
            from . import post_gate as _pg

            early = _pg.run(article)
            hints: list = []
            for row in early["rows"]:
                if (row["ok"] or not row["fix"] or row["scored"] is False
                        or row["id"] in _PG_PUBLISH_TIME_CHECKS):
                    continue
                if row["group"] in ("CONTENT", "SEMANTIC", "SEO"):
                    hints.append(f"GATE {row['id']}: {row['fix']}")
            fixes = fixes[:10] + hints[:4]
        except Exception as exc:  # noqa: BLE001 — gate hint best-effort (publish aapadu)
            log.debug("post_gate early hints skip: %s", exc)
        if not fixes:
            break
        log.info("RankMath %d/100 (target %d) — refine round %d/%d (%d fixes)",
                 strict["score"], target, rnd, rounds, len(fixes))
        try:
            improved = gemini_client.refine_article(article, fixes[:12])
        except Exception as exc:  # noqa: BLE001 — refine best-effort, publish aapadu
            log.warning("Refine round %d failed (%s)", rnd, exc)
            break
        # v85: anti-truncation — improved <70% length = sections lost
        # (refine context cut valla) → reject, original keep.
        # Threshold 2000: real drafts 9000+ chars; test fixtures ~1000
        # (tiny fake-refines legit — guard real-posts ke).
        orig_len = len(article.get("content_html", "") or "")
        new_len = len(improved.get("content_html", "") or "")
        if orig_len > 2000 and new_len < orig_len * 0.7:
            log.warning("Refine truncated (%d → %d chars) — original keep",
                        orig_len, new_len)
            article["_fact"] = facts_before
            break
        rm2 = validator.rankmath_strict(improved, improved.get("content_html", ""))
        facts_after = (validator.fact_guard(improved.get("content_html", ""),
                                            article["_source_texts"])
                       if facts_before else [])
        facts_fixed = bool(facts_before) and not facts_after
        if not (rm2["score"] > strict["score"] or facts_fixed):
            log.info("Refine helped ledu (%s/100 vs %s/100) — original draft keep",
                     rm2["score"], strict["score"])
            article["_fact"] = facts_before
            break
        for k in ("title", "banner_text", "meta_description", "content_html",
                  "tags", "focus_keyword", "seo_title"):
            if improved.get(k):
                article[k] = improved[k]
        article["refined"] = True
        article["_fact"] = facts_after
        log.info("Refine helped: %s -> %s/100 (facts fixed: %s)",
                 strict["score"], rm2["score"], facts_fixed)
        # v64: rewrite tarvata structure malli — TOC/title/meta/links intact
        res2 = rm100.optimize(article, target=target, max_passes=2)
        strict = analyze_rm(article)
        article["_rm100"] = {"score": strict["score"], "before": res["before"],
                             "applied": (res2["passes"][-1]["applied"]
                                         if res2.get("passes") else []),
                             "rounds": rnd}
        log.info("Round %d tarvata: %d/100", rnd, strict["score"])
    article["_rm"] = strict
    # v355: FINAL POLISH — RM + 85-check gate kalipi, fails unte Gemini ki exact
    # fix list → melu ayithe ne accept (owner: "100 times check, 100% perfect").
    try:
        from . import final_polish as _fp

        _fp.polish(article)
        if article.get("_polish"):
            article["_rm"] = analyze_rm(article)
            log.info("FINAL POLISH %s — RM %d · gate %d · fails: %s",
                     "✅ perfect" if article["_polish"]["perfect"] else "⚠️ review",
                     article["_polish"]["after"]["rm"], article["_polish"]["after"]["gate"],
                     ", ".join(article["_polish"]["after"]["fails"][:6]) or "none")
    except Exception:  # noqa: BLE001 — polish fail draft ni aapadu
        log.exception("final polish skip (draft safe)")
    return article


def analyze_rm(article: dict) -> dict:
    return validator.rankmath_strict(article, article.get("content_html", ""))


def publish_article(article: Dict, day: Optional[date] = None) -> Dict:
    """Full publish flow for a generated article dict. Returns WP result."""
    wp = WordPressClient()
    wp.check_connection()

    is_quiz = article.get("article_type") == "quiz"
    # --- QA step 1: HTML sanitize (Gemini bad tags strip) ---
    if is_quiz:
        # v26: quiz block ni memu build chesam (escaped) — sanitize only around it
        from . import quiz_engine as _qe
        article["content_html"] = _qe.sanitize_quiz_content(article["content_html"])
        article = _hygiene(article)
    else:
        article["content_html"] = validator.sanitize_html(article["content_html"])
        article = _hygiene(article)
        # v38: TOP POST hardening (structural only — kotha facts ledu):
        # keyword meta/slug, snippet answer, FAQ extraction, density cap.
        try:  # v391: query-style keyword → natural entity phrase from the title
            from . import kw_align as _ka
            _rep = _ka.align(article)
            if _rep.get("changed"):
                log.info("KW ALIGN: %r → %r", _rep["old"], _rep["new"])
        except Exception:  # noqa: BLE001
            log.exception("kw align skipped (safe)")
        try:
            from . import top_post as _tp
            article, _tp_report = _tp.harden(article)
        except Exception:  # noqa: BLE001 — hardening never blocks publishing
            log.exception("Top-post hardening skipped (safe)")
        # v18: Rank Math STRICT gate (actual panel checks) — low ante refine round
        article = _rankmath_gate(article, article.get("category") or "")

    category_id = wp.get_or_create_term(article["category"], "categories")
    tag_ids = [wp.get_or_create_term(t, "tags") for t in article["tags"]]

    # --- SEO: quick answer + internal links + TOC + schema ---
    recent = wp.get_recent_published(per_page=8)
    same_cat = [p for p in recent if category_id in p.get("categories", [])]
    internal = (same_cat or recent)[:4]
    # Money-page strategy: traffic posts nunchi high-CPC posts ki link priority
    from . import monetize as _mz

    internal = _mz.prioritize_money_pages(internal)[:4]
    # Internal-link fallback: kotha site lo published posts levu ->
    # category archive links istundi (Rank Math internal-link check pass)
    if len(internal) < 2:
        cat_link = wp.get_term_link(category_id, "categories")
        if cat_link:
            internal.append({"link": cat_link,
                             "title": f"{article['category']} – Latest Articles"})
        if len(internal) < 2:
            internal.append({"link": f"{config.WP_SITE}/", "title": "studentup.in – Home"})
    today_str = (day or date.today()).isoformat()
    if is_quiz:
        from . import quiz_engine as _qe
        article["_link"] = ""   # real link publish tarvata telustundi; share bar
        final_html = _qe.finalize_html(   # fallback = site home
            article, internal_links=[
                {"link": p["link"], "title": p["title"]} for p in internal],
            site_url=config.WP_SITE + "/")
    else:
        final_html = seo.enhance(
            article["content_html"],
            focus_keyword=article.get("focus_keyword", ""),
            internal_links=[{"link": p["link"], "title": p["title"]} for p in internal],
            external_links=article.get("external_links", []),
            quick_answer=article.get("quick_answer", ""),
            faq=article.get("faq", []),
            date_str=today_str,
            slug=article["slug"],
            title=article["title"],
            description=article["meta_description"],
            category=article.get("category", ""),
            source_domains=article.get("_source_domains"),
            list_items=article.get("list_items") if article.get("article_type") == "listicle" else None,
            recruitment=article.get("recruitment"),
        )
    # In-content ad hard gate: before AdSense approval no ad spaces are added,
    # even if an old shortcode remains in .env by mistake.
    if config.AD_SHORTCODE and getattr(config, "ADSENSE_APPROVED", False):
        final_html = seo.insert_ad_shortcodes(
            final_html, config.AD_SHORTCODE,
            max_ads=config.MAX_AD_SLOTS, cls_safe=config.AD_CLS_WRAPPER)
    # revenue blocks: affiliate section + channel CTA (schema mundu insert)
    from . import monetize

    if not is_quiz:
        final_html = monetize.append_blocks(final_html, article)
        # v43: AD MANAGER — owner ads (college banners, shop, services).
        # Runs AFTER monetize blocks so the bottom slot + link-adjacency
        # safety check see every real <a> that exists. No-op when inventory
        # empty/missing or AD_MANAGER_ENABLED=0 (publishing never blocked).
        try:
            from . import ad_manager as _admgr
            final_html, _ad_report = _admgr.inject(final_html, article)
            article["_ads"] = _ad_report
        except Exception:  # noqa: BLE001 — owner ads must never block publish
            log.exception("Ad manager inject skipped (safe)")
            article["_ads"] = []

    # v44: DEEP POST ENGINE — cross-source verification + private report;
    # optional visible analysis is reserved for internal/debug exports.
    if not is_quiz and getattr(config, "DEEP_POST_ENABLED", True):
        try:
            from . import deep_research as _dr

            deep_sources = article.get("_deep_sources") or []
            if len(deep_sources) >= int(getattr(config, "DEEP_MIN_SOURCES", 2)):
                _report = _dr.build_report(
                    article.get("title", ""), deep_sources,
                    notebooklm_brief=article.get("_notebooklm_brief", ""),
                    target_year=article.get("_target_year"))
                # Cross-source analysis is retained for gates and the private
                # ledger. It is not printed as a confidence/source table in a
                # normal StudentUp article.
                if not getattr(config, "PUBLIC_EDITORIAL_CLEAN", True):
                    final_html = _dr.inject_deep(final_html, _report)
                article["_deep"] = _report
                _hard, _warn = _dr.gate_post(final_html, _report, live=False)
                article["_deep_flags"] = ([f"DEEP: {h}" for h in _hard] +
                                          [f"DEEP?: {w}" for w in _warn])
                log.info("v44 deep: confidence %s/100 · conflicts=%d · gaps=%d",
                         _report.get("confidence"),
                         len(_report.get("conflicts", [])),
                         len(_report.get("gaps", [])))
        except Exception:  # noqa: BLE001 — deep layer must never block publish
            log.exception("Deep post engine skipped (safe)")
            article["_deep"] = None

    # Source audit is explicit even when research failed; no vague "verified"
    # claim without a count of independent domains and official sources.
    try:
        from . import deep_research as _dr_source

        article["_source_audit"] = _dr_source.audit_source_set(article)
        log.info("Source audit: %s", _dr_source.format_source_audit(
            article["_source_audit"]))
    except Exception:
        log.exception("source audit failed")
        article["_source_audit"] = {"applicable": bool(article.get("source_url")),
                                    "ok": False, "flags": ["SOURCE-AUDIT-FAILED"]}

    # Public article surface: keep the writing, useful SEO structure and
    # verified links, but remove automation/source-count wrappers. The source
    # URLs and hashes remain in the private provenance ledger.
    if getattr(config, "PUBLIC_EDITORIAL_CLEAN", True):
        final_html = seo.clean_public_article(final_html)

    # --- reader-first language + anti-filler audit ---
    # Standard job/exam terms stay in English script; repeated/sodi prose is
    # measured separately from SEO so keyword padding can never look "good".
    final_html, article["_content_quality"] = content_quality.polish_and_audit(
        final_html, article.get("focus_keyword", ""))
    log.info("Reader quality %s/100 · filler=%s · flags=%s",
             article["_content_quality"]["score"],
             article["_content_quality"]["filler_hits"],
             article["_content_quality"]["flags"] or "none")

    # --- QA step 2: validation score + originality proof ---
    qa = validator.validate_article(article, final_html)
    article["_qa"] = qa
    article["_rm"] = validator.rankmath_strict(article, final_html)
    if not article.get("_source_texts") and article.get("_deep_sources"):
        # v78: rewrite path (_deep_sources) nunchi kuda _orig score —
        # live originality gate publish + rewrite rendu ki uniform (None kaadu).
        _st = []
        for _s in article["_deep_sources"]:
            _t = getattr(_s, "text", None)
            if _t is None and isinstance(_s, dict):
                _t = _s.get("text", "")
            if _t:
                _st.append(_t)
        article["_source_texts"] = _st
    if article.get("_source_texts"):
        article["_orig"] = validator.originality_score(
            final_html, article["_source_texts"])
    # v104: claim provenance + original practical value ledger. This does not
    # reward word count; it records source support and user-helpful signals.
    try:
        from . import editorial_value as _ev

        _ledger = _ev.build_ledger(article, final_html,
                                   article.get("_deep_sources") or [])
        article["_editorial_value"] = _ledger
        article["_editorial_flags"] = _ev.gate(
            _ledger, minimum=int(getattr(config, "EDITORIAL_VALUE_MIN", 55)))
        log.info("Editorial value %s/100 (%s) · flags=%s",
                 _ledger["score"], _ledger["grade"],
                 article["_editorial_flags"] or "none")
    except Exception:  # noqa: BLE001 — ledger advisory; other gates remain
        log.exception("editorial value ledger skipped (safe)")

    article["_google_quality"] = google_quality.audit(article, final_html, live=False)
    log.info("Google people-first self-assessment %s/100 · flags=%s",
             article["_google_quality"]["score"],
             article["_google_quality"]["flags"] or "none")
    # Deficient drafts remain available for correction; the live gate below is
    # strict. This preserves evidence instead of silently discarding research.

    # v38: TOP POST SCORE — measurable on-page quality (30+ weighted checks).
    # Quiz posts ki skip (interactive format different rules tho untundi).
    if not is_quiz:
        try:
            from . import top_post as _tp
            article["_top"] = _tp.score_top_post(article, html=final_html)
            log.info("Top Post Score %s/100 %s — failed: %s",
                     article["_top"]["score"], article["_top"]["grade"],
                     ", ".join(article["_top"]["failed"][:4]) or "none")
        except Exception:  # noqa: BLE001
            log.exception("Top-post scoring failed (safe)")
    log.info("QA score %s/100 (words=%d) originality=%s%% issues=%s",
             qa["score"], qa["words"], article.get("_orig", "n/a"),
             qa["issues"][:3] or "none")
    # v35: never let an unreviewed/under-validated article go straight live.
    # Drafts remain available for a human to fix; only direct publish is blocked.
    live_status = str(article.get("_force_status") or
                      getattr(config, "DEFAULT_POST_STATUS", "draft")).lower()
    if (getattr(config, "AUTOMATION_DRAFT_ONLY", True)
            and live_status == "publish"
            and not article.get("_manual_publish_approved")):
        log.warning("AUTOMATION_DRAFT_ONLY: automatic publish downgraded to review draft")
        article["_force_status"] = "draft"
        live_status = "draft"
    if live_status == "publish":
        reviewer = (getattr(config, "EDITORIAL_REVIEWER", "") or "").strip()
        if not reviewer:
            raise RuntimeError(
                "LIVE-PUBLISH BLOCKED: EDITORIAL_REVIEWER is empty; "
                "a named human must review the draft and official source first")
        article["_google_quality"] = google_quality.audit(
            article, final_html, live=True)
        if article["_google_quality"]["flags"]:
            raise RuntimeError(
                "LIVE-PUBLISH BLOCKED: Google people-first self-assessment — "
                + "; ".join(article["_google_quality"]["flags"][:5]))
        min_qa = max(0, min(100, int(getattr(config, "PUBLISH_QA_MIN_SCORE", 80))))
        if qa["score"] < min_qa:
            raise RuntimeError(
                f"LIVE-PUBLISH BLOCKED: local QA {qa['score']}/100 < {min_qa}; "
                "save as draft, fix the listed issues, then review manually")
        if article.get("_orig") is not None:
            min_orig = float(getattr(config, "PUBLISH_ORIGINALITY_MIN", 72))
            if float(article["_orig"]) < min_orig:
                raise RuntimeError(
                    f"LIVE-PUBLISH BLOCKED: originality {article['_orig']}% < "
                    f"{min_orig:g}% — source-backed rewrite needs editorial work")
        reader = article.get("_content_quality") or {}
        if (getattr(config, "CONTENT_QUALITY_BLOCK", True)
                and reader.get("flags")):
            raise RuntimeError(
                "LIVE-PUBLISH BLOCKED: repetitive/filler language — "
                + "; ".join(reader["flags"][:4]))
        source_audit = article.get("_source_audit") or {}
        if (getattr(config, "SOURCE_AUDIT_BLOCK", True)
                and source_audit.get("applicable") and not source_audit.get("ok")):
            raise RuntimeError(
                "LIVE-PUBLISH BLOCKED: source verification — "
                + "; ".join(source_audit.get("flags", [])[:5]))
        # v108: media duplicate/licence ledger flags live review too.
        if article.get("_media_flags"):
            raise RuntimeError(
                "LIVE-PUBLISH BLOCKED: media asset review — "
                + "; ".join(article["_media_flags"][:3]))
        # v104: a source summary with unsupported claims or no practical value
        # is not enough for live publishing. Draft review still receives flags.
        if (getattr(config, "EDITORIAL_VALUE_BLOCK", True)
                and article.get("_editorial_flags")):
            raise RuntimeError(
                "LIVE-PUBLISH BLOCKED: editorial provenance/value review — "
                + "; ".join(article["_editorial_flags"][:4]))
        # v38: Top Post gate — on-page quality measured, not claimed.
        if article.get("_top") is not None:
            from . import top_post as _tp

            ok_live, detail = _tp.publish_gate(article, live=True)
            if not ok_live:
                raise RuntimeError(
                    f"LIVE-PUBLISH BLOCKED: {detail}. Draft ga save chesi "
                    "fix cheyyandi (run.py --score-post <file>)")
            log.info("Top-post gate ✔ %s", detail)
        # v41: site-audit root-cause gate — junk HTML, unregistered shortcode,
        # duplicate TOC anchors, PII, stale dates, Govt/Private category mismatch,
        # empty title/excerpt, featured image — ivi live publish block chestayi.
        from . import site_audit as _sa

        ok_site, detail_site = _sa.article_gate(
            article, html=final_html, category=article.get("category", ""), live=True)
        if not ok_site:
            raise RuntimeError(
                f"LIVE-PUBLISH BLOCKED: {detail_site}")
        log.info("v41 site gate ✔ %s", detail_site)
        # v44: DEEP GATE — source conflicts / date inconsistency / stale
        # years block live publish (drafts carry the flags for review).
        from . import deep_research as _dr

        ok_deep, detail_deep = _dr.publish_gate(article, html=final_html,
                                                live=True)
        if not ok_deep:
            raise RuntimeError(
                f"LIVE-PUBLISH BLOCKED: {detail_deep}. Draft ga save chesi "
                "official source tho fix cheyyandi (run.py --deep-research)")
        log.info("v44 deep gate ✔ %s", detail_deep)
    try:
        _save_provenance(article)
    except OSError:
        log.warning("Provenance sidecar could not be saved", exc_info=True)
    try:  # v19: dup-guard memory (scaled-content protection for FUTURE posts)
        state.save_fingerprint(config.STATE_PATH, article["slug"],
                               validator.fingerprint_tokens(final_html))
    except Exception as exc:  # noqa: BLE001 — best-effort (silent kaadu)
        log.debug("publish_article skip: %s", exc)

    # --- featured image (alt text lo focus keyword) ---
    # Keep a private prompt manifest for an optional image-capable model. The
    # current deterministic Pillow renderer remains the safe default; an AI
    # model may create the visual background, but exact verified text/facts are
    # always rendered after generation and never trusted from the image model.
    try:
        from .thumbnail_prompt import build_prompt as _thumbnail_prompt
        article["_thumbnail_prompt"] = _thumbnail_prompt(article)
    except Exception:
        log.debug("thumbnail prompt manifest unavailable", exc_info=True)
    image_path = Path(config.OUTPUT_DIR / "images" / f"{article['slug']}.webp")
    media_id = None
    if config.IMAGE_ENABLED:
        fk = article.get("focus_keyword") or article["banner_text"]
        year = article.get("year", date.today().year)
        if image_gen.generate_featured_image(article["banner_text"], article["category"], image_path):
            article["_image_path"] = str(image_path)
            alt_text = seo.image_alt(fk, article.get("category", ""), year)
            # v96: SEO thumbnail FILE NAME (keyword-category-year.webp) —
            # slug-only name kanna Google Images/Discover ki better context.
            img_name = seo.image_filename(fk, article.get("slug", ""),
                                          article.get("category", ""), year,
                                          ext=image_path.suffix.lstrip(".") or "webp")
            article["_media_filename"] = img_name
            media_id = wp.upload_media(
                image_path,
                title=article["title"],
                alt_text=alt_text,
                filename=img_name,
            )
            # v38: Top Post Score image-alt check ee alt text ni verify chestundi
            if media_id:
                article["_media_alt"] = alt_text
                article["_media_url"] = getattr(wp, "last_media_url", "")
            # v94: Article JSON-LD ki `image` (REQUIRED for Google Article rich
            # results + Discover large card). Schema upload ki MUNDU generate
            # ayyindi, anduke ippudu patch chestunnamu (idempotent + safe).
            if media_id and getattr(wp, "last_media_url", ""):
                try:
                    final_html = seo.attach_schema_image(
                        final_html, wp.last_media_url, 1200, 675)
                    log.info("v94 schema image attach: %s", wp.last_media_url)
                except Exception:  # noqa: BLE001 — schema patch fail publish aapadu
                    log.exception("v94 schema image attach skip (publish safe)")
            # v95: content LOPALA image (keyword alt) — Rank Math "Focus Keyword
            # in Image Alt" + Discover in-article image + engagement. Idempotent
            # (html lo <img> unte no-op), CLS-safe (width/height), lazy load.
            if media_id and getattr(wp, "last_media_url", ""):
                try:
                    final_html = seo.attach_inline_image(
                        final_html, wp.last_media_url, alt_text,
                        caption=article.get("title", "")[:120], width=1200, height=675)
                    log.info("v95 inline figure attach: %s", wp.last_media_url)
                except Exception:  # noqa: BLE001 — figure fail publish aapadu
                    log.exception("v95 inline figure skip (publish safe)")
            # v247: RENDO in-article image (deep-scroll engagement) — pedda
            # articles ki matrame (3+ h2), vere alt tho, idempotent.
            if media_id and getattr(wp, "last_media_url", ""):
                try:
                    final_html = seo.attach_second_image(
                        final_html, wp.last_media_url,
                        "%s — %s" % (article.get("focus_keyword", "")[:60],
                                     article.get("category", "")[:40]),
                        caption="", width=1200, height=675)
                except Exception:  # noqa: BLE001 — publish aapadu
                    log.exception("v247 second figure skip (publish safe)")
            # v247: source-backed summary table (facts unte matrame; guess ledu)
            try:
                final_html = seo.ensure_summary_table(
                    final_html, article.get("recruitment"))
            except Exception:  # noqa: BLE001 — publish aapadu
                log.exception("v247 summary table skip (publish safe)")
            # v251: citation JSON-LD — AI/answer engines ki "ee page ye
            # official sources meeda build ayindi" ane signal (verified
            # links matrame; links lekapothe emi add kaadu).
            try:
                final_html = seo.attach_citation_schema(
                    final_html, article.get("external_links"))
            except Exception:  # noqa: BLE001 — publish aapadu
                log.exception("v251 citation schema skip (publish safe)")

            # v108: image provenance/licence/hash ledger before local cleanup.
            # Generated-local asset ki kuda evidence undali; duplicate hash ayithe
            # live gate review ki flag chestam.
            try:
                from . import media_ledger as _ml

                _asset = _ml.record(
                    image_path, article.get("slug", ""), alt_text,
                    media_id=media_id, url=getattr(wp, "last_media_url", ""),
                )
                _dup = _ml.duplicate_hash(_asset["sha256"], article.get("slug", ""))
                if _dup:
                    article["_media_flags"] = [f"DUPLICATE-MEDIA: {_dup}"]
                article["_media_ledger"] = _asset
            except Exception:  # noqa: BLE001 — image ledger fail is review flag
                log.exception("media ledger skip (publish gate review)")
                article["_media_flags"] = ["MEDIA-LEDGER-UNAVAILABLE"]

            # disk full avvakunda — upload ayyaka local file delete
            if media_id and not config.KEEP_IMAGES:
                image_path.unlink(missing_ok=True)

    # --- Rank Math meta (plugin active unte) ---
    meta = None
    if config.RANK_MATH_META_ENABLED:
        meta = seo.rankmath_meta(
            focus_keyword=article.get("focus_keyword", article["title"][:60]),
            description=article["meta_description"],
            seo_title=article.get("seo_title") or article["title"],
            secondary_keywords=article.get("secondary_keywords", []),
            slug=article.get("slug", ""),
        )
        # Keep the exact delivery manifest with the candidate. This is not
        # rendered in the article; it lets the create/update path and tests
        # prove which fields were intended for WordPress.
        article["_rankmath_meta"] = dict(meta)

    # --- v72: qualification auto-tag (site filter: 10th · 10+2 · డిగ్రీ · పీజీ) ---
    if meta is not None:
        try:
            qmeta = qual.post_meta(article)
            if qmeta:
                meta.update(qmeta)
                log.info("v72 qual tag → %s", qual.describe(article))
        except Exception:  # noqa: BLE001 — tag fail publish aapadu (theme kuda auto detects)
            log.exception("v72 qual tag skip (publish safe)")
    # Source identity is registered even when Rank Math metadata is disabled;
    # it powers safe in-place updates and source freshness checks.
    source_meta = _source_identity_meta(article)
    if source_meta:
        if meta is None:
            meta = {}
        meta.update(source_meta)
        article["_source_identity"] = dict(source_meta)

    # --- v77 ORIGINALITY: donor sources vs final article (REAL copy %, not claim) ---
    try:
        _srcs = []
        for _s in (article.get("_deep_sources") or []):
            _t = getattr(_s, "text", None)
            if _t is None and isinstance(_s, dict):
                _t = _s.get("text", "")
            if _t:
                _srcs.append(_t)
        article["_originality"] = validator.rewrite_distance(final_html, _srcs) \
            if _srcs else {"overlap": 0.0, "fresh": 1.0, "verdict": "no-sources"}
        log.info("ORIGINALITY fresh=%s overlap=%s (%s)",
                 article["_originality"]["fresh"], article["_originality"]["overlap"],
                 article["_originality"]["verdict"])
    except Exception:  # noqa: BLE001 — score fail publish aapadu
        log.exception("originality skip (publish safe)")
        article["_originality"] = {"overlap": 0.0, "fresh": 1.0,
                                   "verdict": "skip"}
    # --- v65 PIN-TO-PIN GATE: certificate + critical block (live publish mattrame) ---
    is_live = live_status == "publish"
    gate = ({"score": 0, "passed": 0, "total": 0, "critical_fails": [], "block": False,
             "cert_id": "mock", "rows": [], "words": 0, "rankmath": 0,
             "title": article.get("title", ""), "slug": article.get("slug", ""),
             "date": date.today().isoformat()}
            if article.get("_mock") else
            post_gate.run(article, final_html, media_id=media_id, image_path=image_path))
    article["_gate"] = gate
    try:
        paths = post_gate.write_certificate(gate) if not article.get("_mock") else {}
        article["_cert"] = paths.get("md", "")
        log.info("PIN GATE %s/100 · %s/%s checks · critical: %s", gate["score"],
                 gate["passed"], gate["total"], gate["critical_fails"] or "none")
    except Exception:  # noqa: BLE001 — certificate fail publish aapadu
        log.exception("certificate write skip (publish safe)")
    try:
        state.meta_set(config.STATE_PATH, "last_cert",
                       f"{gate['cert_id']}:{gate['score']}")
    except Exception as exc:  # noqa: BLE001 — best-effort (silent kaadu)
        log.debug("publish_article skip: %s", exc)
    if gate["critical_fails"] and gate["block"] and is_live and not article.get("_mock"):
        msg = (f"⛔ PIN GATE BLOCK — {article.get('title', '')[:60]}\n"
               f"critical: {', '.join(gate['critical_fails'])}\n"
               "(fix chesi malli run cheyandi · PIN_GATE_BLOCK=0 tho off)")
        log.error("PIN GATE BLOCK: %s", ", ".join(gate["critical_fails"]))
        try:
            send_telegram(msg)
        except Exception as exc:  # noqa: BLE001 — best-effort (silent kaadu)
            log.debug("publish_article skip: %s", exc)
        return {"error": "pin_gate", "detail": msg, "gate": gate}
    # Two-phase live publish: first create a private draft, verify that the
    # official Rank Math fields really landed, and only then make it public.
    # A missing/outdated SEO bridge can no longer produce another live 23/100
    # post with empty Focus Keyword / SEO title / Description fields.
    requested_status = str(article.get("_force_status") or
                           getattr(config, "DEFAULT_POST_STATUS", "draft")).lower()
    stage_for_seo = requested_status == "publish"
    _duplicate_title_guard(article, wp)
    result = wp.create_post(
        title=article["title"],
        content_html=final_html,
        slug=article["slug"],
        category_id=category_id,
        tag_ids=tag_ids,
        excerpt=article["meta_description"],
        media_id=media_id,
        status="draft" if stage_for_seo else requested_status,
        meta=meta,
    )
    if result.get("id") and not article.get("_mock"):
        try:  # v362 draft watchdog clock
            from . import ops
            ops.record_draft(int(result["id"]))
        except Exception:  # noqa: BLE001
            pass
    # v63: SEO fields nijamainaa land ayyaya? (silent-fail pattadam — "mistake lekunda")
    if stage_for_seo and not meta:
        result["seo_meta_missing"] = ["Rank Math meta generation disabled"]
        log.error("Live publish blocked: RANK_MATH_META_ENABLED is off")
    if meta and result.get("id") and not article.get("_mock"):
        try:
            required_seo = [k for k in meta if k.startswith("rank_math_")]
            # verify_meta is the legacy/core read; verify_rankmath_meta adds
            # bridge readback so a hidden REST field is not reported as empty.
            landed = wp.verify_rankmath_meta(result["id"], required_seo)
            missing = [k for k, ok in landed.items() if not ok]
            if missing and not article.get("_mock"):
                # Generic wp/v2 meta schema failed: use the narrow authenticated
                # theme bridge, then read back from WordPress for proof. The
                # bridge read is important because some Rank Math versions do
                # not expose registered meta in the normal post response.
                wp.write_seo_meta(result["id"], meta)
                landed = wp.verify_rankmath_meta(result["id"], required_seo)
                missing = [k for k, ok in landed.items() if not ok]
            article["_rankmath_landed"] = dict(landed)
            result["seo_meta_persisted"] = not missing
            result["seo_meta_keys"] = required_seo
            if missing:
                log.warning("Rank Math meta land avvaledu: %s (id=%s) — theme seo-bridge "
                            "activate cheyandi (wordpress-theme/studentup/inc/seo-bridge.php)",
                            ", ".join(missing), result["id"])
                result["seo_meta_missing"] = missing
                try:
                    notifier.send_telegram(
                        "⚠️ <b>SEO meta WAR</b> — post %s lo %s land avvaledu.\n"
                        "Fix: WP theme (StudentUp) active undo chudandi (SEO bridge)."
                        % (result["id"], ", ".join(missing)))
                except Exception as exc:  # noqa: BLE001 — best-effort (silent kaadu)
                    log.debug("publish_article skip: %s", exc)
            else:
                log.info("Rank Math meta verified ✔ (id=%s)", result["id"])
                if stage_for_seo:
                    # The local validator is only a preflight. A live post is
                    # promoted only when WordPress/Rank Math returns its real
                    # stored score, and that value is exactly the configured
                    # target. Missing bridge/plugin readback remains draft.
                    live_rankmath = wp.read_rankmath_state(result["id"])
                    live_score = live_rankmath.get("rank_math_ui_score")
                    result["rank_math_ui_score"] = live_score
                    article["_rank_math_state"] = live_rankmath
                    require_live = getattr(config, "RM_REQUIRE_LIVE_SCORE", True)
                    live_min = int(getattr(config, "RM_LIVE_MIN_SCORE", 80) or 80)
                    if require_live and (live_score is None or live_score < live_min):
                        result["rank_math_live_verified"] = False
                        result["rank_math_live_min_score"] = live_min
                        result["live_publish_blocked_reason"] = (
                            "Actual WordPress Rank Math score unavailable or below live minimum: "
                            f"{live_score!r} (minimum {live_min}; target {getattr(config, 'RM_TARGET', 100)})"
                        )
                        log.error("Live publish blocked: %s", result["live_publish_blocked_reason"])
                        try:
                            notifier.send_telegram(
                                "⚠️ <b>LIVE PUBLISH BLOCKED</b> — Rank Math actual score was "
                                f"<b>{live_score!r}</b>, not the target. Draft remains in WordPress."
                            )
                        except Exception:  # noqa: BLE001 — notification cannot unlock a post
                            log.debug("Rank Math block notification failed", exc_info=True)
                    else:
                        result["rank_math_live_verified"] = True
                        result["rank_math_live_min_score"] = int(getattr(config, "RM_LIVE_MIN_SCORE", 80) or 80)
                        result.update(wp.set_post_status(result["id"], "publish"))
                        log.info("SEO + actual Rank Math score verified; draft promoted to publish ✔ (id=%s)",
                                 result["id"])
        except Exception:
            # In two-phase mode the post is still a draft, so a bridge/readback
            # failure is safe and cannot trigger the public-channel notification.
            log.exception("meta verify failed; staged post remains draft")
    if result.get("id") and hasattr(wp, "read_rankmath_state"):
        try:
            rankmath_state = wp.read_rankmath_state(result["id"])
            result["rank_math_ui_score"] = rankmath_state.get("rank_math_ui_score")
            article["_rank_math_state"] = rankmath_state
            if result["rank_math_ui_score"] is None:
                log.info("Official Rank Math stored UI score unavailable; no estimate reported")
            else:
                log.info("Rank Math stored UI score (read-only): %s/100",
                         result["rank_math_ui_score"])
        except Exception:
            log.exception("Rank Math read-only state unavailable")
    if article.get("_gate_warnings") and result.get("id"):
        # v319: remember so the Telegram Publish button refuses until edited
        state.meta_set(config.STATE_PATH, f"gate:warn:{result['id']}",
                       " | ".join(article["_gate_warnings"])[:900])
    state.record_post(config.STATE_PATH, article["title"], article["slug"],
                      article["category"], result["link"], result["status"],
                      qa_score=(article.get("_qa") or {}).get("score"),
                      orig_score=article.get("_orig"), wp_id=result.get("id"))
    state.bump_today_count(config.STATE_PATH, day or date.today())
    if article.get("source_url"):
        state.mark_source_done(config.STATE_PATH, article["source_url"], result.get("id"))
    try:
        state.meta_cleanup(config.STATE_PATH)  # purana rojuvella keys tidy
    except Exception as exc:  # noqa: BLE001 — best-effort (silent kaadu)
        log.debug("publish_article skip: %s", exc)

    log.info("POST CREATED ✔ id=%s status=%s link=%s",
             result.get("id"), result.get("status"), result.get("link"))
    if result.get("status") == "publish":
        _after_publish_push(article, result)
    try:
        notifier.notify_new_post(article, result)
    except Exception:
        log.exception("Notification failed (post safe ga save ayyindi)")
    return result


def _after_publish_push(article: Dict, result: Dict) -> None:
    """Publish ayyaka instant traffic/indexing push (best-effort)."""
    # 1) Instant indexing: IndexNow (Bing/Yandex) + Google Indexing API (JobPosting)
    try:
        from . import indexing

        idx = indexing.submit_published(article, result.get("link", ""))
        article["_indexing"] = idx
        article["_indexnow"] = bool(idx.get("indexnow"))
        if idx.get("google"):
            log.info("Google Indexing API ✔ (JobPosting) %s", result.get("link", ""))
    except Exception as exc:  # noqa: BLE001 — indexing best-effort (publish aapadu)
        log.warning("Indexing push fail: %s", exc)
    # 2) v305: Web Push — theme queue lo ee post undi (publish hook) → ventane subscribers ki
    try:
        from . import webpush as _wp

        if _wp.keys_available():
            _wp.kick("publish")
    except Exception as exc:  # noqa: BLE001
        log.warning("Web push kick fail: %s", exc)
    # Channel broadcast is centralized in notifier.notify_new_post(), which
    # runs after this indexing step. Keeping one owner here prevents duplicate
    # channel posts for direct live runs.
    except Exception:
        log.exception("Channel auto-post failed")


def _source_dict(source) -> dict:
    """Return only serialisable source evidence fields."""
    if isinstance(source, dict):
        return source
    return {
        "url": getattr(source, "url", ""),
        "title": getattr(source, "title", ""),
        "canonical_url": getattr(source, "canonical_url", ""),
        "outbound_links": getattr(source, "outbound_links", []) or [],
        "outbound": getattr(source, "outbound", []) or [],
    }


def _url_key(value: str) -> str:
    """Compare URLs conservatively: scheme/host case and trailing slash only."""
    try:
        parsed = urlparse(str(value or "").strip())
        if parsed.scheme not in ("http", "https") or not parsed.netloc:
            return ""
        path = parsed.path or "/"
        if path != "/":
            path = path.rstrip("/") or "/"
        return f"{parsed.scheme.lower()}://{parsed.netloc.lower()}{path}{('?' + parsed.query) if parsed.query else ''}"
    except ValueError:
        return ""


def _link_record(url: str, *, source_url: str, source_title: str = "",
                 link_type: str = "official_notice", anchor_text: str = "",
                 primary: bool = False) -> dict:
    host = urlparse(url).netloc.lower().replace("www.", "")
    domain_class = ("official_explicit" if host in sources.OFFICIAL_HOSTS else
                    "official_suffix" if sources.is_official_domain(host) else "external")
    return {
        "url": url,
        "exact_url": url,
        "anchor_text": anchor_text or source_title[:180],
        "text": anchor_text or source_title[:180],
        "source_url": source_url,
        "source_title": source_title,
        "canonical_url": url,
        "final_url": url if primary else "",
        "domain_class": domain_class,
        "link_type": link_type,
        "verification_status": "verified_primary_source" if primary else "present_in_source_evidence",
        "primary_source": bool(primary),
    }


def _topic_tokens(*values: str) -> set:
    stop = {"official", "website", "online", "apply", "application", "notice",
            "notification", "download", "click", "here", "the", "and", "for",
            "from", "with", "2026", "2025", "india", "home", "portal"}
    tokens = set()
    for value in values:
        tokens.update(t for t in re.findall(r"[a-z0-9]{4,}", str(value or "").lower())
                      if t not in stop)
    return tokens


def _authority_evidence_allowed(record: dict) -> bool:
    """Allow non-government authorities only with an explicit source label."""
    url = str(record.get("exact_url") or record.get("url") or "")
    if sources.is_official_domain(url):
        return True
    label = str(record.get("anchor_text") or record.get("text") or "").lower()
    kind = str(record.get("link_type") or "unknown")
    return kind in {"application", "organization", "contact", "fee_payment"} and bool(
        re.search(r"official|career|apply|application|registration|payment|fee|contact|website|portal",
                  label, re.I))


def _resolve_evidence_link(record: dict, article: dict) -> tuple[bool, dict]:
    """Resolve an evidence link and fail closed on bad redirects/pages.

    The primary fetched source is already validated by ``fetch_source``. A
    secondary outbound URL must survive a real HTTP resolution, remain on an
    official host, and not land on an obvious error/home redirect. The final
    URL is private audit data; public HTML uses the exact evidence URL.
    """
    item = dict(record)
    if item.get("primary_source"):
        final_url = item.get("canonical_url") or item.get("url", "")
        if final_url and not sources.is_official_domain(final_url):
            item["final_url"] = final_url
            item["verification_status"] = "rejected_primary_nonofficial_canonical"
            return False, item
        item["final_url"] = final_url
        item["verification_status"] = "verified_primary_source"
        return True, item
    url = str(item.get("exact_url") or item.get("url") or "").strip()
    if not sources.is_valid_source_url(url) or not _authority_evidence_allowed(item):
        item["verification_status"] = "rejected_not_authority_evidence"
        return False, item
    try:
        response = requests.get(url, headers={"User-Agent": "studentup-link-check/1.0"},
                                timeout=min(int(config.HTTP_TIMEOUT), 10),
                                allow_redirects=True)
        final_url = str(response.url or url)
        final_host = urlparse(final_url).netloc
        item["final_url"] = final_url
        item["resolved_status"] = int(response.status_code)
        if response.status_code < 200 or response.status_code >= 400:
            item["verification_status"] = "rejected_http_status"
            return False, item
        original_host = urlparse(url).netloc.lower().replace("www.", "")
        final_host_key = final_host.lower().replace("www.", "")
        if (not sources.is_official_domain(final_host)
                and final_host_key != original_host):
            item["verification_status"] = "rejected_redirect_nonofficial"
            return False, item
        content_type = response.headers.get("content-type", "").lower()
        if "html" in content_type or not content_type:
            from bs4 import BeautifulSoup
            soup = BeautifulSoup(response.text[:250000], "html.parser")
            page_title = unescape((soup.title.get_text(" ", strip=True)
                                   if soup.title else ""))
            page_h1 = unescape((soup.find("h1").get_text(" ", strip=True)
                                if soup.find("h1") else ""))
            page_heading = f"{page_title} {page_h1}".lower()
            item["destination_title"] = (page_title or page_h1)[:180]
            if not page_heading.strip():
                item["verification_status"] = "rejected_no_destination_title"
                return False, item
            expected = _topic_tokens(
                article.get("title", ""), item.get("source_title", ""),
                item.get("anchor_text", ""), item.get("link_type", ""))
            destination = _topic_tokens(page_title, page_h1, final_url)
            overlap = sorted(expected.intersection(destination))
            item["destination_topic_overlap"] = overlap[:12]
            if (len(destination) >= 2 and expected and not overlap
                    and item.get("link_type") not in {"organization", "contact"}):
                item["verification_status"] = "rejected_wrong_topic_redirect"
                return False, item
            if re.search(r"404|not found|page unavailable|access denied|server error",
                         page_heading, re.I):
                item["verification_status"] = "rejected_error_page"
                return False, item
            # A redirect to a generic official home page is not a proof of the
            # application/result purpose claimed by the article.
            if page_heading.strip() in {"home", "homepage", "official website"}:
                item["verification_status"] = "rejected_generic_home"
                return False, item
        item["verification_status"] = (
            "verified_resolved_official" if sources.is_official_domain(final_host)
            else "verified_resolved_evidence_external")
        return True, item
    except requests.RequestException as exc:
        item["verification_status"] = "rejected_unreachable"
        item["verification_error"] = str(exc)[:180]
        return False, item


def _append_official_sources(article: dict) -> None:
    """Build public links only from exact, verified source evidence.

    Model-proposed URLs are treated as untrusted suggestions. A URL is
    eligible only when it is the fetched official primary source or the exact
    URL of an anchor found in fetched source evidence. Each selected link is
    resolved before rendering, and its evidence/final URL stays in the private
    audit ledger.
    """
    article["external_links"] = article.get("external_links") or []
    source_urls = [str(u).strip() for u in (article.get("_source_urls") or []) if str(u).strip()]
    deep_sources = list(article.get("_deep_sources") or [])
    records, by_key = [], {}

    # Primary URLs are allowed only when official and present in the fetched
    # source set. This keeps the original source usable even if it has no links.
    for raw_source in deep_sources:
        source = _source_dict(raw_source)
        source_url = str(source.get("url") or "").strip()
        source_title = str(source.get("title") or "").strip()
        canonical = str(source.get("canonical_url") or source_url).strip()
        if sources.is_official_domain(source_url) and source_url:
            primary_type = sources._link_type(source_title, source_url)
            rec = _link_record(source_url, source_url=source_url,
                               source_title=source_title,
                               link_type=(primary_type if primary_type != "unknown"
                                          else "official_notice"), primary=True)
            rec["canonical_url"] = canonical or source_url
            records.append(rec)
            by_key[_url_key(source_url)] = rec
        for link in source.get("outbound_links") or []:
            if not isinstance(link, dict):
                continue
            exact = str(link.get("exact_url") or link.get("url") or "").strip()
            if not exact:
                continue
            rec = dict(link)
            rec.setdefault("exact_url", exact)
            rec.setdefault("url", exact)
            rec.setdefault("source_url", source_url)
            rec.setdefault("source_title", source_title)
            rec.setdefault("anchor_text", rec.get("text", ""))
            rec.setdefault("text", rec.get("anchor_text", ""))
            rec.setdefault("canonical_url", exact)
            rec.setdefault("final_url", "")
            rec.setdefault("domain_class", "external")
            rec.setdefault("link_type", "unknown")
            if rec.get("link_type") == "unknown":
                rec["link_type"] = sources._link_type(
                    rec.get("anchor_text") or rec.get("text", ""), exact)
            rec.setdefault("verification_status", "present_in_source_evidence")
            rec["primary_source"] = False
            records.append(rec)
            by_key[_url_key(exact)] = rec
        # URLs printed as plain text in fetched HTML/PDF are evidence too;
        # they do not need to be clickable anchors to be retained privately.
        for exact in sources._text_urls(str(source.get("text") or "")):
            key = _url_key(exact)
            if key and key not in by_key:
                rec = sources._source_link_record(
                    exact, source_url, "URL in source text",
                    verification_status="present_in_source_text")
                records.append(rec)
                by_key[key] = rec
        # Backward-compatible SourceArticle fixtures may have URL-only outbound.
        for exact in source.get("outbound") or []:
            key = _url_key(exact)
            if key and key not in by_key:
                rec = _link_record(str(exact), source_url=source_url,
                                   source_title=source_title,
                                   link_type="unknown")
                records.append(rec)
                by_key[key] = rec

    # Some callers provide only _source_urls. These remain valid primary
    # evidence, but non-official news/blog URLs can never become public links.
    for source_url in source_urls:
        key = _url_key(source_url)
        if key in by_key or not sources.is_official_domain(source_url):
            continue
        rec = _link_record(source_url, source_url=source_url,
                           source_title="Official Notice", primary=True)
        records.append(rec)
        by_key[key] = rec

    # The model's URL is accepted only if it exactly matches an evidence record.
    # Its label cannot override the evidence's semantic type. Keep rejected
    # suggestions privately so an editor can see why a link disappeared.
    selected = []
    rejected_model_links = []
    for item in article["external_links"]:
        if not isinstance(item, dict):
            continue
        key = _url_key(str(item.get("url") or ""))
        rec = by_key.get(key)
        if not rec:
            rejected_model_links.append({
                "url": str(item.get("url") or ""),
                "text": str(item.get("text") or "")[:180],
                "reason": "not_present_in_fetched_source_evidence",
            })
            continue
        selected.append(rec)
    # Include verified official evidence even if the model omitted the link.
    selected.extend(rec for rec in records if rec not in selected)
    # Do not probe every navigation/resource URL on a large source page.
    # Purpose-first ordering still preserves application/result links before a
    # long tail of generic official resources.
    priority = {"application": 0, "official_notice": 1, "result": 2,
                "admit_card": 3, "syllabus": 4, "fee_payment": 5,
                "organization": 6, "contact": 7, "unknown": 8}
    selected.sort(key=lambda item: (priority.get(item.get("link_type"), 9),
                                   0 if item.get("primary_source") else 1))
    selected = selected[:24]

    # Resolve, dedupe, and keep a small purpose-diverse set for students.
    resolved = []
    seen = set()
    for rec in selected:
        key = _url_key(rec.get("exact_url") or rec.get("url"))
        if not key or key in seen:
            continue
        ok, checked = _resolve_evidence_link(rec, article)
        record_index = records.index(rec) if rec in records else -1
        if record_index >= 0:
            records[record_index] = checked
        if not ok:
            continue
        seen.add(key)
        resolved.append(checked)

    resolved.sort(key=lambda item: (priority.get(item.get("link_type"), 9),
                                   records.index(item) if item in records else 0))
    visible = []
    for item in resolved:
        kind = item.get("link_type", "unknown")
        visible.append({
            "text": item.get("anchor_text") or item.get("text") or
                    f"Official link — {urlparse(item['url']).netloc}",
            "url": item["url"],
            "link_type": kind,
            "source_url": item.get("source_url", ""),
        })
        if len(visible) >= 8:
            break
    article["external_links"] = visible
    article["_source_link_records"] = [dict(item) for item in records]
    article["_verified_link_map"] = {
        kind: next((item for item in resolved if item.get("link_type") == kind), None)
        for kind in ("application", "official_notice", "organization", "result",
                     "admit_card", "syllabus", "fee_payment", "contact")
    }
    # Recruitment URLs are derived exclusively from the evidence map.
    link_map = article["_verified_link_map"]
    application = link_map.get("application")
    organization = link_map.get("organization")
    article["application_url"] = application["url"] if application else ""
    article["verified_org_url"] = organization["url"] if organization else ""
    rec = article.get("recruitment")
    if isinstance(rec, dict):
        rec["org_url"] = article["verified_org_url"]
    article["_official_link_audit"] = {
        "candidate_count": len(records),
        "verified_count": len(resolved),
        "published_count": len(visible),
        "links": [dict(item) for item in records],
        "rejected_model_links": rejected_model_links[:20],
        "mapping": {key: (value or {}).get("url", "")
                    for key, value in link_map.items()},
    }


def _source_evidence_context(report: Dict) -> str:
    """Compact verified-fact ledger supplied to a correction pass."""
    rows = []
    for fact in (report or {}).get("verified", [])[:40]:
        value = fact.get("value", "")
        if not value or fact.get("kind") == "official_link":
            continue
        sources = ", ".join(fact.get("sources", [])[:4])
        rows.append(f"{fact.get('kind', 'fact')}: {value} [{fact.get('status', 'unknown')}; {sources}]")
    return "\n".join(rows) or "No verified numeric/date facts; do not add any."


def _correct_source_claims(article: Dict) -> None:
    """Make a bounded factual correction pass before the hard preflight.

    The first model output is never trusted blindly. If dates/counts are not
    supported by the fetched source text, or the deep report finds a conflict,
    ask the model to remove/correct those claims using only the evidence ledger.
    A failed correction is left for the hard gate to reject.
    """
    if article.get("_mock") or not config.gemini_configured():
        return
    from . import deep_research as _dr

    sources_text = [
        getattr(source, "text", "") or (source.get("text", "") if isinstance(source, dict) else "")
        for source in (article.get("_deep_sources") or [])
    ]
    report = _dr.build_report(
        article.get("title", ""), article.get("_deep_sources") or [],
        notebooklm_brief=article.get("_notebooklm_brief", ""),
        target_year=article.get("_target_year"),
    )
    fact_flags = validator.fact_guard(article.get("content_html", ""), sources_text)
    hard, _warnings = _dr.gate_post(article.get("content_html", ""), report, live=True)
    fixes = fact_flags + hard
    if not fixes:
        return
    log.warning("Source correction pass: %d unsupported/conflicting item(s)", len(fixes))
    try:
        evidence = _source_evidence_context(report)
        improved = gemini_client.refine_article(
            article, fixes[:12], source_evidence=evidence)
        for key in ("title", "meta_description", "seo_title", "content_html",
                    "focus_keyword", "secondary_keywords", "tags", "faq",
                    "quick_answer"):
            if improved.get(key):
                article[key] = improved[key]
        corrected_html = article.get("content_html", "")
        overlaps = validator.verbatim_overlaps(corrected_html, sources_text,
                                               ignore_terms=_verbatim_ignore(article))
        originality = validator.originality_score(corrected_html, sources_text)
        floor = float(getattr(config, "ORIG_HARD_FLOOR", 72))
        # v376 DE-COPY PASS: a copy-risk result used to be a reject/warning.
        # Now the exact shared phrases go back to the model once with an
        # explicit "rewrite in your own Telugu words" instruction; only if
        # overlaps still remain does the gate decide. Drafts get cleaner
        # instead of being dropped or tagged.
        if overlaps or originality < floor:
            try:
                decopy = [
                    "COPY-RISK: the following word runs are copied verbatim from the "
                    "source. Rewrite each in original Telugu (same facts, different "
                    "sentence structure; never quote the source): " + " | ".join(overlaps[:8])
                ] if overlaps else [
                    f"COPY-RISK: originality {originality:.0f}% is below {floor:.0f}%. Rewrite "
                    "the body in original Telugu sentences; keep every verified fact, "
                    "change structure and wording throughout."
                ]
                redo = gemini_client.refine_article(article, decopy, source_evidence=evidence)
                if redo.get("content_html"):
                    html2 = redo["content_html"]
                    ov2 = validator.verbatim_overlaps(html2, sources_text,
                                                      ignore_terms=_verbatim_ignore(article))
                    or2 = validator.originality_score(html2, sources_text)
                    if len(ov2) <= len(overlaps) and or2 >= originality:
                        article["content_html"] = html2
                        for key in ("faq", "quick_answer", "meta_description"):
                            if redo.get(key):
                                article[key] = redo[key]
                        corrected_html, overlaps, originality = html2, ov2, or2
                        log.info("De-copy pass: overlaps %d, originality %.1f%%", len(ov2), or2)
            except Exception as exc:  # noqa: BLE001 — gate below still decides
                log.warning("De-copy pass unavailable: %s", exc)
        if (overlaps or originality < floor) and not _gate_soft_fail(
                article, "COPY-RISK",
                f"originality={originality:.1f}%, overlaps={len(overlaps)} — edit before publish"):
            raise RuntimeError(
                "SOURCE CORRECTION REJECTED: rewrite copy-risk remains "
                f"(originality={originality:.1f}%, overlaps={len(overlaps)})")
    except RuntimeError:
        raise
    except Exception as exc:  # noqa: BLE001 — preflight remains the hard gate
        log.warning("Source correction pass unavailable: %s", exc)


def _strict_source_preflight(article: Dict, *, allow_mock: bool = False) -> Dict:
    """Validate evidence before a source-derived article reaches WordPress.""

    A source URL/search result is not permission to invent missing facts. This
    gate requires the fetched source set, an official source, the cross-source
    report, numeric/date fact support and the claim ledger. It deliberately
    runs before draft creation, not only before live publishing.
    """
    if allow_mock or article.get("article_type") == "quiz":
        return {"ok": True, "skipped": True}
    if not getattr(config, "SOURCE_PREFLIGHT_REQUIRED", True):
        return {"ok": True, "skipped": True, "reason": "disabled by config"}
    from . import deep_research as _dr
    from . import editorial_value as _ev

    deep_sources = list(article.get("_deep_sources") or [])
    report = _dr.build_report(
        article.get("title", ""), deep_sources,
        notebooklm_brief=article.get("_notebooklm_brief", ""),
        target_year=article.get("_target_year"),
    )
    article["_deep"] = report
    audit = _dr.audit_source_set(article)
    article["_source_audit"] = audit
    source_texts = []
    for source in deep_sources:
        text = source.get("text", "") if isinstance(source, dict) else getattr(source, "text", "")
        if text:
            source_texts.append(text)
    fact_flags = validator.fact_guard(article.get("content_html", ""), source_texts)
    article["_source_fact_flags"] = fact_flags
    ledger = _ev.build_ledger(article, article.get("content_html", ""), deep_sources)
    article["_editorial_value"] = ledger
    claim_flags = [
        f"{item.get('value', 'claim')}: source evidence missing"
        for item in ledger.get("unsupported_claims", [])[:8]
    ]
    article["_claim_flags"] = claim_flags
    hard, warnings = _dr.gate_post(article.get("content_html", ""), report, live=True)
    result = {
        "ok": not audit.get("flags") and not fact_flags and not claim_flags and not hard,
        "audit": audit, "fact_flags": fact_flags,
        "claim_flags": claim_flags, "deep_hard": hard, "warnings": warnings,
    }
    article["_source_preflight"] = result
    if not result["ok"]:
        parts = (audit.get("flags", []) + fact_flags + claim_flags + hard)[:8]
        if _gate_soft_fail(article, "EVIDENCE", "; ".join(parts)):
            return result
        raise RuntimeError(
            "SOURCE PREFLIGHT FAILED — article not created because evidence is incomplete: "
            + "; ".join(parts)
        )
    log.info("SOURCE PREFLIGHT PASS ✔ %s", _dr.format_source_audit(audit))
    return result



def _draft_mode(article: Dict) -> bool:
    """True when this article will be saved as a review DRAFT (not live)."""
    status = str(article.get("_force_status") or
                 getattr(config, "DEFAULT_POST_STATUS", "draft")).lower()
    return status != "publish"


def _verbatim_ignore(article: Dict, src=None) -> list:
    """v388: names that legitimately repeat verbatim (title, keyword, org,
    H2 texts) — verbatim_overlaps ignores these tokens."""
    terms = [article.get("title", ""), article.get("focus_keyword", ""),
             article.get("seo_title", "")]
    terms += [str(k) for k in (article.get("secondary_keywords") or [])[:6]]
    if src is not None:
        terms.append(str(getattr(src, "title", "") or ""))
    terms += re.findall(r"<h[23][^>]*>(.*?)</h[23]>", article.get("content_html", "") or "", flags=re.S)
    return [validator.strip_tags(t) for t in terms if t]


def _duplicate_title_guard(article: Dict, wp=None) -> None:
    """v388/v391: the same story from two URLs created identical drafts, and on
    22-Oct the SAME notification was published 4× under different wording
    (AP DSC 2,721 ×4, APPSC Group 2 ×2). Three checks before a WP slot is used:
      1. exact / ≥0.92 fuzzy title match against our recent titles
      2. topic signature (shared entity tokens + same post count + year)
      3. the slug already exists in WordPress (publish/draft/pending/future)
    """
    import difflib

    from . import kw_align as _ka

    title = str(article.get("title") or "")
    norm = state.normalize_title(title)
    if not norm or article.get("_mock") or article.get("_refresh_of"):
        return
    try:
        if state.title_exists(config.STATE_PATH, title):
            raise RuntimeError(f"SKIP-DUPLICATE-TITLE: already drafted — {title[:70]}")
        for old in state.recent_titles(config.STATE_PATH, limit=150):
            r = difflib.SequenceMatcher(None, norm, state.normalize_title(old)).ratio()
            if r >= 0.92:
                raise RuntimeError(f"SKIP-DUPLICATE-TITLE: {r:.0%} same as '{old[:60]}'")
            if _ka.same_topic(title, old):
                raise RuntimeError(f"SKIP-DUPLICATE-TOPIC: same notification as '{old[:60]}'")
    except RuntimeError:
        raise
    except Exception as exc:  # noqa: BLE001 — state read fail → don't block
        log.debug("dup-title guard skip: %s", exc)
    slug = str(article.get("slug") or "").strip()
    if wp is not None and slug:
        try:
            resp = wp._request("GET", "posts", params={
                "slug": slug, "status": "publish,draft,pending,future",
                "context": "edit", "_fields": "id,status,title", "per_page": 5})
            if resp.status_code == 200 and resp.json():
                hit = resp.json()[0]
                raise RuntimeError(
                    f"SKIP-DUPLICATE-SLUG: '{slug}' already exists in WP (#{hit.get('id')}, "
                    f"{hit.get('status')}) — WordPress would have made it '{slug}-2'")
        except RuntimeError:
            raise
        except Exception as exc:  # noqa: BLE001
            log.debug("dup-slug guard skip: %s", exc)


def _gate_soft_fail(article: Dict, tag: str, detail: str) -> bool:
    """v319: in draft mode record the gate failure as a warning instead of
    aborting. Returns True when the caller should continue (warned)."""
    if not getattr(config, "GATE_DRAFT_WARN_ONLY", True) or not _draft_mode(article):
        return False
    warns = list(article.get("_gate_warnings") or [])
    warns.append(f"{tag}: {detail}"[:300])
    article["_gate_warnings"] = warns
    article["_manual_publish_approved"] = False
    log.warning("GATE %s → draft warning (live publish stays blocked): %s", tag, detail[:160])
    return True

def create_from_source(url: str, mock: bool = False, category: str = "",
                       notebooklm_brief: str = "",
                       target_year: int | None = None,
                       force_draft: bool = False) -> Dict:
    """Vere site URL -> 100% original SEO article -> draft post.

    category empty aite auto-classify (Telugu+English keywords tho).
    """
    if not sources.is_valid_source_url(url):
        raise ValueError("URL valid kadu (http/https link ivvandi)")

    # Same-notification protection: if the official source was already stored
    # on a StudentUp post, refresh that post in place. A failed live lookup is
    # non-destructive and falls back to the normal source-backed draft path.
    if getattr(config, "AUTO_UPDATE_SAME_SOURCE", True) and not mock:
        try:
            existing = WordPressClient().find_post_by_source_url(url)
            if existing and existing.get("id"):
                log.info("Existing source match post %s — update in place, no duplicate", existing["id"])
                return update_post(int(existing["id"]), new_source_urls=[url], mock=False)
        except Exception as exc:  # noqa: BLE001 — source lookup must not lose work
            log.warning("Existing-source lookup unavailable; normal draft path continues: %s", exc)

    if state.source_done(config.STATE_PATH, url):
        raise ValueError("Ee URL already process chesayi — duplicate!")

    log.info("Source fetch chestunnanu: %s", url)
    from . import gnews as _gn
    if _gn.is_google_news_url(url):
        # v316: already-queued Google News links → publisher URL first
        real = _gn.resolve(url)
        if not real:
            raise ValueError("Google News redirect link resolve avvaledu — skip")
        log.info("Google News → publisher: %s", real)
        url = real
    src = sources.fetch_source(url)
    log.info("Source ready: %s (%d chars)", src.title[:60], len(src.text))
    # v383: expired news (job mela held in May, drafted in October) must never
    # become a draft — raises ValueError("stale …") → queue marks stale_notice.
    if not mock:
        from . import stale_gate
        stale_gate.assert_fresh(src, category or classify_source_category(url, src.title, src.text))

    # v318: same opportunity from a DIFFERENT publisher URL (Telegram links /
    # radar) → refresh the existing StudentUp post instead of a duplicate draft.
    opp_key = ""
    try:
        from .news_radar import _opportunity_key
        import hashlib as _hl
        opp = _opportunity_key(src.title)
        opp_key = _hl.sha1(opp.encode("utf-8")).hexdigest()[:20] if opp else ""
        prev_id = state.opportunity_post(config.STATE_PATH, opp_key) if opp_key else None
        if (prev_id and not mock
                and getattr(config, "AUTO_UPDATE_SAME_SOURCE", True)):
            log.info("Same opportunity already covered by post %s — update in place "
                     "(new source merged), duplicate draft kaadu", prev_id)
            return update_post(int(prev_id), new_source_urls=[url], mock=False)
    except Exception as exc:  # noqa: BLE001 — dedup must never lose work
        log.debug("opportunity dedup skip: %s", exc)
    if target_year is None:
        from .research_brief import target_year_from_text
        target_year = target_year_from_text(f"{src.title} {url} {notebooklm_brief[:4000]}")
    generation_year = target_year or date.today().year
    if target_year:
        log.info("Target-year mode enabled: %d — other-year claims require verification", target_year)

    # --- multi-source research: internet lo same topic articles ---
    extras, competitor_titles = [], []
    notebooklm_bundle = {}
    if config.RESEARCH_ENABLED and not mock:
        try:
            extras, competitor_titles = research.research_topic(
                src, config.RESEARCH_MAX_SOURCES)
            if extras:
                log.info("Research: +%d extra sources (MERGE & BEAT mode)", len(extras))
            else:
                log.info("Research: extra sources levu — primary source tho rewrite")
        except Exception:
            log.exception("Research step failed — primary source tho continue")
    # Discovery/research can take time and a notice may change while it runs.
    # Re-fetch the complete evidence set immediately before drafting; a failed
    # recheck stops this source-derived draft instead of using stale claims.
    reverified_at = ""
    if not mock:
        from . import reverification

        src, extras, reverified_at = reverification.refresh([src] + extras)
        log.info("SOURCE RECHECK PASS ✔ %d source(s) fetched immediately before drafting",
                 1 + len(extras))
        if getattr(config, "NOTEBOOKLM_AUTO_BUNDLE", True):
            try:
                from . import research_brief as _rb

                notebooklm_bundle = _rb.write_bundle(
                    src.title, [src] + extras, target_year=target_year)
                log.info("NotebookLM bundle ready: %d sources → %s",
                         notebooklm_bundle.get("sources", 0),
                         notebooklm_bundle.get("bundle"))
            except Exception:
                # Bundle preparation is observable but never substitutes for
                # the strict fetched-source preflight below.
                log.exception("NotebookLM bundle preparation skipped")

    if mock:
        article = {
            "title": f"{src.title[:80]} – Complete Guide {generation_year} (Original)",
            "slug": "src-" + src.title.lower().replace(" ", "-")[:30],
            "meta_description": f"{src.title[:100]} — Telugu lo complete details.",
            "tags": [str(generation_year), "Students", "Telugu", "Guide", "News"],
            "banner_text": f"Students Guide {generation_year}",
            "content_html": (
                "<p>ఈ ఆర్టికల్‌లోని ముఖ్యమైన విషయాలను సులభమైన భాషలో "
                f"వివరించాము: {src.title}</p>"
                "<h2>Key Details</h2><ul><li>Point one</li><li>Point two</li></ul>"
                "<h2>Process</h2><ol><li>Step one</li><li>Step two</li></ol>"
                "<h2>FAQ</h2><h3>Question?</h3><p>Answer</p>"
            ),
            "category": category or classify_source_category(url, src.title, src.text),
            "model": "mock",
            "focus_keyword": f"test guide {generation_year}",
            "seo_title": f"Test Guide {generation_year} – Complete Details",
            "secondary_keywords": ["test guide details", f"{generation_year} guide telugu"],
            "quick_answer": (f"Test guide {generation_year} gurinchi menu thelisi untundi — "
                             "ee quick answer featured snippet test kosam."),
            "faq": [
                {"question": "Ee guide em gurinchi?", "answer": "Test guide gurinchi."},
                {"question": "Ela apply cheyali?", "answer": "Online lo apply cheyali."},
            ],
            "external_links": [{"text": "Official Site", "url": "https://www.gov.in"}],
            "source_url": url,
            "source_title": src.title,
        }
    else:
        recent = state.recent_titles(config.STATE_PATH, limit=30)
        article = gemini_client.generate_article_from_source(
            src, recent, generation_year, extras=extras,
            competitor_titles=competitor_titles,
            notebooklm_brief=notebooklm_brief,
        )
        if category:
            # Curated source-grid hints are authoritative; they were assigned
            # by the editor/source map, not guessed from generic headlines.
            article["category"] = category
        else:
            # Never trust the model's broad fallback (often Central Govt Jobs
            # for a software notification). Reclassify from the source title +
            # generated title with the canonical intent rules.
            article["category"] = classify_source_category(
                url, f"{src.title} {article.get('title', '')}", src.text)
        # --- originality guard: 70% kante takkuva aite OKKO regenerate ---
        source_texts = [src.text] + [e.text for e in extras]
        if notebooklm_brief:
            from . import research_brief as _rb
            source_urls = [src.url] + [e.url for e in extras]
            brief_check = _rb.validate_editor_brief(
                notebooklm_brief, source_urls, target_year=target_year)
            if not brief_check["ok"]:
                raise ValueError(
                    "NotebookLM brief validation failed: "
                    + "; ".join(brief_check["problems"]))
            article["_notebooklm_claims"] = brief_check["claims"]
            article["_notebooklm_sources"] = brief_check["source_ids"]
        article["content_html"] = validator.sanitize_html(article["content_html"])
        orig = validator.originality_score(article["content_html"], source_texts)
        overlaps = validator.verbatim_overlaps(article["content_html"], source_texts,
                                               ignore_terms=_verbatim_ignore(article, src))
        if overlaps:
            log.warning("Exact source phrase overlap detected (%d runs) — regenerate", len(overlaps))
        if orig < 70.0 or overlaps:
            log.warning("Source similarity guard triggered (originality %.1f%%) — regenerate", orig)
            try:
                retry_article = gemini_client.generate_article_from_source(
                    src, recent, generation_year, extras=extras,
                    competitor_titles=competitor_titles,
                    notebooklm_brief=notebooklm_brief,
                )
                retry_article["content_html"] = validator.sanitize_html(
                    retry_article["content_html"])
                retry_orig = validator.originality_score(
                    retry_article["content_html"], source_texts)
                retry_overlaps = validator.verbatim_overlaps(
                    retry_article["content_html"], source_texts,
                    ignore_terms=_verbatim_ignore(retry_article, src))
                # Prefer a clean rewrite over a numerically higher similarity
                # score; exact copied runs are never an acceptable tradeoff.
                better = (not retry_overlaps and bool(overlaps)) or (
                    len(retry_overlaps) < len(overlaps)
                    and retry_orig >= orig - 2.0
                ) or (not overlaps and retry_orig > orig)
                if better:
                    log.info("Regenerate better: %.1f%% -> %.1f%%; exact runs %d -> %d",
                             orig, retry_orig, len(overlaps), len(retry_overlaps))
                    article, orig, overlaps = retry_article, retry_orig, retry_overlaps
            except gemini_client.GeminiError:
                log.exception("Regenerate failed — first version e continue")
        if overlaps and not _gate_soft_fail(
                article, "VERBATIM",
                f"{len(overlaps)} exact source phrase(s) — edit before publish: "
                + " | ".join(str(o)[:70] for o in overlaps[:2])):
            raise RuntimeError(
                "SKIP-VERBATIM-OVERLAP: rewrite still shares exact long phrases "
                "with a source; source set needs editorial rewriting before use")
        # v18 HARD FLOOR: near-copy anipichte publish EEDU (AdSense rule #1 —
        # copied content unte site approve avakapote runtime lo ban risk)
        floor = getattr(config, "ORIG_HARD_FLOOR", 72)
        if orig < floor and not _gate_soft_fail(
                article, "NEAR-COPY", f"originality {orig:.1f}% < {floor}%"):
            raise RuntimeError(
                f"SKIP-NEAR-COPY: best originality {orig:.1f}% < hard floor "
                f"{floor}% — ee source ni skip chestunnam (AdSense risk). "
                f"Inko deep-rewrite source try cheyandi: {src.url}")

        # v103: local donors tho match avvakapoyina, internet lo unknown copied
        # phrase undochu. Distinctive sentences ni live exact-search chesi
        # returned pages fetch chesi verify chestam. Match = publish BLOCK.
        if getattr(config, "ORIG_LIVE_CHECK", True):
            try:
                from . import originality_live as _live

                _live_rep = _live.check(
                    article["content_html"],
                    own_domain=urlparse(config.WP_SITE).netloc,
                    max_phrases=getattr(config, "ORIG_LIVE_PHRASES", 3),
                )
                article["_live_originality"] = _live_rep
                log.info("%s", _live.format_report(_live_rep))
                if _live_rep.get("matches") and not _gate_soft_fail(
                        article, "LIVE-COPY",
                        f"web search found copied phrase(s) on {len(_live_rep['matches'])} page(s)"):
                    raise RuntimeError(
                        "SKIP-LIVE-EXACT-OVERLAP: live web search found copied "
                        f"phrase(s) on {len(_live_rep['matches'])} page(s); "
                        "human rewrite/source attribution required")
                # v253: CSE credentials unte live check "best effort" kaadu —
                # adi mandatory. Credentials unna check fail aite publish
                # block (silent degrade = copy risk).
                _cse_ready = bool(getattr(config, "GOOGLE_CSE_API_KEY", "")
                                  and getattr(config, "GOOGLE_CSE_ID", ""))
                _live_required = (getattr(config, "ORIG_LIVE_REQUIRED", False)
                                  or _cse_ready)
                if (_live_rep.get("status") in ("partial", "error")
                        and _live_required and not _gate_soft_fail(
                            article, "LIVE-CHECK", "real-time originality check incomplete")):
                    raise RuntimeError(
                        "SKIP-LIVE-CHECK-UNAVAILABLE: required real-time "
                        "originality check did not complete")
            except RuntimeError:
                raise
            except Exception:  # noqa: BLE001 — report, never fake PASS
                log.exception("live originality check failed (local gates remain)")

    # v19: near-duplicate guard — Google "scaled content abuse" policy:
    # swapped-name/only-date-changed pages site-wide signal ni charchestayi.
    # Mana published posts tho ee level dup ante SKIP (AdSense + ranking both).
    try:
        ratio, match = validator.near_duplicate(
            article["title"], article["content_html"],
            state.load_fingerprints(config.STATE_PATH),
            config.DUP_JACCARD_SKIP)
        if ratio >= config.DUP_JACCARD_SKIP and not _gate_soft_fail(
                article, "NEAR-DUP", f"{ratio:.0%} overlap with '{match}' — merge/update instead?"):
            raise RuntimeError(
                f"SKIP-NEAR-DUP: {ratio:.0%} overlap with existing post "
                f"'{match}' — different exam/notification topic pick cheyandi")
        elif ratio >= 0.40:
            log.warning("Near-dup warning: %.0f%% overlap with '%s' (ok, but watch)",
                        ratio, match)
    except RuntimeError:
        raise
    except Exception as exc:  # noqa: BLE001 — guard never blocks on infra error
        log.warning("Dup guard skipped (%s)", exc)

    if notebooklm_bundle:
        # Private provenance only; never render bundle paths or source labels in
        # the public article.
        article["_notebooklm_bundle"] = {
            key: str(value) for key, value in notebooklm_bundle.items()
        }
    if reverified_at:
        article["_source_reverified_at"] = reverified_at
    if (getattr(config, "NOTEBOOKLM_REQUIRED", False)
            and not mock and not notebooklm_brief):
        raise RuntimeError(
            "NOTEBOOKLM BRIEF REQUIRED: import the private evidence bundle into "
            "NotebookLM and rerun with --notebooklm-brief <cited-brief.md>")

    # --- QA data (notification + trust box kosam) ---
    # Preserve the exact owner-supplied URL for source-aware classification and
    # private provenance; it is never rendered as a raw source dump.
    article.setdefault("source_url", url)
    article.setdefault("source_title", src.title)
    article["_source_texts"] = [src.text] + [e.text for e in extras]
    article["_deep_sources"] = [src] + extras  # v44: full objects (tiering)
    article["_target_year"] = target_year
    article["_notebooklm_brief"] = notebooklm_brief
    article["_source_urls"] = [src.url] + [e.url for e in extras]
    article["_source_domains"] = [
        d for d in [urlparse(src.url).netloc.replace("www.", "")]
        + [urlparse(e.url).netloc.replace("www.", "") for e in extras]
    ]

    # One bounded correction pass fixes source-detectable mistakes before the
    # strict preflight. Anything still unsupported/conflicting is rejected.
    _correct_source_claims(article)
    _append_official_sources(article)

    # Do not spend a WordPress draft slot on an article whose source facts or
    # claim evidence have not passed the strict source preflight.
    _strict_source_preflight(article, allow_mock=mock)

    # slug safe ga + Rank Math optimize (keyword tokens + stopwords)
    from .main import _safe_slug
    article["slug"] = seo.optimize_slug(
        _safe_slug(article.get("slug", ""), article["title"]),
        focus_keyword=article.get("focus_keyword", ""))
    article.setdefault("focus_keyword", "")
    article.setdefault("external_links", [])
    article.setdefault("secondary_keywords", [])
    article.setdefault("quick_answer", "")
    article.setdefault("faq", [])
    article.setdefault("seo_title", "")
    # Mock runs can assert the outbound payload, but they must never be
    # mistaken for proof that a real WordPress bridge persisted it.
    article["_mock"] = bool(mock)
    if force_draft:
        # Radar/orchestrator output always waits for owner review, irrespective
        # of the site's normal publishing default. It must also pass evidence
        # quality BEFORE consuming a WordPress draft slot or notifying Telegram.
        article["_force_status"] = "draft"
        if not mock:
            from . import deep_research as _pre

            article["_deep"] = _pre.build_report(
                article.get("title", src.title), [src] + extras,
                notebooklm_brief=notebooklm_brief,
                target_year=target_year)
            preflight = _pre.audit_source_set(article)
            article["_source_audit"] = preflight
            # v337: owner rule — drafts must keep flowing (v316). Evidence /
            # fact flags become visible review warnings on the draft + the
            # Telegram card; live publish stays blocked until a human fixes.
            if not preflight.get("ok") and not _gate_soft_fail(
                    article, "EVIDENCE", "; ".join(preflight.get("flags", [])[:5])):
                raise RuntimeError(
                    "DRAFT EVIDENCE REJECTED: "
                    + "; ".join(preflight.get("flags", [])[:5]))
            hard, _warnings = _pre.gate_post(
                article.get("content_html", ""), article["_deep"], live=True)
            if hard and not _gate_soft_fail(article, "FACT-CONFLICT", "; ".join(hard[:4])):
                raise RuntimeError("DRAFT FACT CONFLICT: " + "; ".join(hard[:4]))
            log.info("Evidence preflight ✔ %s", _pre.format_source_audit(preflight))

    result = publish_article(article)
    try:
        if opp_key and isinstance(result, dict) and result.get("id"):
            state.remember_opportunity_post(config.STATE_PATH, opp_key, int(result["id"]))
    except Exception:  # noqa: BLE001
        pass
    return result


# ------------------------------------------------------------------ update flow

def update_post(post_id: int, new_source_urls=None, mock: bool = False) -> Dict:
    """Already-published/draft post ni kotha info tho IMPROVE chesi update.

    Same URL (slug preserve) — Google lo freshness boost + SEO juice safe.
    new_source_urls: user ichina kotha source URLs (optional).
    Levu ante post title meeda auto web research chestundi.
    """
    wp = WordPressClient()
    wp.check_connection()
    post = wp.get_post(post_id)
    title = (post.get("title") or {}).get("raw") or (post.get("title") or {}).get("rendered", "")
    existing_html = (post.get("content") or {}).get("raw", "") or (post.get("content") or {}).get("rendered", "")
    slug = post.get("slug", "")
    link = post.get("link", "")
    existing_text = validator.strip_tags(existing_html)
    log.info("Update mode: post %s '%s' (%d chars)", post_id, title[:50], len(existing_text))

    # --- kotha sources gather ---
    extras = []
    from .sources import SourceArticle as SA

    for u in (new_source_urls or []):
        try:
            extras.append(sources.fetch_source(u))
        except Exception as exc:
            log.warning("New source fetch fail (%s): %s", u[:60], exc)
    if config.RESEARCH_ENABLED and not mock and len(extras) < 2:
        try:
            pseudo = SA(url=link or f"{config.WP_SITE}/?p={post_id}",
                        title=title, site_name="studentup.in", text="")
            more, _unused = research.research_topic(pseudo, config.RESEARCH_MAX_SOURCES)
            extras.extend(more)
        except Exception:
            log.exception("Auto research fail — manual sources tho continue")
    if not extras and not mock:
        raise ValueError("Kotha information dorakaledu — source URL ivvandi "
                         "or konchem rojulu tarvata try cheyandi")

    # Reverify update evidence immediately before generating replacement copy;
    # source-monitor findings never trigger an automatic edit by themselves.
    reverified_at = ""
    if not mock:
        from . import reverification

        primary_fresh, extras, reverified_at = reverification.refresh(extras)
        extras = [primary_fresh] + extras
        log.info("SOURCE RECHECK PASS ✔ %d source(s) fetched before update draft",
                 len(extras))

    # --- generate updated version ---
    if mock:
        article = {
            "title": title,
            "slug": slug or "keep",
            "meta_description": f"{title[:100]} — updated version.",
            "tags": ["2026", "Students", "Telugu", "Guide"],
            "banner_text": "Updated Guide",
            "content_html": (
                "<p>Ee updated test article — kotha info merge ayyindi.</p>"
                "<h2>Key Details</h2><ul><li>Old point</li><li>Kotha point add ayyindi</li></ul>"
                "<h2>Process</h2><ol><li>Step one</li><li>Step two</li></ol>"
                "<h2>FAQ</h2><h3>Q?</h3><p>A</p>"
            ),
            "category": "Education News",
            "model": "mock",
            "focus_keyword": "test guide 2026",
            "secondary_keywords": ["update test"],
            "quick_answer": "Updated quick answer for the test.",
            "faq": [{"question": "Q?", "answer": "A"}],
            "update_notes": "• Kotha fee details add chesayi (test)",
        }
    else:
        fk = ""
        try:
            fk = (post.get("meta") or {}).get("rank_math_focus_keyword", "") or ""
            fk = fk.split(",")[0].strip()
        except Exception as exc:  # noqa: BLE001 — best-effort (silent kaadu)
            log.debug("update_post skip: %s", exc)
        article = gemini_client.generate_update(
            title, existing_text, fk, extras, date.today().year,
        )

    # identity preserve — URL marakudadu
    article["title"] = title
    article["slug"] = slug
    article["content_html"] = validator.sanitize_html(article["content_html"])
    article = _hygiene(article)
    article.setdefault("update_notes", "")
    article["_deep_sources"] = list(extras)  # v77: update originality scoring
    if reverified_at:
        article["_source_reverified_at"] = reverified_at
    # v87: update kuda official-source links (create-path parity — kotha
    # gov notice links updates lo poyevai!). Preserve the existing primary
    # source as evidence instead of allowing a model-generated URL.
    previous_source = str((post.get("meta") or {}).get("studentup_source_url", "")).strip()
    article["source_url"] = previous_source or (extras[0].url if extras else "")
    article["_source_urls"] = ([previous_source] if previous_source else []) + \
        [e.url for e in extras if getattr(e, "url", "")]
    _append_official_sources(article)
    _strict_source_preflight(article, allow_mock=mock)

    # v84: update kuda rm100 re-run (LLM rewrite structure degrade kakunda +
    # internal preflight fresh). Fail ayina update aagadu (advisory).
    try:
        if not article.get("_no_rm100"):
            _ures = rm100.optimize(
                article, target=int(getattr(config, "RM_TARGET", 100) or 100),
                max_passes=2)
            # v87: optimize returns "score" (not "after") — v84 key bug valla
            # update rm100 ALWAYS skip ayyedi (KeyError → advisory catch)!
            article["_rm100"] = {"score": _ures["score"],
                                 "before": _ures["before"]}
            log.info("Update rm100 %s→%s", _ures["before"], _ures["score"])
    except Exception:  # noqa: BLE001 — advisory (update safe)
        log.exception("update rm100 skip (post safe)")

    # v101 DECEPTIVE-FRESHNESS GUARD: Google Aug-2026 spam update
    # "dateModified bumped with no real change" ni target chestundi, mariyu
    # "a scheduled job doing it nightly turns a one-off into a pattern".
    # Mana auto_refresh roju nadustundi — so content nijamga marithe
    # MATRAME dateModified bump cheyali. Lekapothe fake freshness signal.
    # Fail-closed for the freshness *signal*: if the audit cannot run, the
    # content refresh may continue but dateModified must NOT be fabricated.
    _fresh = {"publish": True, "bump_date": False, "change_pct": 0.0,
              "reason": "guard unavailable — dateModified bump blocked"}
    try:
        from . import freshness as _freshness

        _fresh = _freshness.decide(existing_html, article["content_html"])
        article["_freshness"] = _fresh
        log.info("FRESHNESS change=%.1f%% bump=%s — %s",
                 _fresh["change_pct"], _fresh["bump_date"], _fresh["reason"])
    except Exception:  # noqa: BLE001 — guard fail refresh ni aapadu
        log.exception("freshness guard skip (refresh safe, bump allowed)")
    if not _fresh.get("publish", True):
        log.warning("UPDATE SKIPPED post %s: %s", post_id, _fresh["reason"])
        return {"skipped": True, "post_id": post_id,
                "reason": _fresh["reason"], "freshness": _fresh,
                "link": post.get("link", "")}

    # --- SEO re-enhance (fresh TOC/quick answer/schema) ---
    recent = wp.get_recent_published(per_page=8)
    internal = [p for p in recent if p.get("id") != post_id][:4]
    final_html = seo.enhance(
        article["content_html"],
        focus_keyword=article.get("focus_keyword", ""),
        internal_links=[{"link": p["link"], "title": p["title"]} for p in internal],
        external_links=article.get("external_links", []),
        quick_answer=article.get("quick_answer", ""),
        faq=article.get("faq", []),
        # Google freshness rule: original datePublished preserve, dateModified new
        date_str=(post.get("date") or date.today().isoformat())[:10],
        # v101: nijamaina change unte matrame kotha dateModified — lekapothe
        # original modified date ne uncham (fake freshness Google ki vaddu).
        date_modified=(date.today().isoformat() if _fresh.get("bump_date", True)
                       else (post.get("modified") or post.get("date")
                             or date.today().isoformat())[:10]),
        slug=slug,
        title=title,
        description=article["meta_description"],
        category=article.get("category", ""),
        source_domains=[e.site_name for e in extras],
        recruitment=article.get("recruitment"),
    )
    # v96 BUG FIX: refresh flow lo monetize blocks MISS ayyevi. `publish_article`
    # lo `monetize.append_blocks()` untundi, kaani update path lo ledu — so
    # auto-refresh (roju purana posts) ayina prathi post nunchi Telegram CTA,
    # affiliate section mariyu v96 join strip **poyevi**. Refresh ekkuva
    # ayina kొద్దీ site lo CTA-less posts perigevi (channel growth + RPM loss).
    try:
        from . import monetize as _mz_upd

        final_html = _mz_upd.append_blocks(final_html, article)
        try:
            from . import ad_manager as _admgr_upd

            final_html, _ad_report = _admgr_upd.inject(final_html, article)
            article["_ads"] = _ad_report
        except Exception:  # noqa: BLE001 — owner ads must never block a refresh
            log.exception("Update ad manager inject skipped (safe)")
    except Exception:  # noqa: BLE001 — CTA fail update aapadu
        log.exception("update monetize blocks skip (post safe)")

    try:
        from . import deep_research as _dr_update
        article["_source_audit"] = _dr_update.audit_source_set(article)
    except Exception:
        log.exception("update source audit failed")
        article["_source_audit"] = {"applicable": True, "ok": False,
                                    "flags": ["SOURCE-AUDIT-FAILED"]}
    if getattr(config, "PUBLIC_EDITORIAL_CLEAN", True):
        final_html = seo.clean_public_article(final_html)
    final_html, article["_content_quality"] = content_quality.polish_and_audit(
        final_html, article.get("focus_keyword", ""))
    try:
        from . import editorial_value as _ev_update
        article["_editorial_value"] = _ev_update.build_ledger(
            article, final_html, article.get("_deep_sources") or [])
    except Exception:
        log.exception("update editorial ledger failed")
        article["_editorial_value"] = {"score": 0,
                                       "unsupported_claims": ["ledger unavailable"]}
    article["_google_quality"] = google_quality.audit(article, final_html, live=True)
    if article["_google_quality"]["flags"] and not mock:
        return {"error": "google_quality", "post_id": post_id,
                "reason": "; ".join(article["_google_quality"]["flags"]),
                "link": post.get("link", "")}
    if (getattr(config, "CONTENT_QUALITY_BLOCK", True)
            and article["_content_quality"]["flags"] and not mock):
        return {"error": "content_quality", "post_id": post_id,
                "reason": "; ".join(article["_content_quality"]["flags"]),
                "link": post.get("link", "")}
    qa = validator.validate_article(article, final_html)
    article["_qa"] = qa
    log.info("Update QA %s/100 words=%d · reader=%s/100", qa["score"], qa["words"],
             article["_content_quality"]["score"])
    try:  # v77: update kuda originality proof (donor sources vs final)
        article["_originality"] = validator.rewrite_distance(
            final_html, [e.text for e in extras if getattr(e, "text", "")])
        log.info("ORIGINALITY (update) fresh=%s (%s)",
                 article["_originality"]["fresh"],
                 article["_originality"]["verdict"])
    except Exception:  # noqa: BLE001
        log.exception("update originality skip (post safe)")

    meta = None
    if config.RANK_MATH_META_ENABLED:
        meta = seo.rankmath_meta(
            focus_keyword=article.get("focus_keyword", title[:60]),
            description=article["meta_description"],
            seo_title=article.get("seo_title") or title,
            secondary_keywords=article.get("secondary_keywords", []),
            slug=article.get("slug", ""),
        )
        article["_rankmath_meta"] = dict(meta)

    # v135: updates kuda job meta ni refresh cheyyali. Mundu ee block publish
    # path lo matrame undedi — anduke update tarvata 'studentup_qual' /
    # 'studentup_last_date' purathanam ga migilipoyevi (apply bar countdown,
    # eligibility filter, JobPosting schema anni stale ayyevi).
    if meta is not None:
        try:
            qmeta = qual.post_meta(article)
            if qmeta:
                meta.update(qmeta)
                log.info("v135 update qual/last-date refresh → %s", qual.describe(article))
        except Exception:  # noqa: BLE001 — tag fail update ni aapadu
            log.exception("v135 qual refresh skip (update safe)")

    source_meta = _source_identity_meta(article)
    if source_meta:
        if meta is None:
            meta = {}
        meta.update(source_meta)
        article["_source_identity"] = dict(source_meta)

    try:  # v65: update ki kuda certificate (evidence)
        gate = post_gate.run(article, final_html)
        article["_gate"] = gate
        post_gate.write_certificate(gate)
        log.info("PIN GATE (update) %s/100 · critical: %s", gate["score"],
                 gate["critical_fails"] or "none")
    except Exception:
        log.exception("update gate skip (post safe)")
    # v105: exact rollback point BEFORE the remote PUT. WordPress revisions
    # alone are not enough — preserve source ledger + candidate diff locally.
    try:
        from . import update_safety as _us

        article["_update_backup"] = _us.create_backup(
            post, final_html, new_meta=meta,
            ledger=article.get("_editorial_value") or {},
        )
        log.info("Update backup ✔ %s (%d diff lines)",
                 article["_update_backup"]["path"],
                 article["_update_backup"]["diff_lines"])
    except Exception as exc:  # noqa: BLE001 — never update without logging
        log.exception("update backup failed — REFUSING remote update")
        return {"error": "update_backup", "post_id": post_id,
                "reason": str(exc), "link": post.get("link", "")}

    result = wp.update_post(
        post_id,
        content_html=final_html,
        title=title,  # same title enforce (URL + identity safe)
        excerpt=article["meta_description"],
        meta=meta,
    )
    # v111: transparent correction/update ledger after successful WP write.
    try:
        from . import corrections as _corr

        article["_correction_record"] = _corr.record(
            post_id, title, reason="research-backed refresh",
            sources=article.get("_source_urls") or [],
            backup=(article.get("_update_backup") or {}).get("path", ""),
            change_summary=(article.get("_freshness") or {}).get("reason", ""),
        )
    except Exception:  # noqa: BLE001 — update succeeded; ledger warning only
        log.exception("correction ledger write failed (post already updated)")
    log.info("POST UPDATED ✔ id=%s link=%s", post_id, result.get("link"))
    if meta and not mock:
        try:
            required_seo = [k for k in meta if k.startswith("rank_math_")]
            # The underlying verify_meta read remains part of the compatibility
            # path; verify_rankmath_meta supplements it with bridge readback.
            landed = wp.verify_rankmath_meta(post_id, required_seo)
            missing = [k for k, ok in landed.items() if not ok]
            if missing and not mock:
                wp.write_seo_meta(post_id, meta)
                landed = wp.verify_rankmath_meta(post_id, required_seo)
                missing = [k for k, ok in landed.items() if not ok]
            article["_rankmath_landed"] = dict(landed)
            result["seo_meta_persisted"] = not missing
            result["seo_meta_keys"] = required_seo
            if missing:
                log.warning("UPDATE %s: Rank Math meta missing %s", post_id, missing)
        except Exception:
            log.exception("update meta verify skip (safe)")
    # Existing published URLs are preserved, but their final Rank Math state is
    # still read from WordPress after the update. A local SEO estimate can never
    # turn this into a "100" claim.
    try:
        live_rankmath = wp.read_rankmath_state(post_id)
        result["rank_math_ui_score"] = live_rankmath.get("rank_math_ui_score")
        live_min = int(getattr(config, "RM_LIVE_MIN_SCORE", 80) or 80)
        result["rank_math_live_min_score"] = live_min
        result["rank_math_live_verified"] = (
            not getattr(config, "RM_REQUIRE_LIVE_SCORE", True)
            or (result["rank_math_ui_score"] is not None and result["rank_math_ui_score"] >= live_min)
        )
        article["_rank_math_state"] = live_rankmath
        if not result["rank_math_live_verified"]:
            result["live_publish_blocked_reason"] = (
                "Actual WordPress Rank Math score after update is "
                f"{result['rank_math_ui_score']!r}; live minimum is {live_min}, "
                f"target is {getattr(config, 'RM_TARGET', 100)}"
            )
            log.error("Update SEO verification warning: %s", result["live_publish_blocked_reason"])
            try:
                notifier.send_telegram(
                    "⚠️ <b>UPDATED POST NEEDS SEO REVIEW</b> — actual Rank Math score is "
                    f"<b>{result['rank_math_ui_score']!r}</b>; no 100 claim was made."
                )
            except Exception:  # noqa: BLE001
                log.debug("Rank Math update warning notification failed", exc_info=True)
    except Exception:
        result["rank_math_live_verified"] = False
        result["live_publish_blocked_reason"] = "Actual WordPress Rank Math readback unavailable"
        log.exception("update Rank Math read-only state unavailable")
    article["source_url"] = None
    try:
        state.record_refresh(config.STATE_PATH, post_id)
    except Exception as exc:  # noqa: BLE001 — best-effort (silent kaadu)
        log.debug("update_post skip: %s", exc)
    try:
        from . import indexnow

        indexnow.submit(result.get("link", ""))
    except Exception as exc:  # noqa: BLE001 — best-effort (silent kaadu)
        log.debug("update_post skip: %s", exc)
    try:
        notifier.notify_updated_post(article, result)
    except Exception:
        log.exception("Update notification failed (post update safe)")
    return result


# ------------------------------------------------------------------ listicles

def create_listicle(topic: str = "", mock: bool = False) -> Dict:
    """Trending listicle post (Top 10 jobs lanti 'stories')."""
    from . import topic_engine

    idea = topic or topic_engine.pick_listicle_idea(
        state.recent_titles(config.STATE_PATH, limit=30))
    log.info("Listicle idea: %s", idea)

    if mock:
        article = topic_engine.mock_listicle(idea,
                                             state.today_count(config.STATE_PATH, date.today()))
    else:
        if not config.ai_configured():
            raise ValueError("AI provider key ledu — listicle generate avvaledu")
        recent = state.recent_titles(config.STATE_PATH, limit=30)
        article = gemini_client.generate_listicle(idea, recent, date.today().year)

    from .main import _safe_slug
    # Keep the offline/mock path side-effect-compatible with the other test
    # generators: it may create a draft in FakeWP, but must not attempt SEO
    # bridge writes or send production notifications.
    article["_mock"] = bool(mock)
    article["slug"] = seo.optimize_slug(
        _safe_slug(article.get("slug", ""), article["title"]),
        focus_keyword=article.get("focus_keyword", "") or idea)
    for k, v in (("focus_keyword", idea), ("external_links", []),
                 ("secondary_keywords", []), ("quick_answer", ""),
                 ("faq", []), ("seo_title", ""), ("list_items", None)):
        article.setdefault(k, v)
    return publish_article(article)


# ------------------------------------------------------------------ daily quiz

def create_quiz(topic: str = "", level: int = 0, questions: int = 0,
                mock: bool = False, dry_run: bool = False) -> Dict:
    """v26: Daily Quiz post — exam-style interactive MCQ quiz.

    topic empty aithe roju automatic rotation (Mon GK ... Sun Mega Mock).
    Telugu lo topic ichhina work avutundi (Gemini bilingual prompt).
    """
    from . import quiz_engine

    now_day = date.today()
    if topic:
        # manual topic (Telugu ok) — level default 2, questions default
        topic_en = topic.strip()
        topic_te = topic.strip()
        # v87: manual level clamp (9 isthe LEVEL_NAMES KeyError crash!)
        lvl = max(1, min(4, level)) if level else 2
        # v87: questions clamp (500 adigithe LLM output truncate + cost!)
        n = max(1, min(30, questions)) if questions else config.QUIZ_QUESTIONS
    else:
        topic_en, topic_te, lvl, n = quiz_engine.pick_daily_topic(now_day)
        if questions:
            n = max(1, min(30, questions))
        if level:
            lvl = max(1, min(4, level))

    log.info("Quiz mode: '%s' (%s) — L%d, %d questions%s",
             topic_en, topic_te, lvl, n, " [MOCK]" if mock else "")
    # v87: duplicate guard GENERATE MUNDU (LLM call waste kakunda) —
    # title ki quiz object avasaram ledu (topic/lvl matrame).
    _dstr = now_day.strftime("%d %B %Y")
    _qtitle = (f"Daily Quiz – {_dstr} | {topic_en} Telugu "
               f"({quiz_engine.LEVEL_NAMES[lvl]})") if not topic else \
        f"Quiz: {topic_en} Telugu ({quiz_engine.LEVEL_NAMES[lvl]})"
    if state.title_exists(config.STATE_PATH, _qtitle):
        raise ValueError(f"Quiz already generated today: {_qtitle}")
    if mock:
        quiz = quiz_engine.mock_quiz(topic_en, topic_te, lvl, n, now_day)
    else:
        if not config.ai_configured():
            raise ValueError("AI provider key ledu — quiz generate avvaledu")
        recent = state.recent_titles(config.STATE_PATH, limit=20)
        quiz = gemini_client.generate_quiz(topic_en, topic_te, lvl, n,
                                           now_day.year)
        _ = recent  # future: question-level dedupe against old quizzes

    content_html, uid = quiz_engine.build_quiz_html(quiz, topic_en, topic_te,
                                                    lvl, n, now_day)
    dstr, title = _dstr, _qtitle  # v87: pre-computed (guard generate mundu)
    focus = "daily quiz telugu" if not topic else topic_en.lower()
    article = {
        "title": title,
        "seo_title": title,
        "slug": "",  # filled below
        "category": config.QUIZ_CATEGORY,
        "tags": ["Daily Quiz", "GK Quiz Telugu", topic_en, "Current Affairs Quiz",
                 str(now_day.year)][:8],
        "meta_description": (
            f"{dstr} Daily Quiz Telugu lo — {topic_en} మీద {n} exam-style "
            f"questions, timer + negative marking + explanations. "
            f"ఆడండి, నేర్చుకోండి! (studentup.in free quiz)"),
        "focus_keyword": focus,
        "secondary_keywords": [topic_en, "quiz telugu", "gk telugu"],
        "quick_answer": (f"ఈరోజు క్విజ్: {topic_en} — {n} questions, "
                         f"Level {lvl}. Start Quiz నొక్కి వెంటనే మొదలుపెట్టండి."),
        "banner_text": f"DAILY QUIZ\n{topic_en}\nLevel {lvl} • {quiz_engine.LEVEL_NAMES[lvl]}",
        "faq": [],
        "external_links": [],
        "article_type": "quiz",
        "content_html": content_html,
        "_quiz": quiz,
        "_quiz_level": lvl,
        "_mock": mock,
        # Daily quiz is one review draft per IST day. Owner approval can
        # promote it later; the scheduler must never publish it silently.
        "_force_status": "draft",
    }
    from .main import _safe_slug
    article["slug"] = seo.optimize_slug(
        _safe_slug("", article["title"]), focus_keyword=focus)
    log.info("Quiz ready: %s (uid=%s, %d questions)", title, uid,
             len(quiz["questions"]))
    if dry_run:
        out_dir = config.OUTPUT_DIR / "quiz-dry"
        out_dir.mkdir(parents=True, exist_ok=True)
        final = article["content_html"]
        fp = out_dir / f"{article['slug']}.html"
        fp.write_text(
            "<!doctype html><html><head><meta charset='utf-8'>"
            f"<title>{article['title']}</title></head><body>"
            f"<h1>{article['title']}</h1>{final}</body></html>",
            encoding="utf-8")
        log.info("QUIZ DRY-RUN saved to %s (state lo record cheyaledu)", fp)
        return {"id": 0, "status": "dry-run", "link": str(fp)}
    return publish_article(article)


# ------------------------------------------------------------------ auto refresh

def auto_refresh(limit: int = 1, older_days: int = None) -> list:
    """Purana published posts ni kotha research tho refresh (daily maintenance).

    Google freshness signal — rankings long-term lo stable.
    """
    older = older_days if older_days is not None else config.AUTO_REFRESH_MIN_AGE_DAYS
    targets = state.posts_to_refresh(config.STATE_PATH, older_days=older, limit=limit)
    if not targets:
        log.info("Auto-refresh: eligible posts levu (min %d days old)", older)
        return []
    results = []
    for t in targets:
        try:
            log.info("Auto-refresh: post %s '%s'", t["wp_id"], t["title"][:50])
            results.append(update_post(t["wp_id"]))
        except Exception:
            log.exception("Auto-refresh fail: post %s", t["wp_id"])
    # v87: owner summary (cron silent kakunda — updates jarigayo ledo teliyali)
    try:
        if results and config.TELEGRAM_BOT_TOKEN and config.TELEGRAM_CHAT_ID:
            from .notifier import esc as _esc, send_telegram as _tg
            lines = [f"🔄 <b>Auto-refresh: {len(results)} post(s)</b>"]
            for r in results[:5]:
                if isinstance(r, dict) and not r.get("error"):
                    lines.append(f"✔ {_esc(r.get('link', ''))}")
            _tg("\n".join(lines))
    except Exception:  # noqa: BLE001 — notify never breaks cron
        log.exception("auto-refresh summary skip (safe)")
    return results
