# Go-live report — 2026-10-09 20:29

Mode: PREVIEW · 1 ok · 5 warn · 2 blocker


## ✅ 1. Server deploy-check

server ready (python · deps · files · disk)

```
==========================================================================
  🚀 DEPLOY CHECK — ee server lo deploy cheyyadaniki ready-a?
==========================================================================
  ✅ Python version       3.11.2
  ✅ Python deps          requests · pillow · beautifulsoup4 · pypdf
  ✅ Repo files           8 core files unnayi
  ✅ Write permission     /home/user/studentup/.work/Automation_charan1-arena-01a1035e-automation-charan1 writable (logs/db/state ki)
  ✅ Disk space           20.5 GB free
  ✅ Deploy artifacts     7 files (systemd/Docker/backup/cron)
  ⚠️  Git repo             .git ledu
       ↳ fix: git clone chesi deploy cheste updates easy
  ✅ Bot imports          12 modules import ok (smoke)
  ✅ Cron command         /usr/bin/python3 /home/user/studentup/.work/Automation_charan1-arena-01a1035e-automation-charan1/run.py --run
  ⚠️  .env file            ledu — defaults tho run avutundi
       ↳ fix: cp .env.example .env → WP_USERNAME/WP_APP_PASSWORD pettandi
  ⚠️  WordPress creds      ledu (audit/publish ki kavali)
       ↳ fix: wp-admin → Users → Application Passwords → .env lo pettandi
  ⚠️  Telegram notify      ledu (optional — in-app banner pani chestundi)
--------------------------------------------------------------------------
  8 ok · 4 warn · 0 fail  (0.1s)
  ✅ Ready. Next: DEPLOY.md lo mee path (VPS / Docker / shared-cron) follow cheyandi.
```


## ⛔ 2. AI providers + keys

AI key ledu — .env lo GEMINI_API_KEYS/GROQ_API_KEYS pettandi

```
======================================================================
  AI PROVIDERS — keys · models · failover order
======================================================================
  ➖ gemini      ⭐ primary · keys 0 
       model: gemini-2.5-flash
       ↳ Google AI Studio — free tier (key okkintiki rojuki ~1400 req)
  ➖ groq          fallback · keys 0 
       model: llama-3.3-70b-versatile
       ↳ Groq Cloud — free tier, chala vegam (llama-3.3-70b)
  ➖ openrouter    fallback · keys 0 
       model: openrouter/free
       ↳ OpenRouter — konni models free (`:free` suffix)
  ➖ cerebras      fallback · keys 0 
       model: llama-3.3-70b
       ↳ Cerebras — free tier, vegam
  ➖ together      fallback · keys 0 
       model: meta-llama/Llama-3.3-70B-Instruct-Turbo
       ↳ Together AI — free credits
  ➖ mistral       fallback · keys 0 
       model: mistral-small-latest
       ↳ Mistral — free tier (small models)
  ➖ openai        fallback · keys 0 
       model: gpt-4o-mini
       ↳ OpenAI — paid
  ➖ custom        fallback · keys 0 
       model: —
       ↳ Any OpenAI-compatible endpoint
----------------------------------------------------------------------
  ⛔ ే AI key ledu — bot mock/offline mode lo matrame nadustundi.
     .env lo kanisam okati pettandi, udaharanaki:
       GEMINI_API_KEYS=key1,key2,key3
       GROQ_API_KEYS=key1,key2
       AI_PROVIDER=gemini
       AI_FALLBACK_PROVIDERS=groq,openrouter,cerebras
======================================================================
```


## ⛔ 3. WordPress connection

WP_USERNAME/WP_APP_PASSWORD .env lo ledu


## ➖ 4. Categories (20 pillars)

20 pillars ready to create (--apply tho create avutai)

```
Scholarships, Central Govt Jobs, TS Govt Jobs, AP Govt Jobs, Private Jobs, Software Jobs, Part Time Jobs, Walkin Jobs, Outsourcing Jobs, Hall Tickets, Results, Internships, Online Education, Current Affairs, Exam Tips, Upcoming Exams, Abroad Jobs, Success Stories, Govt Schemes, District News
```


## ⚠️ 5. Site setup (settings · menus · SEO)

settings · footer policy menu · category SEO · robots/sitemap

```
================================================================
  🔧 WORDPRESS SITE SETUP — AUDIT (dry-run)
================================================================
  ❌ WP connect kaDU: HTTPSConnectionPool(host='studentup.in', port=443): Max retries exceeded with url: /wp-json/wp/v2/users/me?context=edit (Caused by SSLError(SSLZeroReturnError(6, 'TLS/SSL connection has been closed (EOF) (_ssl.c:992)')))
```


## ⚠️ 6. Instant indexing (IndexNow)

INDEXNOW_KEY ledu (--apply key generate chestundi)


## ➖ 7. Theme options auto-config (.env → site)

4 options ready (--apply tho push avutai) · GSC service account ledu (.env: GSC_SERVICE_ACCOUNT_FILE) · purge skipped (preview)

```
Consent Mode = 1
Consent regions = EEA,UK
ic_city = Hyderabad
ic_name = Studen…nter
```


## ➖ 8. Search Console sitemaps

GSC service account ledu (.env: GSC_SERVICE_ACCOUNT_FILE)


## ⚠️ 9. AdSense readiness

blockers unnayi (posts count / policy pages) — kinda chudandi

```
========================================================================
  💰 ADSENSE APPROVAL READINESS (pre-application gate)
========================================================================
  ── POLICY ──────────────────────────────────────────────────────
  ✅ page_privacy               Privacy policy (AdSense ki MANDATORY): built (43 KB)
  ✅ page_about                 About / editorial team (E-E-A-T): built (43 KB)
  ✅ page_contact               Contact (readers reach avvali): built (44 KB)
  ✅ page_disclaimer            Disclaimer (exam/job info accuracy): built
  ✅ page_editorial-policy      Editorial policy (how we verify): built
  ✅ privacy_google_ads_dat     privacy lo google ads dat: undi
  ✅ privacy_cookies            privacy lo cookies: undi
  ✅ privacy_third-party_vendors privacy lo third-party vendors: undi
  ✅ privacy_opt-out_link       privacy lo opt-out link: undi
  ✅ footer_links               footer lo policy links: 4
  ── CONTENT ─────────────────────────────────────────────────────
  ⛔ volume                     published posts: 0 (recommended ≥20)
      ↳ roju posts publish cheyandi (radar + top-post engine) — 20+ substantive posts tarvata apply cheyandi
  ✅ depth_gate                 useful-word floor: 600 (900+ only when the topic supports it)
  ✅ originality                originality floor: 72% (recommended ≥70%)
  ✅ qa_gate                    live QA gate (publish ki quality floor) undi
  ── NAVIGATION ──────────────────────────────────────────────────
  ✅ menu                       primary menu (fallback kuda) undi
  ✅ menu_grouped               menu grouped dropdowns (clean, 1-line)
  ✅ breadcrumbs                breadcrumbs undi (users + crawlers)
  ✅ search                     site search undi
  ✅ categories                 category sections: 10
  ── TECHNICAL ───────────────────────────────────────────────────
  ✅ robots                     robots.txt: sitemap + admin block
  ✅ sitemap                    sitemap.xml: 19 URLs
  ✅ viewport                   mobile viewport meta undi
  ✅ https_headers              security headers (nosniff · referrer · frame)
  ✅ no_placeholders            placeholder/under-construction text ledu
  ── TRUST ───────────────────────────────────────────────────────
  ✅ author_box                 author/E-E-A-T box undi
  ✅ trust_note                 post kindha verification/trust note undi
  ✅ corrections                corrections contact line undi
  ✅ sources                    source/citation block undi
  ── AD SAFETY ───────────────────────────────────────────────────
  ✅ sponsored                  SPONSORED labelling undi (house ads)
  ✅ density                    ad density cap: 5 per page (≤5 safe)
  ✅ cls                        ads CLS-safe (reserved space)
  ✅ consent                    consent mode module undi (EEA/UK)
  ✅ policy_pages_no_ads        legal pages ki ads OFF option undi (AdSense policy)
  ── PROHIBITED ──────────────────────────────────────────────────
  ✅ scan                       prohibited-content scan clean
  ── DISCOVER ────────────────────────────────────────────────────
  ✅ image_size                 ≥1200px image size: studentup-discover (1200px) (Discover large card)
  ✅ og_dims                    og:image width/height tags
  ✅ news_sitemap               news sitemap module undi
  ✅ max_preview                max-image-preview:large robots directive
------------------------------------------------------------------------
  Score: 97% (28/29 mandatory) · verdict: NOT READY
  1 blocker(s) — ivi fix cheyyakunda apply cheyyakandi
  Posts: 0 published (recommended ≥20 substantive posts before applying)

  ℹ️  HONEST LIMIT: AdSense approval, ad serving, ranking mariyu revenue
     Google + mee account + time batti untayi. Ee audit kevalam technical/
     content requirements ready aa leda ani cheptundi — approval guarantee ledu.
  artifact: /home/user/studentup/.work/Automation_charan1-arena-01a1035e-automation-charan1/output/adsense
```


## ⚠️ 10. Production safety + revenue

blockers unnayi

```
========================================================================
  PRODUCTION SAFETY + REVENUE AUDIT (v30)
========================================================================
  ✅ WordPress HTTPS           https://studentup.in
  ⛔ WordPress credentials     WP_USERNAME/WP_APP_PASSWORD missing
  ⛔ Gemini/AI key rotation    no AI provider key
  ✅ Fact guard                dates/counts must match source
  ✅ Originality floor         80% (72% minimum recommended)
  ✅ Human review mode         draft
  ✅ Live QA gate              direct publish requires QA 80/100
  ✅ Live originality gate     direct publish requires originality 72%
  ✅ Corrections contact       studentupinformative@gmail.com
  ℹ️  AdSense pre-approval gate ADSENSE_APPROVED=0; no loader or in-content ad spaces will be emitted
  ℹ️  Analytics                 GA4 disabled; no tracking script emitted
  ✅ Ad slot cap               3
  ✅ Ad CLS protection         reserved slot wrapper enabled
  ⛔ WordPress REST/auth       HTTPSConnectionPool(host='studentup.in', port=443): Max retries exceeded with url: /wp-json/wp/v2/users/me?context=edit (Caused by SSLError(SSLZeroReturnError(6
------------------------------------------------------------------------
  Result: 11 pass · 0 warnings · 3 blockers
  Google approval/revenue are never guaranteed by code; review WARN items manually.
========================================================================
```


## ⚠️ 11. 42-item launch checklist

28 code · 12 .env key kavali · 2 owner · 0 missing

```
🔑 1. Google Search Console
🔑 2. Submit sitemap
✅ 3. robots.txt check
🔑 4. Bing Webmaster + IndexNow
👤 5. Google Business Profile
🔑 6. Google Analytics (GA4)
✅ 7. Track money actions (events)
🔑 8. Microsoft Clarity
✅ 9. Core Web Vitals
✅ 10. Compress images
✅ 11. Lazy load below the fold
✅ 12. Limit fonts + third-party scripts
✅ 13. Unique page title
✅ 14. Meta description
✅ 15. One H1 per page
✅ 16. Image alt text
✅ 17. Internal links
✅ 18. City + keyword on service pages
🔑 19. LocalBusiness schema
✅ 20. Breadcrumbs
✅ 21. Social share image (Open Graph)
✅ 22. Favicon
🔑 23. Real reviews
🔑 24. Case studies
✅ 25. FAQ section
🔑 26. Real team photo
🔑 27. Map + directions
✅ 28. Privacy policy page
✅ 29. Clear CTA above the fold
✅ 30. Sticky mobile CTA
✅ 31. Thank-you page
✅ 32. Form success/error messages
🔑 33. Promise a response time
✅ 34. Clickable phone, email, logo
✅ 35. Custom 404 page
✅ 36. Fix broken links/buttons
✅ 37. Mobile layout
✅ 38. No placeholder text + current year
✅ 39. Clean nav + footer links
🔑 40. Force HTTPS + one address
✅ 41. Backups + security
👤 42. Final test on a real phone
```


## Owner TODO

1. Theme zip upload + Activate — WordPress core lo theme-install REST endpoint ledu (WP-CLI unte deploy script chestundi)
2. Search Console verify token — console lo site add chesi meta token copy → .env GSC_VERIFY_TOKEN (taruvata automatic)
3. GSC service account JSON — Google Cloud lo SA create + GSC lo aa email ki access → sitemap submit automatic avutundi
4. GA4 Measurement ID — GA4 property create → .env GA4_MEASUREMENT_ID + GA4_ENABLED=1 (taruvata automatic)
5. AdSense account + approval — Google decision — 20+ posts taruvata apply; approve ayyaka .env lo IDs pettandi
6. AdSense slot IDs — approval taruvata dashboard nunchi copy → .env ADSENSE_SLOT_* (taruvata automatic)
7. CMP id (EEA/UK) — AdSense → Privacy & messaging lo CMP on → id .env CONSENT_CMP_ID
8. Cache purge — Cloudflare token+zone .env lo pedithe purge kooda automatic
9. 20+ substantive posts publish chesaka ne AdSense apply (Google ki content kavali — code raayaledu, nijamaina content)
10. Telegram bot token (@BotFather) → .env TELEGRAM_BOT_TOKEN (taruvata chat id, broadcast anni automatic)