# Pin-to-pin certificate — Orig Feed Test 2026 Test orig feed guide

- cert: `3c0d6d474a` · date: 2026-10-06
- score: **77/100** · checks: 59/72
- Rank Math: **76/100** · words: 641
- critical fails: rm_score, people_first

| Group | Check | Result | Detail |
|---|---|---|---|
| CONTENT | Content depth (≥600 useful words) | ✅ | 641 words · 20% unique |
| CONTENT | Keyword density (0.4–3%) | ✅ | 2.34% (15x) |
| CONTENT | Keyword first paragraph lo | ❌ | ok |
| CONTENT | Keyword body lo 7+ sarlu | ✅ | 15x |
| CONTENT | FAQ 3+ ప్రశ్నలు | ❌ | 0 faq · 2 h3 |
| CONTENT | ముఖ్య వివరాలు table | ❌ | 0 table |
| CONTENT | TOC links heading ids ki match | ✅ | 3 links · ids 6 |
| SEO | Rank Math TOC block detected | ✅ | official editor marker |
| CONTENT | Dev/demo/placeholder text ledu | ✅ | clean |
| CONTENT | Paragraphs ≤140 words | ❌ | 2 long |
| CONTENT | Telugu connectives 25%+ sentences | ❌ | 0% (0/10) |
| CONTENT | Telugu script share ≥25% | ❌ | 10% |
| CONTENT | List items ≤12 words | ✅ | 0 long items |
| CONTENT | Duplicate H2s ledu | ✅ | 0 duplicates |
| CONTENT | Heading hierarchy (H1 ledu · skip ledu) | ✅ | H1 0 · level-skip 0 |
| CONTENT | Headings ≤70 chars (mobile truncate kaadu) | ✅ | 0 long |
| CONTENT | Markdown/escape leftovers ledu | ✅ | clean |
| CONTENT | List items ≤12 words | ✅ | 0 long |
| CONTENT | Table ≤5 columns (table ledu — skip) | ✅ | table ledu |
| GOOGLE READINESS | Job-guarantee/clickbait claims ledu (trust + policy) | ✅ | clean |
| SEO | Focus keyword cannibalization ledu | ✅ | skip (AttributeError) |
| SEO | Slug ≤60 chars · 3+ words | ✅ | 20 ch · 5 words |
| SEO | Meta lo CTA/action word (CTR) | ❌ | cta ['apply', 'details'] · number no |
| SEO | Secondary keywords body lo | ✅ | 4/5 used |
| MEDIA | Content images ki width/height (CLS) | ✅ | content img ledu · featured image theme handle chestundi |
| LINKS | Anchor text descriptive (click here ledu) | ✅ | 0 weak anchors |
| SEMANTIC | FAQ answers deep (faq list ledu — skip) | ✅ | faq list ledu |
| SEMANTIC | Primary entity + related entities (2+) | ✅ | 6 entities |
| SEMANTIC | ముఖ్యాంశాలు (key takeaways) box | ✅ |  |
| SEMANTIC | Question-form headings 2+ | ✅ | 2 questions |
| SEMANTIC | సంబంధిత అంశాలు block (topic cluster) | ✅ |  |
| SEMANTIC | Avg sentence ≤24 words (చదవడానికి easy) | ❌ | avg 65.1 words |
| SEMANTIC | Current year content lo (fresh signal) | ✅ | 2026 |
| SEMANTIC | Quick answer / summary block | ✅ |  |
| SEO | Title 40–62 chars | ✅ | 40 ch |
| SEO | Focus keyword title MODATLO | ✅ | pos 0 |
| SEO | Title lo number/year | ✅ | number ledu |
| SEO | Title lo power word | ✅ |  |
| SEO | Title lo positive sentiment word | ✅ |  |
| SEO | Meta 110–156 + keyword | ✅ | 151 ch |
| SEO | Slug lo keyword tokens | ✅ | feed-test-v78-orig-1 |
| SEO | Local on-page preflight passed | ⛔ | needs fixes |
| SEO | Secondary keywords | ✅ | 5 keywords |
| SCHEMA | Article JSON-LD | ✅ |  |
| SCHEMA | BreadcrumbList JSON-LD | ✅ |  |
| SCHEMA | Publisher → Organization @id | ✅ |  |
| MEDIA | Featured image | ✅ | media_id=88 |
| MEDIA | Image ≥1200px wide (Google Discover) | ✅ | upload ayyindi (WP side) |
| MEDIA | Image alt lo keyword | ✅ | orig feed test Results 2026 | StudentUp |
| MEDIA | Content lopala image (keyword alt) | ❌ | ledu |
| MEDIA | Images hotlink ledu (mana host) | ✅ | 0 external |
| LINKS | Internal links 3+ | ✅ | 3 |
| LINKS | External authority link (gov/edu) | ❌ | 0/0 |
| LINKS | At least one editorial dofollow source | ❌ | 0/0 |
| LINKS | Ad/paid links rel=sponsored | ✅ | 0/0 ad links labelled |
| LINKS | Empty anchors ledu | ✅ |  |
| ADSENSE | Ad slot content lo | ✅ | 1 slot |
| ADSENSE | House ads content ratio (≤1/600 words) | ✅ | 0 ≤ 1 |
| ADSENSE | Ad first paragraph tarvata (policy-friendly) | ✅ | top ad ok (leaderboard) |
| ADSENSE | ads.txt ready | ✅ | preview/ads.txt |
| FRESHNESS | Date published ≤ today | ✅ | auto (WP) |
| FRESHNESS | Deadline past kaadu | ✅ | n/a |
| FRESHNESS | Update ki dateModified | ✅ | auto |
| GOOGLE READINESS | inLanguage te | ✅ |  |
| GOOGLE READINESS | Named author (E-E-A-T) | ✅ |  |
| GOOGLE READINESS | Publisher (brand signal) | ✅ |  |
| GOOGLE READINESS | Editorial provenance policy | ✅ |  |
| GOOGLE READINESS | People-first evidence audit | ⛔ | 58/100 |
| GOOGLE READINESS | Demand signal (trend/priority) | ✅ | trend queue lo ledu (mari okkasarilo) |
| GOOGLE READINESS | Near-duplicate ledu (Google scaled-content) | ✅ | overlap 12% (feed-test-v78-orig-1) |
| GOOGLE READINESS | Unverified facts ledu | ✅ | 0 flags |
| GOOGLE READINESS | IndexNow submit (publish tarvata) | ✅ | auto (pipeline) |
