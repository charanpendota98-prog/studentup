# Pin-to-pin certificate — SSC CGL 2026 Apply Online · · Important Dates

- cert: `ab6dfb5891` · date: 2026-10-06
- score: **82/100** · checks: 62/72
- Rank Math: **89/100** · words: 2396
- critical fails: rm_score, people_first

| Group | Check | Result | Detail |
|---|---|---|---|
| CONTENT | Content depth (≥600 useful words) | ✅ | 2396 words · 10% unique |
| CONTENT | Keyword density (0.4–3%) | ✅ | 2.13% (51x) |
| CONTENT | Keyword first paragraph lo | ❌ | ok |
| CONTENT | Keyword body lo 7+ sarlu | ✅ | 51x |
| CONTENT | FAQ 3+ ప్రశ్నలు | ✅ | 4 faq · 38 h3 |
| CONTENT | ముఖ్య వివరాలు table | ✅ | 2 table |
| CONTENT | TOC links heading ids ki match | ✅ | 18 links · ids 53 |
| SEO | Rank Math TOC block detected | ✅ | official editor marker |
| CONTENT | Dev/demo/placeholder text ledu | ✅ | clean |
| CONTENT | Paragraphs ≤140 words | ✅ | 0 long |
| CONTENT | Telugu connectives 25%+ sentences | ❌ | 0% (0/148) |
| CONTENT | Telugu script share ≥25% | ❌ | 4% |
| CONTENT | List items ≤12 words | ✅ | 0 long items |
| CONTENT | Duplicate H2s ledu | ❌ | 3 duplicates |
| CONTENT | Heading hierarchy (H1 ledu · skip ledu) | ✅ | H1 0 · level-skip 0 |
| CONTENT | Headings ≤70 chars (mobile truncate kaadu) | ✅ | 0 long |
| CONTENT | Markdown/escape leftovers ledu | ✅ | clean |
| CONTENT | List items ≤12 words | ✅ | 0 long |
| CONTENT | Table ≤5 columns (mobile lo scroll kaadu) | ✅ | 2 cols |
| GOOGLE READINESS | Job-guarantee/clickbait claims ledu (trust + policy) | ✅ | clean |
| SEO | Focus keyword cannibalization ledu | ✅ | skip (AttributeError) |
| SEO | Slug ≤60 chars · 3+ words | ✅ | 25 ch · 5 words |
| SEO | Meta lo CTA/action word (CTR) | ✅ | cta ['apply', 'details'] · number yes |
| SEO | Secondary keywords body lo | ✅ | 7/8 used |
| MEDIA | Content images ki width/height (CLS) | ✅ | content img ledu · featured image theme handle chestundi |
| LINKS | Anchor text descriptive (click here ledu) | ✅ | 0 weak anchors |
| SEMANTIC | FAQ answers 3+ deep (12+ words) | ❌ | 1/4 deep |
| SEMANTIC | Primary entity + related entities (2+) | ✅ | 6 entities |
| SEMANTIC | ముఖ్యాంశాలు (key takeaways) box | ✅ |  |
| SEMANTIC | Question-form headings 2+ | ✅ | 38 questions |
| SEMANTIC | సంబంధిత అంశాలు block (topic cluster) | ✅ |  |
| SEMANTIC | Avg sentence ≤24 words (చదవడానికి easy) | ✅ | avg 16.3 words |
| SEMANTIC | Current year content lo (fresh signal) | ✅ | 2026 |
| SEMANTIC | Quick answer / summary block | ✅ |  |
| SEO | Title 40–62 chars | ✅ | 45 ch |
| SEO | Focus keyword title MODATLO | ✅ | pos 0 |
| SEO | Title lo number/year | ✅ | number ledu |
| SEO | Title lo power word | ✅ |  |
| SEO | Title lo positive sentiment word | ✅ |  |
| SEO | Meta 110–156 + keyword | ✅ | 154 ch |
| SEO | Slug lo keyword tokens | ✅ | ssc-cgl-2026-apply-online |
| SEO | Local on-page preflight passed | ⛔ | needs fixes |
| SEO | Secondary keywords | ✅ | 8 keywords |
| SCHEMA | Article JSON-LD | ✅ |  |
| SCHEMA | BreadcrumbList JSON-LD | ✅ |  |
| SCHEMA | Publisher → Organization @id | ✅ |  |
| MEDIA | Featured image | ❌ | ledu |
| MEDIA | Image ≥1200px wide (Google Discover) | ❌ | ledu |
| MEDIA | Image alt lo keyword | ✅ | ssc cgl 2026 apply online – Central Govt Jobs 2026 | student |
| MEDIA | Content lopala image (keyword alt) | ❌ | ledu |
| MEDIA | Images hotlink ledu (mana host) | ✅ | 0 external |
| LINKS | Internal links 3+ | ✅ | 5 |
| LINKS | External authority link (gov/edu) | ✅ | 2/2 |
| LINKS | At least one editorial dofollow source | ✅ | 2/2 |
| LINKS | Ad/paid links rel=sponsored | ✅ | 0/0 ad links labelled |
| LINKS | Empty anchors ledu | ✅ |  |
| ADSENSE | Ad slot content lo | ✅ | 1 slot |
| ADSENSE | House ads content ratio (≤1/600 words) | ✅ | 0 ≤ 3 |
| ADSENSE | Ad first paragraph tarvata (policy-friendly) | ✅ | top ad ok (leaderboard) |
| ADSENSE | ads.txt ready | ✅ | preview/ads.txt |
| FRESHNESS | Date published ≤ today | ✅ | auto (WP) |
| FRESHNESS | Deadline past kaadu | ✅ | n/a |
| FRESHNESS | Update ki dateModified | ✅ | auto |
| GOOGLE READINESS | inLanguage te | ✅ |  |
| GOOGLE READINESS | Named author (E-E-A-T) | ✅ |  |
| GOOGLE READINESS | Publisher (brand signal) | ✅ |  |
| GOOGLE READINESS | Editorial provenance policy | ✅ |  |
| GOOGLE READINESS | People-first evidence audit | ⛔ | 67/100 |
| GOOGLE READINESS | Demand signal (trend/priority) | ✅ | trend queue lo ledu (mari okkasarilo) |
| GOOGLE READINESS | Near-duplicate ledu (Google scaled-content) | ✅ | overlap 24% (ssc-cgl-2026-apply-online) |
| GOOGLE READINESS | Unverified facts ledu | ✅ | 0 flags |
| GOOGLE READINESS | IndexNow submit (publish tarvata) | ✅ | auto (pipeline) |
