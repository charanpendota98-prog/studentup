# Pin-to-pin certificate — Test Keyword Test v77-copy-1 guide · · Complete Guide

- cert: `080b34b064` · date: 2026-10-11
- score: **75/100** · checks: 59/72
- Rank Math: **72/100** · words: 516
- critical fails: rm_score, people_first

| Group | Check | Result | Detail |
|---|---|---|---|
| CONTENT | Content depth (≥600 useful words) | ❌ | 516 words · 36% unique |
| CONTENT | Keyword density (0.4–3%) | ❌ | 3.29% (17x) |
| CONTENT | Keyword first paragraph lo | ❌ | ok |
| CONTENT | Keyword body lo 7+ sarlu | ✅ | 17x |
| CONTENT | FAQ 3+ ప్రశ్నలు | ✅ | 0 faq · 6 h3 |
| CONTENT | ముఖ్య వివరాలు table | ✅ | 1 table |
| CONTENT | TOC links heading ids ki match | ✅ | 7 links · ids 10 |
| SEO | Rank Math TOC block detected | ✅ | official editor marker |
| CONTENT | Dev/demo/placeholder text ledu | ✅ | clean |
| CONTENT | Paragraphs ≤140 words | ✅ | 0 long |
| CONTENT | Telugu connectives 25%+ sentences | ❌ | 0% (0/45) |
| CONTENT | Telugu script share ≥25% | ❌ | 20% |
| CONTENT | List items ≤12 words | ❌ | 1 long items |
| CONTENT | Duplicate H2s ledu | ✅ | 0 duplicates |
| CONTENT | Heading hierarchy (H1 ledu · skip ledu) | ✅ | H1 0 · level-skip 0 |
| CONTENT | Headings ≤70 chars (mobile truncate kaadu) | ✅ | 0 long |
| CONTENT | Markdown/escape leftovers ledu | ✅ | clean |
| CONTENT | List items ≤12 words | ❌ | 1 long |
| CONTENT | Table ≤5 columns (mobile lo scroll kaadu) | ✅ | 2 cols |
| GOOGLE READINESS | Job-guarantee/clickbait claims ledu (trust + policy) | ✅ | clean |
| SEO | Focus keyword cannibalization ledu | ✅ | skip (AttributeError) |
| SEO | Slug ≤60 chars · 3+ words | ✅ | 23 ch · 5 words |
| SEO | Meta lo CTA/action word (CTR) | ❌ | cta ['apply', 'details'] · number no |
| SEO | Secondary keywords body lo | ✅ | 5/5 used |
| MEDIA | Content images ki width/height (CLS) | ✅ | content img ledu · featured image theme handle chestundi |
| LINKS | Anchor text descriptive (click here ledu) | ✅ | 0 weak anchors |
| SEMANTIC | FAQ answers deep (faq list ledu — skip) | ✅ | faq list ledu |
| SEMANTIC | Primary entity + related entities (2+) | ✅ | 6 entities |
| SEMANTIC | ముఖ్యాంశాలు (key takeaways) box | ✅ |  |
| SEMANTIC | Question-form headings 2+ | ✅ | 6 questions |
| SEMANTIC | సంబంధిత అంశాలు block (topic cluster) | ✅ |  |
| SEMANTIC | Avg sentence ≤24 words (చదవడానికి easy) | ✅ | avg 9.1 words |
| SEMANTIC | Current year content lo (fresh signal) | ✅ | 2026 |
| SEMANTIC | Quick answer / summary block | ✅ |  |
| SEO | Title 40–62 chars | ✅ | 53 ch |
| SEO | Focus keyword title MODATLO | ✅ | pos 0 |
| SEO | Title lo number/year | ✅ | number ledu |
| SEO | Title lo power word | ✅ |  |
| SEO | Title lo positive sentiment word | ✅ |  |
| SEO | Meta 110–156 + keyword | ✅ | 147 ch |
| SEO | Slug lo keyword tokens | ✅ | test-keyword-v77-copy-1 |
| SEO | Local on-page preflight passed | ⛔ | needs fixes |
| SEO | Secondary keywords | ✅ | 5 keywords |
| SCHEMA | Article JSON-LD | ✅ |  |
| SCHEMA | BreadcrumbList JSON-LD | ✅ |  |
| SCHEMA | Publisher → Organization @id | ✅ |  |
| MEDIA | Featured image | ✅ | media_id=88 |
| MEDIA | Image ≥1200px wide (Google Discover) | ✅ | upload ayyindi (WP side) |
| MEDIA | Image alt lo keyword | ✅ | test keyword Results 2026 | StudentUp |
| MEDIA | Content lopala image (keyword alt) | ❌ | ledu |
| MEDIA | Images hotlink ledu (mana host) | ✅ | 0 external |
| LINKS | Internal links 3+ | ✅ | 3 |
| LINKS | External authority link (gov/edu) | ❌ | 0/0 |
| LINKS | At least one editorial dofollow source | ❌ | 0/0 |
| LINKS | Ad/paid links rel=sponsored | ✅ | 0/0 ad links labelled |
| LINKS | Empty anchors ledu | ✅ |  |
| ADSENSE | Ad slot content lo | ✅ | 1 slot |
| ADSENSE | House ads content ratio (≤1/600 words) | ✅ | 0 ≤ 1 |
| ADSENSE | Ad first paragraph tarvata (policy-friendly) | ✅ | top ad ok (leaderboard) |
| ADSENSE | ads.txt ready | ✅ | preview/ads.txt |
| FRESHNESS | Date published ≤ today | ✅ | auto (WP) |
| FRESHNESS | Deadline past kaadu | ✅ | n/a |
| FRESHNESS | Update ki dateModified | ✅ | auto |
| GOOGLE READINESS | inLanguage te | ✅ |  |
| GOOGLE READINESS | Named author (E-E-A-T) | ✅ |  |
| GOOGLE READINESS | Publisher (brand signal) | ✅ |  |
| GOOGLE READINESS | Editorial provenance policy | ✅ |  |
| GOOGLE READINESS | People-first evidence audit | ⛔ | 75/100 |
| GOOGLE READINESS | Demand signal (trend/priority) | ✅ | trend queue lo ledu (mari okkasarilo) |
| GOOGLE READINESS | Near-duplicate ledu (Google scaled-content) | ✅ | overlap 14% (test-keyword-v77-copy-1) |
| GOOGLE READINESS | Unverified facts ledu | ✅ | 0 flags |
| GOOGLE READINESS | IndexNow submit (publish tarvata) | ✅ | auto (pipeline) |
