# Pin-to-pin certificate — TSPSC Group 2 Notification గ్రూప్-2 నోటిఫికేషన్ విడుదల

- cert: `d43fda02df` · date: 2026-10-08
- score: **100/100** · checks: 73/73
- Rank Math: **100/100** · words: 2142
- critical fails: ఏమీ లేదు ✔

| Group | Check | Result | Detail |
|---|---|---|---|
| CONTENT | Content depth (≥600 useful words) | ✅ | 2142 words · 12% unique |
| CONTENT | Keyword density (0.4–3%) | ✅ | 0.42% (9x) |
| CONTENT | Keyword first paragraph lo | ✅ | ok |
| CONTENT | Keyword body lo 7+ sarlu | ✅ | 9x |
| CONTENT | FAQ 3+ ప్రశ్నలు | ✅ | 4 faq · 16 h3 |
| CONTENT | ముఖ్య వివరాలు table | ✅ | 1 table |
| CONTENT | TOC links heading ids ki match | ✅ | 12 links · ids 24 |
| SEO | Rank Math TOC block detected | ✅ | official editor marker |
| CONTENT | Dev/demo/placeholder text ledu | ✅ | clean |
| CONTENT | Paragraphs ≤140 words | ✅ | 0 long |
| CONTENT | Telugu connectives 25%+ sentences | ✅ | 43% (67/157) |
| CONTENT | Telugu script share ≥25% | ✅ | 91% |
| CONTENT | List items ≤12 words | ✅ | 0 long items |
| CONTENT | Duplicate H2s ledu | ✅ | 0 duplicates |
| CONTENT | Heading hierarchy (H1 ledu · skip ledu) | ✅ | H1 0 · level-skip 0 |
| CONTENT | Headings ≤70 chars (mobile truncate kaadu) | ✅ | 0 long |
| CONTENT | Markdown/escape leftovers ledu | ✅ | clean |
| CONTENT | List items ≤12 words | ✅ | 0 long |
| CONTENT | Table ≤5 columns (mobile lo scroll kaadu) | ✅ | 2 cols |
| GOOGLE READINESS | Job-guarantee/clickbait claims ledu (trust + policy) | ✅ | clean |
| SEO | Focus keyword cannibalization ledu | ✅ | skip (AttributeError) |
| SEO | Slug ≤60 chars · 3+ words | ✅ | 32 ch · 5 words |
| SEO | Meta lo CTA/action word (CTR) | ✅ | cta ['దరఖాస్తు', 'వివరాలు'] · number yes |
| SEO | Secondary keywords body lo | ✅ | 3/3 used |
| MEDIA | Content images ki width/height (CLS) | ✅ | 0/1 without size |
| LINKS | Anchor text descriptive (click here ledu) | ✅ | 0 weak anchors |
| SEMANTIC | FAQ answers 3+ deep (12+ words) | ✅ | 4/4 deep |
| SEMANTIC | Primary entity + related entities (2+) | ✅ | 6 entities |
| SEMANTIC | ముఖ్యాంశాలు (key takeaways) box | ✅ |  |
| SEMANTIC | Question-form headings 2+ | ✅ | 5 questions |
| SEMANTIC | సంబంధిత అంశాలు block (topic cluster) | ✅ |  |
| SEMANTIC | Avg sentence ≤24 words (చదవడానికి easy) | ✅ | avg 13.1 words |
| SEMANTIC | Current year content lo (fresh signal) | ✅ | 2026 |
| SEMANTIC | Quick answer / summary block | ✅ |  |
| SEO | Title 40–62 chars | ✅ | 54 ch |
| SEO | Focus keyword title MODATLO | ✅ | pos 0 |
| SEO | Title lo number/year | ✅ | number ledu |
| SEO | Title lo power word | ✅ |  |
| SEO | Title lo positive sentiment word | ✅ |  |
| SEO | Meta 110–156 + keyword | ✅ | 139 ch |
| SEO | Slug lo keyword tokens | ✅ | tspsc-group-notification-group-2 |
| SEO | Local on-page preflight passed | ✅ | pass |
| SEO | Secondary keywords | ✅ | 3 keywords |
| SCHEMA | Article JSON-LD | ✅ |  |
| SCHEMA | BreadcrumbList JSON-LD | ✅ |  |
| SCHEMA | JobPosting (recruitment unte) | ✅ |  |
| SCHEMA | Publisher → Organization @id | ✅ |  |
| MEDIA | Featured image | ✅ | media_id=999 |
| MEDIA | Image ≥1200px wide (Google Discover) | ✅ | 1200x675 |
| MEDIA | Image alt lo keyword | ✅ | TSPSC Group 2 Notification – Government Jobs 2026 | studentu |
| MEDIA | Content lopala image (keyword alt) | ✅ | TSPSC Group 2 Notification – Government Jobs 2026  |
| MEDIA | Images hotlink ledu (mana host) | ✅ | 0 external |
| LINKS | Internal links 3+ | ✅ | 7 |
| LINKS | External authority link (gov/edu) | ✅ | 2/2 |
| LINKS | At least one editorial dofollow source | ✅ | 2/2 |
| LINKS | Ad/paid links rel=sponsored | ✅ | 0/0 ad links labelled |
| LINKS | Empty anchors ledu | ✅ |  |
| ADSENSE | Ad slot content lo | ✅ | 1 slot |
| ADSENSE | House ads content ratio (≤1/600 words) | ✅ | 1 ≤ 3 |
| ADSENSE | Ad first paragraph tarvata (policy-friendly) | ✅ | top ad ok (leaderboard) |
| ADSENSE | ads.txt ready | ✅ | preview/ads.txt |
| FRESHNESS | Date published ≤ today | ✅ | 2026-10-08 |
| FRESHNESS | Deadline past kaadu | ✅ | 2026-10-09 |
| FRESHNESS | Update ki dateModified | ✅ | auto |
| GOOGLE READINESS | inLanguage te | ✅ |  |
| GOOGLE READINESS | Named author (E-E-A-T) | ✅ |  |
| GOOGLE READINESS | Publisher (brand signal) | ✅ |  |
| GOOGLE READINESS | Editorial provenance policy | ✅ |  |
| GOOGLE READINESS | People-first evidence audit | ✅ | 100/100 |
| GOOGLE READINESS | Demand signal (trend/priority) | ✅ | trend queue lo ledu (mari okkasarilo) |
| GOOGLE READINESS | Near-duplicate ledu (Google scaled-content) | ✅ | fingerprints levu |
| GOOGLE READINESS | Unverified facts ledu | ✅ | 0 flags |
| GOOGLE READINESS | IndexNow submit (publish tarvata) | ✅ | auto (pipeline) |
