#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""v233 — HOME: space fix + naukri-style scrolling category rail.

Owner (2 screenshots + voice):
  * "Government Jobs, Results & Notifications — idi avasaram ledu okaynaa."
    → phone lo aa heading space baga tinestundi.
  * "Search StudentUp" ante chalu.
  * "Latest jobs click chethe ANNI jobs open avvali, latest ga chesinavi post."
  * "TS govt jobs, AP jobs, central ... neat icons tho ravali, naukri lo la
    neat ga, ADVANCED ga SCROLLING kinda ravali, anni icons neat ga."

Idi apply chese script (preview side). Theme side header/premium/front-page
lo direct ga unnayi. Run: python3 tools/apply_v233_home.py
"""
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent

#: naukri-style rail — (icon, label, hint, href)
CATS = [
    ("bank",     "TS Govt Jobs",   "TSPSC · Police",     "../pages/ts-jobs-hub.html"),
    ("bank",     "AP Govt Jobs",   "APPSC · DSC",        "index.html#jobs"),
    ("flag",     "Central Jobs",   "SSC · UPSC · RRB",   "index.html#jobs"),
    ("ticket",   "Hall Tickets",   "Admit cards",        "../pages/results-hub.html"),
    ("doc",      "Results",        "Marks · cutoff",     "../pages/results-hub.html"),
    ("walk",     "Walk-in Jobs",   "This week",          "index.html#jobs"),
    ("laptop",   "Software Jobs",  "IT · fresher",       "index.html#jobs"),
    ("trophy",   "Success Stories", "Verified journeys", "index.html#jobs"),
    ("building", "Private Jobs",   "Off-campus",         "index.html#jobs"),
    ("news",     "Current Affairs", "Daily GK",          "index.html#jobs"),
]


def ic(n, s):
    return (f'<svg class="su-uicon su-uicon-{n}" width="{s}" height="{s}" viewBox="0 0 24 24" '
            f'fill="currentColor" aria-hidden="true" focusable="false"><use href="#su-i-{n}"/></svg>')


def rail_html():
    L = ['  <section class="su-catwrap" aria-label="Browse by section">',
         '    <div class="wrap">',
         '      <div class="su-cathead"><b>Browse by section</b>'
         '<a class="su-viewall" href="index.html#jobs">All sections →</a></div>',
         '      <div class="su-catrail" role="list">']
    for i, (icon, lab, hint, href) in enumerate(CATS, start=1):
        L.append(f'        <a role="listitem" class="su-cat c{i}" href="{href}">'
                 f'<span class="su-cat-ic">{ic(icon, 22)}</span>'
                 f'<b>{lab}</b><small>{hint}</small></a>')
    L.append('      </div>')
    L.append('    </div>')
    L.append('  </section>')
    return "\n".join(L) + "\n"


def main():
    for rel in ("preview/worldclass/index.html", "preview/worldclass/standalone.html"):
        p = ROOT / rel
        s = p.read_text(encoding="utf-8")

        # 1) H1 — DOM lo untundi (SEO), visual ga poindi
        s = s.replace('<h1 class="su-hero-title">', '<h1 class="su-hero-title su-h1-quiet">')
        # 2) search placeholder
        s = re.sub(r'placeholder="Search TSPSC[^"]*"',
                   'placeholder="Search StudentUp — jobs, hall tickets, results…"', s)
        # 3) rail — hero ki VENTANE kinda (slider kante mundu)
        if "su-catrail" not in s:
            k = s.find('  <!-- ================== LATEST JOBS SLIDING TRACK ================== -->')
            if k < 0:
                k = s.index('<section class="su-slider-sec"')
            s = s[:k] + rail_html() + "\n" + s[k:]
        p.write_text(s, encoding="utf-8")
        print("  home hero + rail:", rel)


if __name__ == "__main__":
    main()
