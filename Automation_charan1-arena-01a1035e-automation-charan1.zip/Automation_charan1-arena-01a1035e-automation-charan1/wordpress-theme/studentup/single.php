<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<?php
/**
 * Single post — article layout: meta, content, ads, share, related, trust note.
 *
 * @package studentup
 */

get_header();
?>
<div class="su-progress" aria-hidden="true"><span id="su-progress-bar"></span></div>
<main id="main">
	<div class="wrap">
		<div class="su-layout">
			<div class="su-main">
		<?php
		while ( have_posts() ) :
			the_post();
			?>
			<div class="crumbs"><?php echo wp_kses_post( studentup_breadcrumbs() ); ?></div>
			<article <?php post_class( 'article' ); ?>>
				<div class="article-head">
					<h1><?php the_title(); ?></h1>
					<div class="article-meta">
						<span class="su-am su-am-date"><?php echo studentup_ui_icon( 'calendar', 14 ); // phpcs:ignore WordPress.Security.EscapeOutput -- trusted SVG ?> <?php echo esc_html( get_the_date() ); ?></span>
						<?php echo wp_kses_post( studentup_last_updated() ); ?>
						<?php // studentup_reading_time() intentionally not shown on article pages. ?>
						<?php $su_cats = get_the_category(); ?>
						<?php if ( $su_cats ) : ?>
							<span class="su-am su-am-cat"><?php echo studentup_ui_icon( 'tag', 14 ); // phpcs:ignore WordPress.Security.EscapeOutput -- trusted SVG ?> <?php echo esc_html( $su_cats[0]->name ); ?></span>
						<?php endif; ?>
						<?php
						if ( function_exists( 'studentup_qual_labels' ) ) {
							$su_q = studentup_qual_labels( get_the_ID(), 3 );
							if ( $su_q ) {
								echo '<span class="su-am su-am-qual">' . studentup_ui_icon( 'check', 14 ) . ' ' . esc_html( implode( ' · ', $su_q ) ) . '</span>'; // phpcs:ignore WordPress.Security.EscapeOutput -- trusted SVG
							}
							$su_badge = studentup_last_date_badge( get_the_ID() );
							if ( $su_badge ) {
								echo '<span>' . wp_kses_post( $su_badge ) . '</span>';
							}
						}
						?>
					</div>
					<?php // Byline is intentionally omitted from the article header; schema retains publisher/author data. ?>
				</div>

				<?php if ( function_exists( 'studentup_reader_toolbar' ) ) : ?>
					<?php studentup_reader_toolbar(); ?>
				<?php endif; ?>

				<?php if ( function_exists( 'studentup_audio_reader' ) ) : ?>
					<?php studentup_audio_reader(); ?>
				<?php endif; ?>

				<?php if ( has_post_thumbnail() ) : ?>
					<figure class="su-featured-hero">
						<?php the_post_thumbnail( 'studentup-discover', array(
							'loading'       => 'eager',
							'fetchpriority' => 'high',
							'decoding'      => 'async',
							'alt'           => esc_attr( get_the_title() ),
						) ); ?>
					</figure>
				<?php endif; ?>

				<?php echo wp_kses_post( studentup_save_button( 0, 'su-save-single' ) ); // v92: 🔖 save-for-later ?>
				<?php if ( function_exists( 'studentup_tool_buttons' ) ) : ?>
					<?php echo wp_kses_post( studentup_tool_buttons( 0, 'single' ) ); ?>
				<?php endif; ?>
				<?php if ( function_exists( 'studentup_source_verification_notice' ) ) : ?>
					<?php echo wp_kses_post( studentup_source_verification_notice( get_the_ID() ) ); ?>
				<?php endif; ?>

				<?php echo function_exists( 'studentup_expired_notice' ) ? wp_kses_post( studentup_expired_notice() ) : ''; ?>

				<?php studentup_updated_stamp(); // v144: honest freshness line ?>

				<?php studentup_ad( 'mid' ); ?>

				<?php
				if ( function_exists( 'studentup_quick_summary_box' ) ) {
					studentup_quick_summary_box();
				}
				?>
				<?php
				if ( function_exists( 'studentup_sponsor_partner_box' ) ) {
					studentup_sponsor_partner_box();
				}
				?>

				<?php studentup_keyfacts_box(); // v158 ?>
				<?php
				if ( function_exists( 'studentup_age_calculator_block' ) ) {
					studentup_age_calculator_block();
				}
				?>
				<?php
				if ( function_exists( 'studentup_fee_calculator_block' ) ) {
					studentup_fee_calculator_block();
				}
				?>
				<?php
				if ( function_exists( 'studentup_video_ad_slot' ) ) {
					studentup_video_ad_slot();
				}
				?>
				<div class="article-content" id="su-details"><?php the_content(); ?></div>   <?php // v175: id — apply bar "Full details" ghost button anchor (puratham anchor ledu → click emi cheyaledu). ?>
				<?php
				if ( function_exists( 'studentup_syllabus_tracker_block' ) ) {
					studentup_syllabus_tracker_block();
				}
				?>
				<?php
				if ( function_exists( 'studentup_faq_box' ) ) {
					studentup_faq_box();
				}
				?>
				<?php
				if ( function_exists( 'studentup_smart_recirculation_box' ) ) {
					studentup_smart_recirculation_box();
				}
				?>
				<?php
				if ( function_exists( 'studentup_community_pulse_card' ) ) {
					studentup_community_pulse_card();
				}
				?>
				<?php
				if ( function_exists( 'studentup_status_card_generator' ) ) {
					studentup_status_card_generator();
				}
				?>

				<div class="share" aria-label="Share">
					<a class="su-share-btn su-share-wa" href="https://wa.me/?text=<?php echo rawurlencode( get_the_title() . ' — ' . get_permalink() ); ?>" target="_blank" rel="noopener"><?php echo studentup_social_icon( 'whatsapp', 15 ); // phpcs:ignore WordPress.Security.EscapeOutput -- trusted SVG ?> Share on WhatsApp</a>
					<a class="su-share-btn su-share-tg" href="https://t.me/share/url?url=<?php echo rawurlencode( get_permalink() ); ?>&text=<?php echo rawurlencode( get_the_title() ); ?>" target="_blank" rel="noopener"><?php echo studentup_social_icon( 'telegram', 15 ); // phpcs:ignore WordPress.Security.EscapeOutput -- trusted SVG ?> Share on Telegram</a>
					<a class="su-share-btn su-share-x" href="<?php echo esc_url( 'https://twitter.com/intent/tweet?url=' . rawurlencode( get_permalink() ) ); ?>" target="_blank" rel="noopener"><?php echo studentup_social_icon( 'x', 14 ); // phpcs:ignore WordPress.Security.EscapeOutput -- trusted SVG ?> Share on X</a>
					<button type="button" class="su-copy su-share-copy" data-url="<?php echo esc_url( get_permalink() ); ?>"><?php echo studentup_social_icon( 'link', 14 ); // phpcs:ignore WordPress.Security.EscapeOutput -- trusted SVG ?> Copy link</button>
				</div>

				<?php if ( has_tag() ) : ?>
					<div class="su-tags" aria-label="Tags"><?php echo studentup_ui_icon( 'tag', 13 ); // phpcs:ignore WordPress.Security.EscapeOutput -- trusted SVG ?> <?php the_tags( '', ' · ', '' ); ?></div>
				<?php endif; ?>

				<?php studentup_author_box(); ?>

				<?php studentup_trust_note(); ?>

				<nav class="post-nav" aria-label="More posts">
					<span class="post-nav-prev"><?php previous_post_link( '%link', '← %title' ); ?></span>
					<span class="post-nav-next"><?php next_post_link( '%link', '%title →' ); ?></span>
				</nav>
			</article>

			<?php
			// v96: Up Next — reader tap = NIJAMAINA kotha pageview (policy-safe
			// ad refresh). Ad ki MUNDU pedatunnam: content link modata, ad tarvata.
			if ( function_exists( 'studentup_upnext_block' ) ) {
				studentup_upnext_block();
			}
			?>
			<?php studentup_helpful_box(); // v144: browser-only helpfulness vote ?>

			<?php studentup_ad( 'below-content' ); ?>
			<?php
			if ( comments_open() || get_comments_number() ) {
				comments_template();
			}
			?>

			<?php
			$su_rel  = get_the_category();
			$su_cat  = $su_rel ? wp_list_pluck( $su_rel, 'term_id' ) : array();
			$su_tags = wp_get_post_tags( get_the_ID(), array( 'fields' => 'ids' ) );
			// v210: related posts ALWAYS chupinchali — old code `tags && category`
			// strict-gate valla tags leni bot posts ki empty section vachedi.
			// Ippudu 3-step relevance: (1) tag+category exact, (2) tag-only
			// cross-category same-topic, (3) same-category latest fill — 4 cards
			// (phone lo 2x2 neat grid). Ids-only light queries, count vaddu.
			$su_picks = array();
			if ( $su_cat && $su_tags ) {
				$su_picks = get_posts(
					array(
						'fields'              => 'ids',
						'posts_per_page'      => 4,
						'category__in'        => $su_cat,
						'tag__in'             => $su_tags,
						'post__not_in'        => array( get_the_ID() ),
						'ignore_sticky_posts' => true,
						'no_found_rows'       => true, // v69 perf: count query vaddu
					)
				);
			}
			if ( count( $su_picks ) < 4 && $su_tags ) {
				$su_picks = array_merge(
					$su_picks,
					get_posts(
						array(
							'fields'              => 'ids',
							'posts_per_page'      => 4 - count( $su_picks ),
							'tag__in'             => $su_tags,
							'post__not_in'        => array_merge( array( get_the_ID() ), $su_picks ),
							'ignore_sticky_posts' => true,
							'no_found_rows'       => true,
						)
					)
				);
			}
			if ( count( $su_picks ) < 4 && $su_cat ) {
				$su_picks = array_merge(
					$su_picks,
					get_posts(
						array(
							'fields'              => 'ids',
							'posts_per_page'      => 4 - count( $su_picks ),
							'category__in'        => $su_cat,
							'post__not_in'        => array_merge( array( get_the_ID() ), $su_picks ),
							'ignore_sticky_posts' => true,
							'no_found_rows'       => true,
						)
					)
				);
			}
			if ( ! $su_picks ) {
				// Category kuda leni rare post — ikkada kuda empty section
				// vaddu; site-lo latest updates tho fill.
				$su_picks = get_posts(
					array(
						'fields'              => 'ids',
						'posts_per_page'      => 4,
						'post__not_in'        => array( get_the_ID() ),
						'ignore_sticky_posts' => true,
						'no_found_rows'       => true,
					)
				);
			}
			if ( $su_picks ) {
				echo '<div class="sectionhead"><div><h2>ఇవి కూడా చూడండి</h2></div></div><div class="newsgrid">';
				$su_i = 0;
				foreach ( $su_picks as $su_pid ) {
					$su_pick = get_post( $su_pid );
					if ( ! $su_pick ) {
						continue;
					}
					$GLOBALS['post'] = $su_pick; // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited
					setup_postdata( $su_pick );
					studentup_card( $su_i );
					$su_i++;
				}
				echo '</div>';
				wp_reset_postdata();
			}
			?>
		<?php endwhile; ?>
			</div><!-- /.su-main -->
			<?php get_sidebar(); // v191.5: article sidebar (300x250) — highest viewability ?>
		</div><!-- /.su-layout -->
	</div>
</main>
<?php
studentup_calendar_button();
studentup_pdf_button();
studentup_up_next();

get_footer();
