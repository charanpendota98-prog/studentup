# -*- coding: utf-8 -*-
"""v250 — Daily Quiz IST rollover fix (kotha quiz roju raatri 12:00 ki).

Bug: quiz day key `gmdate('Y-m-d')` = UTC. Valla
  · kotha quiz udayam 5:30 IST ki marutundi (raatri 12:00 kaadu),
  · bot raatri 00:30 IST ki push chesthe "nenna" key lo padutundi.
Fix: studentup_quiz_ist_date() / studentup_quiz_ist_daynum() —
master checklist #136 (IST) + #137 (midnight rollover).

PHP logic ni Python lo replicate chesi verify chestunnam (sandbox lo PHP ledu).
"""
import os, re, sys
from datetime import datetime, timedelta, timezone

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
QUIZ = os.path.join(ROOT, "wordpress-theme", "studentup", "inc", "quiz.php")

IST = timezone(timedelta(hours=5, minutes=30))
fails = []
def ck(name, cond, extra=""):
    print(("  %-56s " % name) + ("✔" if cond else "✘ " + str(extra)))
    if not cond:
        fails.append(name)

def php_ist_date(ts, shift=0):
    """PHP: gmdate('Y-m-d', time() + 5h30m + shift*86400)"""
    return datetime.fromtimestamp(ts + 5 * 3600 + 30 * 60 + shift * 86400,
                                  tz=timezone.utc).strftime("%Y-%m-%d")

def main():
    print("v250 — quiz IST rollover")
    s = open(QUIZ, encoding="utf-8").read()

    ck("IST date helper undi", "function studentup_quiz_ist_date(" in s)
    ck("IST daynum helper undi", "function studentup_quiz_ist_daynum(" in s)
    ck("5h30m offset", "5 * HOUR_IN_SECONDS" in s and "30 * MINUTE_IN_SECONDS" in s)
    ck("bot store key IST", "$today_key   = studentup_quiz_ist_date()" in s)
    ck("REST intake key IST", "$today = studentup_quiz_ist_date()" in s)
    ck("rotation seed IST", "$day    = studentup_quiz_ist_daynum( $shift )" in s)
    ck("recent days IST", "studentup_quiz_ist_date( -$i )" in s)
    # 'gmdate(\'Y-m-d\')' no-arg form (= UTC today) ikapai undakudadu;
    # helper lopala gmdate('Y-m-d', $ts) matrame correct.
    code = "\n".join(l for l in s.split("\n") if not l.lstrip().startswith("*"))
    ck("UTC 'today' form ikapai ledu (code lo)",
       len(re.findall(r"gmdate\(\s*'Y-m-d'\s*\)", code)) == 0)
    ck("current_time('timestamp') quiz day ki vadaledu",
       "current_time( 'timestamp' ) - ( $i * DAY_IN_SECONDS )" not in s)

    # --- behaviour: rollover exactly at IST midnight ---
    # 23:59 IST and 00:01 IST must be different days
    base = datetime(2026, 10, 11, 23, 59, 0, tzinfo=IST)
    t1 = base.timestamp()
    t2 = (base + timedelta(minutes=2)).timestamp()
    ck("23:59 IST = 11th", php_ist_date(t1) == "2026-10-11", php_ist_date(t1))
    ck("00:01 IST = 12th (rollover IST midnight)",
       php_ist_date(t2) == "2026-10-12", php_ist_date(t2))

    # old UTC logic would still say 11th at 00:01 IST — regression proof
    utc_day = datetime.fromtimestamp(t2, tz=timezone.utc).strftime("%Y-%m-%d")
    ck("purana UTC logic tappu ani prove", utc_day == "2026-10-11", utc_day)

    # bot push at 00:30 IST lands on the new day
    t3 = datetime(2026, 10, 12, 0, 30, tzinfo=IST).timestamp()
    ck("bot 00:30 IST push = ade roju key", php_ist_date(t3) == "2026-10-12")

    # 05:29 IST still same day (old bug flipped here)
    t4 = datetime(2026, 10, 12, 5, 29, tzinfo=IST).timestamp()
    ck("05:29 IST ippatiki 12th (5:30 flip bug poyindi)",
       php_ist_date(t4) == "2026-10-12")

    # shift -1 = yesterday
    ck("shift -1 = nenna", php_ist_date(t3, -1) == "2026-10-11")

    # daily store + freshness contract
    ck("roju kotha questions (bot store merge)", "studentup_daily_quiz_store" in s)
    ck("REST intake permission callback", "permission_callback" in s)
    ck("server-side scoring intact", "studentup_quiz_answers_from_post" in s)

    print("=" * 74)
    if fails:
        print("  %d TEST(S) FAILED ✘" % len(fails)); sys.exit(1)
    print("  anni v250 checks pass ✔")

if __name__ == "__main__":
    main()
