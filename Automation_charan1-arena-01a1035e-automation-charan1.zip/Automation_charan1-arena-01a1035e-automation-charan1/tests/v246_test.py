# -*- coding: utf-8 -*-
"""v246 — source freshness / health dashboard.

326 sources lo EDHI pani chestundo visibility kavali ("correct ga undali").
tools/source_health.py → output/source-health.md + source-health.html.
Bot run avvakapothe fake numbers raayadu — "live data inka ledu" ani
clear ga cheptundi.
"""
import os, re, subprocess, sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
REPO = os.path.dirname(os.path.dirname(ROOT))
sys.path.insert(0, ROOT)

fails = []
def ck(name, cond, extra=""):
    print(("  %-52s " % name) + ("✔" if cond else "✘ " + str(extra)))
    if not cond:
        fails.append(name)

def main():
    print("v246 — source health dashboard")
    tool = os.path.join(ROOT, "tools", "source_health.py")
    ck("tool undi", os.path.exists(tool))
    out = subprocess.run([sys.executable, tool, "--strict"],
                         capture_output=True, text=True, timeout=180)
    ck("--strict clean ga run avutundi", out.returncode == 0, out.stdout[-300:])
    ck("problems 0", "problems  0" in out.stdout, out.stdout[-200:])

    md = open(os.path.join(ROOT, "output", "source-health.md"), encoding="utf-8").read()
    from autoblog.sources_grid import SOURCES_GRID as G
    ck("md lo anni sources", len(re.findall(r"^\| \d+ \| ", md, re.M)) == len(G))
    ck("md lo category table", "## Sources by category" in md)
    ck("md honesty line", ("Live data inka ledu" in md) or ("Radar events" in md))

    html = open(os.path.join(REPO, "source-health.html"), encoding="utf-8").read()
    ck("html lo anni rows", html.count('<tr data-cat=') == len(G))
    ck("html lo search + tier filter", 'id="q"' in html and 'id="tier"' in html)
    ck("html mobile-first viewport", "width=device-width" in html)
    ck("html hub link", 'href="index.html"' in html)

    # honesty: live data lekapothe fake numbers undakudadu
    import sqlite3
    db = os.path.join(ROOT, "state.db")
    empty = True
    if os.path.exists(db):
        con = sqlite3.connect(db)
        try:
            empty = con.execute("SELECT COUNT(*) FROM radar_events").fetchone()[0] == 0
        except sqlite3.Error:
            pass
        con.close()
    if empty:
        ck("live data ledu ante honest message", "Live data inka ledu" in html)

    # hub + proof page lo link
    hub = open(os.path.join(REPO, "index.html"), encoding="utf-8").read()
    ck("preview hub lo link", "source-health.html" in hub)

    print("=" * 70)
    if fails:
        print("  %d TEST(S) FAILED ✘" % len(fails)); sys.exit(1)
    print("  anni v246 checks pass ✔")

if __name__ == "__main__":
    main()
