# -*- coding: utf-8 -*-
"""v251 — AI / answer-engine discovery (Google + ChatGPT/Gemini/Perplexity).

Owner: "Google lo mana page/website suggest avvali — AI kuda suggest cheyyali."

Theme (inc/ai-discovery.php):
  · robots.txt lo AI crawlers EXPLICIT allow + llms.txt + sitemap pointer
  · SiteNavigationElement ItemList (sitelinks + site structure)
  · Organization knowsAbout + sameAs (knowledge graph entity)
  · Article about / mentions / abstract / dateModified (entity retrieval)

Bot (autoblog/seo.py + pipeline):
  · citation JSON-LD — verified official sources matrame (fake citation ledu)
"""
import os, sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
THEME = os.path.join(ROOT, "wordpress-theme", "studentup")
sys.path.insert(0, ROOT)

fails = []
def ck(name, cond, extra=""):
    print(("  %-58s " % name) + ("✔" if cond else "✘ " + str(extra)))
    if not cond:
        fails.append(name)

def rd(*p):
    with open(os.path.join(*p), encoding="utf-8") as f:
        return f.read()

def main():
    print("v251 — AI discovery + citations")
    s = rd(THEME, "inc", "ai-discovery.php")
    fn = rd(THEME, "functions.php")

    ck("theme lo load avtundi", "inc/ai-discovery.php" in fn)

    # robots
    for bot in ("GPTBot", "ChatGPT-User", "OAI-SearchBot", "ClaudeBot",
                "PerplexityBot", "Google-Extended", "Applebot-Extended",
                "CCBot", "Bingbot"):
        ck("AI crawler allow: %s" % bot, "'%s'" % bot in s)
    ck("robots_txt filter", "add_filter( 'robots_txt'" in s)
    ck("wp-admin disallow intact", "Disallow: /wp-admin/" in s)
    ck("llms.txt pointer", "/llms.txt" in s)
    ck("sitemap pointer", "Sitemap: " in s)
    ck("private site lo robots marchadu", "if ( ! $public )" in s)

    # site schema
    ck("SiteNavigationElement", "SiteNavigationElement" in s)
    ck("nav items real menu nunchi", "wp_get_nav_menu_items(" in s)
    ck("menu lekapothe real categories fallback", "get_categories(" in s)
    ck("Organization @id", "#organization" in s)
    ck("knowsAbout entity topics", "knowsAbout" in s)
    ck("sameAs http matrame", "sameAs" in s and "strpos( (string) $u, 'http' )" in s)
    ck("nav cap 20 (spam ledu)", "$pos > 20" in s)

    # article entities
    ck("article about", "'about'" in s)
    ck("article mentions (max 10)", "'mentions'" in s and "array_slice( $tags, 0, 10 )" in s)
    ck("abstract (TL;DR AI ki)", "'abstract'" in s)
    ck("dateModified", "dateModified" in s)
    ck("about/mentions lekapothe schema radu", "if ( ! $about && ! $mentions )" in s)
    ck("escaping", "esc_url_raw(" in s and "wp_strip_all_tags(" in s)

    # bot citations
    from autoblog import seo
    out = seo.attach_citation_schema(
        "<p>x</p>",
        [{"text": "TSPSC official", "url": "https://www.tspsc.gov.in/"},
         {"url": "https://www.tspsc.gov.in/"},          # duplicate
         {"url": "javascript:alert(1)"}])               # invalid
    ck("citation schema add avtundi", '"citation"' in out)
    ck("duplicate URL okkasaare", out.count("tspsc.gov.in") == 1)
    ck("javascript: URL block", "javascript:" not in out)
    ck("idempotent", seo.attach_citation_schema(out, [{"url": "https://a.gov.in"}]) == out)
    ck("links lekapothe fake citation ledu",
       seo.attach_citation_schema("<p>x</p>", []) == "<p>x</p>")
    ck("max 8 citations",
       seo.citation_schema([{"url": "https://x%d.gov.in" % i} for i in range(20)]).count("WebPage") == 8)

    pipe = rd(ROOT, "autoblog", "pipeline.py")
    ck("pipeline lo wire ayindi", "seo.attach_citation_schema(" in pipe)
    ck("publish aapadu (try/except)", "v251 citation schema skip (publish safe)" in pipe)

    print("=" * 76)
    if fails:
        print("  %d TEST(S) FAILED ✘" % len(fails)); sys.exit(1)
    print("  anni v251 checks pass ✔")

if __name__ == "__main__":
    main()
