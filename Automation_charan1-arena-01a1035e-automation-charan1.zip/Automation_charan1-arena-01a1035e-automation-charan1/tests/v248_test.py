# -*- coding: utf-8 -*-
"""v248 — tools OFF + SEO MAX layer.

Owner: "tools em vaddu (age calculator laantivi), space waste avtundi.
Inka best SEO + keywords + Rank Math + Google top ki emem kavalo anni build cheyyi."

A) inc/tools-off.php — tool shortcodes khaali, tool pages noindex +
   sitemap nunchi tholagimpu, firstrun aa pages create cheyyadu,
   megamenu lo Tools column poyi Daily Quiz vachhindi.
B) inc/seo-max.php — rel prev/next · speakable schema · news_keywords +
   article:tag · article:modified_time/og:updated_time · paged title ·
   thin archive + search noindex,follow · orphan-guard parent link.
"""
import os, sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
THEME = os.path.join(ROOT, "wordpress-theme", "studentup")

fails = []
def ck(name, cond, extra=""):
    print(("  %-56s " % name) + ("✔" if cond else "✘ " + str(extra)))
    if not cond:
        fails.append(name)

def rd(*p):
    with open(os.path.join(*p), encoding="utf-8") as f:
        return f.read()

def main():
    print("v248 — tools OFF + SEO MAX")
    off = rd(THEME, "inc", "tools-off.php")
    seo = rd(THEME, "inc", "seo-max.php")
    fn = rd(THEME, "functions.php")
    mega = rd(THEME, "inc", "megamenu.php")
    first = rd(THEME, "inc", "firstrun.php")

    # ---------- A. tools off ----------
    ck("tools-off.php load avtundi", "inc/tools-off.php" in fn)
    ck("default OFF", "'studentup_tools_enabled', false" in off)
    ck("marali ON cheyyochu (filter)", "apply_filters( 'studentup_tools_enabled'" in off)
    for sc in ("studentup_age_calc", "studentup_fee_calc", "studentup_score_calc",
               "studentup_resume_maker", "studentup_compare", "studentup_saved",
               "studentup_workspace", "studentup_syllabus_tracker"):
        ck("shortcode off: %s" % sc, "'%s'" % sc in off)
    ck("shortcode khaali string istundi", "__return_empty_string" in off)
    ck("tool pages noindex", "'noindex'" in off and "wp_robots" in off)
    ck("sitemap nunchi tholagimpu", "wp_sitemaps_posts_query_args" in off and "post__not_in" in off)
    ck("firstrun lo create cheyyadu", "studentup_firstrun_pages" in off)
    ck("firstrun filtered list vadutundi",
       "studentup_setup_pages_filtered()" in first and "apply_filters( 'studentup_firstrun_pages'" in first)

    # megamenu: Tools column poyindi, Daily Quiz vachhindi
    ck("menu lo Tools group ledu", "'label'   => 'Tools'" not in mega)
    ck("menu lo Age/Fee/Resume items levu",
       all(x not in mega for x in ("Age Eligibility", "Fee Calculator",
                                   "Resume Maker", "Compare Jobs", "Saved Posts")))
    ck("menu lo Daily Quiz group vachhindi", "'label'   => 'Daily Quiz'" in mega)
    ck("quiz feature CTA", "Start quiz" in mega)

    # ---------- B. seo max ----------
    ck("seo-max.php load avtundi", "inc/seo-max.php" in fn)
    ck("rel prev", "rel=\"prev\"" in seo)
    ck("rel next", "rel=\"next\"" in seo)
    ck("pagination singular lo radu", "! is_singular()" in seo)
    ck("speakable schema", "SpeakableSpecification" in seo and "cssSelector" in seo)
    ck("speakable selectors theme lo nijam", ".article-head h1" in seo)
    ck("news_keywords", "news_keywords" in seo)
    ck("article:tag", "article:tag" in seo)
    ck("keyword cap 10 (stuffing ledu)", "array_slice( array_unique( $terms ), 0, 10 )" in seo)
    ck("modified time signals", "article:modified_time" in seo and "og:updated_time" in seo)
    ck("paged title suffix", "document_title_parts" in seo and "Page %d" in seo)
    ck("search + empty archive noindex,follow",
       "is_search()" in seo and "'follow' => " not in seo and "$robots['follow'] = 'follow'" in seo)
    ck("content unna archive noindex kaadu", "found_posts" in seo)
    ck("orphan guard parent link", "su-parent-link" in seo and "get_category_link" in seo)
    ck("parent link idempotent", "false !== strpos( $content, 'su-parent-link' )" in seo)
    ck("escaping (esc_url/esc_attr/esc_html)",
       all(x in seo for x in ("esc_url(", "esc_attr(", "esc_html(")))

    # fake/spam guards
    ck("fake rating/review schema ledu",
       "aggregateRating" not in seo and "AggregateRating" not in seo)
    ck("keyword stuffing meta ledu", '"keywords"' not in seo and "name=\"keywords\"" not in seo)

    css = rd(THEME, "assets", "css", "premium.css")
    ck("parent link css", ".su-parent-link" in css)

    print("=" * 74)
    if fails:
        print("  %d TEST(S) FAILED ✘" % len(fails)); sys.exit(1)
    print("  anni v248 checks pass ✔")

if __name__ == "__main__":
    main()
