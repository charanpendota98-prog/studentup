# -*- coding: utf-8 -*-
"""v253 — live originality check: CSE credentials unte adi MANDATORY.

Owner: "no copy ... 100 times check ... actual ga check cheyu".

v103 lo live web originality check unnadi, kaani credentials unna kuda
status=partial/error aite publish continue ayyedi (silent degrade = copy risk).
v253: GOOGLE_CSE_API_KEY + GOOGLE_CSE_ID rendu unte, live check complete
avvakapothe publish BLOCK avutundi (ORIG_LIVE_REQUIRED env avasaram ledu).
"""
import os, sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)

fails = []
def ck(name, cond, extra=""):
    print(("  %-58s " % name) + ("✔" if cond else "✘ " + str(extra)))
    if not cond:
        fails.append(name)


def rd(*parts):
    with open(os.path.join(*parts), encoding="utf-8") as fh:
        return fh.read()


def main():
    print("=" * 76)
    print("  v253 — LIVE ORIGINALITY GATE (CSE unte mandatory)")
    print("=" * 76)

    pipe = rd(ROOT, "autoblog", "pipeline.py")
    ck("CSE readiness check undi", "_cse_ready" in pipe)
    ck("GOOGLE_CSE_API_KEY chustunnam", "GOOGLE_CSE_API_KEY" in pipe)
    ck("GOOGLE_CSE_ID chustunnam", "GOOGLE_CSE_ID" in pipe)
    ck("required = ORIG_LIVE_REQUIRED OR cse_ready",
       "_live_required" in pipe and "ORIG_LIVE_REQUIRED" in pipe)
    ck("partial/error aite block",
       '_live_rep.get("status") in ("partial", "error")' in pipe
       and "_live_required" in pipe)
    ck("exact match aite epudaina block",
       "SKIP-LIVE-EXACT-OVERLAP" in pipe)
    ck("fake PASS ledu (report, never fake)",
       "report, never fake PASS" in pipe)

    # thresholds inka unnayi ani confirm (regression guard)
    from autoblog import config
    ck("ORIG hard floor >= 80", float(getattr(config, "ORIG_HARD_FLOOR", 0)) >= 80.0)
    ck("publish originality min >= 70",
       float(getattr(config, "PUBLISH_ORIGINALITY_MIN", 0)) >= 70.0)
    ck("QA min score >= 80", int(getattr(config, "PUBLISH_QA_MIN_SCORE", 0)) >= 80)
    ck("Rank Math target 100", int(getattr(config, "RM_TARGET", 0)) == 100)
    ck("min live sources >= 3", int(getattr(config, "SOURCE_MIN_LIVE", 0)) >= 3)
    ck("min official source >= 1", int(getattr(config, "SOURCE_MIN_OFFICIAL", 0)) >= 1)

    # Rank Math engine nijamga 100 ki techuntunda (deterministic proof)
    from autoblog import rm100
    art = rm100.sample_article()
    res = rm100.optimize(art, target=100, max_passes=3)
    ck("rm100: sample article 100/100 reach avtundi",
       res["score"] == 100 and res["reached"], res["score"])
    ck("rm100: migilina issues zero",
       rm100.analyze(res["article"])["issues"] == [],
       rm100.analyze(res["article"])["issues"])

    print("=" * 76)
    if fails:
        print("  %d TEST(S) FAILED ✘" % len(fails)); sys.exit(1)
    print("  anni v253 checks pass ✔")


if __name__ == "__main__":
    main()
