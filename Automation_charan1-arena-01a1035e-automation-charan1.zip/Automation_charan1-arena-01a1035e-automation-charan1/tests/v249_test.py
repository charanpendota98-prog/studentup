# -*- coding: utf-8 -*-
"""v249 — Doubts & Answers (Q&A) feature, real backend tho.

Owner: "inka chaala advanced ga". Ide nijam ga advanced:
user-generated long-tail content + QAPage rich result + return visits +
content-gap radar (students em adugutunnaro adi next post topic).

UI matrame kaadu ani prove cheyyali:
  storage (WP comments table) · permissions (moderate_comments) ·
  validation (length, links, honeypot, nonce, rate limit, duplicate) ·
  moderation (default unapproved) · error handling (clear messages) ·
  no-JS form + REST API · QAPage schema answered-only · privacy (IP hash).
"""
import os, sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
THEME = os.path.join(ROOT, "wordpress-theme", "studentup")

fails = []
def ck(name, cond, extra=""):
    print(("  %-58s " % name) + ("✔" if cond else "✘ " + str(extra)))
    if not cond:
        fails.append(name)

def rd(*p):
    with open(os.path.join(*p), encoding="utf-8") as f:
        return f.read()

def main():
    print("v249 — Doubts & Answers")
    s = rd(THEME, "inc", "doubts.php")
    fn = rd(THEME, "functions.php")
    css = rd(THEME, "assets", "css", "premium.css")

    ck("theme lo load avtundi", "inc/doubts.php" in fn)
    ck("filter tho OFF cheyyochu", "apply_filters( 'studentup_doubts_enabled'" in s)

    # storage
    ck("WP comments table lo store", "wp_insert_comment(" in s)
    ck("separate comment_type", "comment_type" in s and "su_doubt" in s)
    ck("normal comment counts lo kalupadu", "comments_clauses" in s)

    # moderation
    ck("default unapproved (moderation)", "'comment_approved' => 0" in s)
    ck("approved vi matrame chupistam", "'status'  => 'approve'" in s)

    # validation / spam
    ck("min length check", "STUDENTUP_DOUBT_MIN" in s)
    ck("max length 600", "STUDENTUP_DOUBT_MAX  = 600" in s)
    ck("links/email/phone block", "https?://" in s and "@[a-z0-9" in s)
    ck("honeypot field", "su_doubt_hp" in s and "honeypot" in s.lower())
    ck("nonce verify", "wp_verify_nonce( $nonce, 'su_doubt_'" in s)
    ck("rate limit 60s", "set_transient( $rl, 1, 60 )" in s)
    ck("duplicate question guard", "strcasecmp" in s)
    ck("html strip + sanitize", "wp_strip_all_tags(" in s and "sanitize_text_field(" in s)
    ck("output escaping", "esc_html(" in s and "esc_attr(" in s)

    # privacy
    ck("IP plain ga store cheyyam (hash)", "wp_hash(" in s and "REMOTE_ADDR" in s)

    # no-JS + REST
    ck("no-JS form (POST + redirect)", "template_redirect" in s and "wp_safe_redirect(" in s)
    ck("REST route", "register_rest_route(" in s and "'/doubt'" in s)
    ck("REST error status 400", "? 200 : 400" in s)

    # errors
    for msg in ("Please wait a minute before asking again.",
                "Links, emails and phone numbers are not allowed",
                "Could not save the question"):
        ck("error message: %s…" % msg[:28], msg in s)

    # schema
    ck("QAPage schema", "'QAPage'" in s and "acceptedAnswer" in s)
    ck("answer leni question schema lo radu", "continue; // answer leni question schema lo vaddu" in s)

    # admin
    ck("admin answer box", "add_meta_boxes_comment" in s and "su_answer" in s)
    ck("admin capability check", "current_user_can( 'moderate_comments' )" in s)
    ck("admin nonce", "su_doubt_answer_nonce" in s)
    ck("answer length cap", "0, 1200 )" in s)

    # a11y / mobile css
    ck("css undi", ".su-doubts{" in css)
    ck("16px input (phone zoom aagutundi)", "font-size:16px" in css.split(".su-doubt-form textarea")[1][:200])
    ck("44px tap target", "min-height:44px" in css)
    ck("honeypot screen reader ki hidden", "su-doubt-hp" in css and "left:-9999px" in css)
    ck("dark mode", "body.dark .su-doubts" in css)

    print("=" * 76)
    if fails:
        print("  %d TEST(S) FAILED ✘" % len(fails)); sys.exit(1)
    print("  anni v249 checks pass ✔")

if __name__ == "__main__":
    main()
