# -*- coding: utf-8 -*-
"""v243 — master 265-item checklist audit + hreflang annotation.

Owner 42-item list tarvata 265-item Telugu master checklist ichadu
(foundation → pages → search → SEO → speed → analytics → trust → security →
DAILY QUIZ full spec → content → admin → accounts → money → integrations →
a11y → QA → launch day). `tools/master265_audit.py` prathi item ni repo lo
check chesi CODE / KEY / MANUAL / NA / GAP status istundi — gaps 0 undali.
"""
import os, re, subprocess, sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
def rd(*p):
    with open(os.path.join(ROOT, *p), encoding="utf-8") as f:
        return f.read()

fails = []
def ck(name, cond, extra=""):
    print(("  %-54s " % name) + ("✔" if cond else "✘ " + str(extra)))
    if not cond:
        fails.append(name)

def main():
    print("v243 — master 265 checklist + hreflang")
    tool = rd("tools", "master265_audit.py")
    ck("audit tool undi", "MASTER 265" in tool)
    ck("265 items assert undi", 'len(items) == 265' in tool)
    ck("5 statuses (CODE/KEY/MANUAL/NA/GAP)",
       all(s in tool for s in ['"CODE"', '"KEY"', '"MANUAL"', '"NA"', '"GAP"']))

    out = subprocess.run([sys.executable, os.path.join(ROOT, "tools", "master265_audit.py")],
                         capture_output=True, text=True, timeout=180)
    ck("audit run avutundi", out.returncode == 0, out.stderr[-200:])
    txt = out.stdout
    m = re.search(r"GAP\s+(\d+)", txt)
    ck("GAP 0", bool(m) and int(m.group(1)) == 0, txt[-200:])
    m2 = re.search(r"CODE\s+(\d+)", txt)
    ck("CODE items 180+", bool(m2) and int(m2.group(1)) >= 180, txt[-200:])

    rep = rd("output", "master-265.md")
    ck("report lo anni 265 rows", len(re.findall(r"^\| \d+ \|", rep, re.M)) == 265)
    ck("report lo daily quiz section", "9A. Daily Quiz" in rep and "9B. Daily Quiz" in rep
       and "9C. Daily Quiz" in rep)

    # hreflang (item 163)
    schema = rd("wordpress-theme", "studentup", "inc", "schema.php")
    ck("hreflang function undi", "function studentup_hreflang_tags(" in schema)
    ck("self + x-default emit avutundi", 'hreflang="x-default"' in schema and "esc_url( $url )" in schema)
    ck("wp_head ki hook ayindi", "add_action( 'wp_head', 'studentup_hreflang_tags'" in schema)
    ck("archives/search lo radu", "is_search()" in schema and "is_singular()" in schema)

    print("=" * 74)
    if fails:
        print("  %d TEST(S) FAILED ✘" % len(fails)); sys.exit(1)
    print("  anni v243 checks pass ✔")

if __name__ == "__main__":
    main()
