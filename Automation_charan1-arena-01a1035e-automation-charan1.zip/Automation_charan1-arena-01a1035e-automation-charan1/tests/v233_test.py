# -*- coding: utf-8 -*-
"""v233 — home page space fix + naukri-style scrolling category rail.

Owner feedback (Telugu): hero lo pedda H1 "avasaram ledu", search chinnaga
"Search StudentUp", Latest Jobs anni jobs latest-first open cheyyali, mariyu
TS/AP/Central laanti sections neat icons tho, naukri lo la ADVANCED ga
horizontal scrolling rail ga home lo pైne ravali.

Regenerator: tools/apply_v233_home.py (preview side), drawer side ki
tools/apply_v230_drawer.py — rendu idempotent.
"""
import os, re, sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
def rd(*p):
    with open(os.path.join(ROOT, *p), encoding="utf-8") as f:
        return f.read()

CATS = ["ts-jobs","ap-jobs","central","hall-tickets","results",
        "walkin","software","success-stories","private","current-affairs"]
LABELS = ["TS Govt Jobs","AP Govt Jobs","Central Jobs","Hall Tickets","Results",
          "Walk-in Jobs","Software Jobs","Success Stories","Private Jobs","Current Affairs"]

fails = []
def ck(name, cond, extra=""):
    print(("  %-52s " % name) + ("✔" if cond else "✘ " + str(extra)))
    if not cond:
        fails.append(name)

def main():
    print("v233 — home space + naukri scrolling category rail")
    prem = rd("wordpress-theme", "studentup", "inc", "premium.php")
    front = rd("wordpress-theme", "studentup", "front-page.php")
    css = rd("wordpress-theme", "studentup", "assets", "css", "premium.css")
    tool = rd("tools", "apply_v233_home.py")

    # 1. hero H1 — SEO ki DOM lo undi, kaani kanipinchadu
    ck("hero h1 su-h1-quiet tho hidden",
       re.search(r'<h1[^>]*class="su-hero-title su-h1-quiet"', prem) is not None)
    ck("su-h1-quiet CSS sr-only ga undi",
       ".su-h1-quiet{" in css and "clip-path:inset(50%)" in css)

    # 2. search placeholder chinnaga
    ck("placeholder 'Search StudentUp' tho start avthundi",
       re.search(r"'Search StudentUp[^']*'", prem) is not None)

    # 3. Latest Jobs → full board, latest-first
    ck("Latest Jobs chip board URL vadthundi",
       "studentup_opportunity_board_url()" in prem and "'board'" in prem)

    # 4. rail renderer
    ck("studentup_category_rail() function undi",
       "function studentup_category_rail(" in prem)
    # v234: rail ippudu hero LOPALA — search box ki ventane kinda
    ck("rail hero lo search box kinda call avthundi",
       prem.index("studentup_category_rail();") > prem.index('class="su-search-wrap"')
       and prem.index("studentup_category_rail();") < prem.index('class="su-hero-acts"'))
    ck("front-page lo duplicate rail call ledu",
       "studentup_category_rail" not in front)
    ck("rail prathi term ni studentup_used_term() tho gate chesthundi",
       "studentup_used_term(" in prem.split("function studentup_category_rail(")[1])

    # 5. 10 categories — order + labels
    rail_php = prem.split("function studentup_category_rail(")[1]
    for slug, label in zip(CATS, LABELS):
        ck("rail lo '%s' undi" % label, slug in rail_php and label in rail_php)

    # 6. CSS — nijam ga scroll avuthunda?
    ck("su-catrail horizontal scroll + snap",
       "overflow-x:auto" in css and "scroll-snap-type:x" in css
       and "-webkit-overflow-scrolling:touch" in css)
    ck("scrollbar mobile lo kanipinchadu",
       ".su-catrail::-webkit-scrollbar{display:none}" in css and "scrollbar-width:none" in css)
    ck("prathi card ki snap-align + fixed width",
       "scroll-snap-align:start" in css)
    ck("10 color tints (.c1 … .c10)",
       all((".su-cat.c%d " % i) in css for i in range(1, 11)))
    ck("laptop lo rail grid ga marthundi",
       "repeat(10,minmax(0,1fr))" in css)
    ck("dark mode support",
       "body.dark .su-catrail>a{" in css)
    ck("reduced-motion respect",
       "prefers-reduced-motion" in css)

    # 7. preview pages — owner nijam ga open chesi chudagaligelaa
    for page in [("preview", "worldclass", "index.html"), ("preview", "worldclass", "standalone.html")]:
        html = rd(*page)
        name = page[-1]
        ck("%s: rail markup undi" % name, 'class="su-catrail"' in html)
        ck("%s: 10 cat cards" % name, len(re.findall(r'class="su-cat c\d+"', html)) == 10)
        ck("%s: h1 hidden" % name, "su-h1-quiet" in html)
        ck("%s: placeholder chinnadi" % name, "Search StudentUp" in html)
        ck("%s: rail search box ki kinda, hero lopala" % name,
           html.index('<div class="su-catrail"') > html.index('<div class="su-search-wrap">')
           and html.index('<div class="su-catrail"') < html.index('<div class="su-hero-acts">'))
        ck("%s: okkate rail (duplicate ledu)" % name, html.count('<section class="su-catwrap') == 1)
        ck("%s: anni icons sprite lo unnayi" % name,
           all(("#su-i-" + i) in html for i in
               ["bank", "city", "flag", "badge", "award", "walk", "code", "trophy", "work", "globe"]))

    # 8. v235 — advanced layer: arrows · progress · drag · counts
    js = rd("wordpress-theme", "studentup", "assets", "js", "studentup-premium.js")
    ck("arrows + progress bar markup (theme)",
       'class="su-railbox"' in prem and "su-railnav--l" in prem
       and "su-railnav--r" in prem and 'class="su-railbar"' in prem)
    ck("card meeda count pill (term->count)",
       "su-cat-n" in prem and "$term->count" in prem)
    ck("rail keyboard reachable (tabindex + aria-label)",
       'class="su-catrail" role="list" tabindex="0"' in prem)
    ck("JS: drag + arrows + progress + keyboard",
       "pointerdown" in js and "su-railnav--l" in js and "su-railbar i" in js
       and "ArrowRight" in js and "prefers-reduced-motion" in js)
    ck("JS: okkasari matrame init (data-su-rail guard)", "dataset.suRail" in js)
    ck("CSS: edge fade + arrows + progress + drag cursor",
       ".su-railbox::before" in css and ".su-railnav{" in css
       and ".su-railbar i{" in css and ".su-catrail.is-drag{" in css)
    ck("CSS: gradient icon chip + count pill + entry animation",
       ".su-cat-ic::after" in css and ".su-cat-n{" in css and "@keyframes su-cat-in" in css)
    for page in [("preview", "worldclass", "index.html"), ("preview", "worldclass", "standalone.html")]:
        html, name = rd(*page), page[-1]
        ck("%s: arrows + progress + counts" % name,
           html.count("su-railnav") >= 4 and 'class="su-railbar"' in html
           and len(re.findall(r'class="su-cat-n"', html)) == 10)
        ck("%s: rail JS inline ga undi" % name, "v235 category rail" in html)

    # 9. v236 — tagline teesesaam + clicks/revenue polish
    drawer_tool = rd("tools", "apply_v230_drawer.py")
    ck("drawer brand lo tagline ledu (owner: paina idi avasaram ledu)",
       "Jobs · Results · Scholarships" not in drawer_tool)
    ck("CSS: top-3 money sections highlight + live dot",
       ".su-catwrap .su-cat.c1" in css and "@keyframes su-cat-live" in css)
    ck("CSS: laptop lo 5-column grid",
       "repeat(5,minmax(0,1fr))" in css)
    ck("rail CSS critical lo leaking ledu (.su-hero scope vadaledu)",
       ".su-hero .su-cat" not in css)
    for page in [("preview", "worldclass", "index.html"), ("preview", "worldclass", "standalone.html")]:
        html, name = rd(*page), page[-1]
        ck("%s: tagline teesesaam" % name, "Jobs · Results · Scholarships" not in html)

    # 10. regenerator idempotent
    icons = rd("wordpress-theme", "studentup", "inc", "icons.php")
    ck("kotha icons theme sprite lo unnayi",
       all(("'%s'" % k) in icons for k in ["city", "badge", "award", "code", "globe"]))
    ck("prathi category ki veru icon (repeat ledu)",
       len(set(re.findall(r"'icon' => '([a-z]+)'", rail_php))) == 10)
    ck("apply_v233_home.py idempotent guard undi", "su-catwrap" in tool and "NEW_ICONS" in tool)

    print("=" * 74)
    if fails:
        print("  %d TEST(S) FAILED ✘" % len(fails))
        sys.exit(1)
    print("  anni v233 checks pass ✔")

if __name__ == "__main__":
    main()
