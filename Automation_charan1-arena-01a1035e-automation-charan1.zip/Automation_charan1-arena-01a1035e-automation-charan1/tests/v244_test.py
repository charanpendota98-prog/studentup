# -*- coding: utf-8 -*-
"""v244 — advanced thumbnail polish + advanced-proof page.

Owner: "thumbnail advanced ga, best ga undali". image_gen.py ki _pro_polish()
layer add ayindi (stripe texture, corner glow, left accent bar, bottom fade,
vignette) — kaani text safe band (21%..79%) ni touch cheyyadu, kabatti mobile
square crop lo kuda okka letter kuda podu.
"""
import os, sys, tempfile
from pathlib import Path

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)

fails = []
def ck(name, cond, extra=""):
    print(("  %-52s " % name) + ("✔" if cond else "✘ " + str(extra)))
    if not cond:
        fails.append(name)

def main():
    print("v244 — advanced thumbnails")
    src = open(os.path.join(ROOT, "autoblog", "image_gen.py"), encoding="utf-8").read()
    ck("_pro_polish() undi", "def _pro_polish(" in src)
    ck("generate lo call avutundi", "img = _pro_polish(img, w, h)" in src)
    for bit in ("diagonal stripe", "vignette", "GaussianBlur", "ACCENT + (235,)"):
        ck("polish piece: %s" % bit, bit in src)

    from autoblog.image_gen import generate_featured_image, VARIANTS
    ck("3 layouts rotate", len(VARIANTS) == 3)
    with tempfile.TemporaryDirectory() as td:
        for v in VARIANTS:
            p = generate_featured_image("TSPSC Group 2 Notification 2026 — 1,540 Posts",
                                        "TS Govt Jobs", Path(td) / ("t_%s.jpg" % v), variant=v)
            ck("render: %s" % v, p is not None and p.exists() and p.stat().st_size > 8000)
        from PIL import Image
        im = Image.open(Path(td) / "t_bottom.jpg")
        ck("size 1200x675", im.size == (1200, 675), im.size)

    # advanced-proof page (repo root lo)
    page = Path(ROOT).parent.parent / "advanced-proof.html"
    if page.exists():
        html = page.read_text(encoding="utf-8")
        ck("proof page lo thumbs", html.count("preview-thumbs/thumb") >= 6)
        ck("proof page lo honest pending section", "migilindi" in html)

    print("=" * 70)
    if fails:
        print("  %d TEST(S) FAILED ✘" % len(fails)); sys.exit(1)
    print("  anni v244 checks pass ✔")

if __name__ == "__main__":
    main()
