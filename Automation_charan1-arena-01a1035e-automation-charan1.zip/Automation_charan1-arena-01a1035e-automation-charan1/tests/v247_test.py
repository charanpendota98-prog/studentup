# -*- coding: utf-8 -*-
"""v247 — advanced article enrichment: 2nd in-article image + summary table.

Owner: "inka advanced ga... kaani correct ga undali."
  · attach_second_image()  — pedda articles ki rendo image (deep scroll),
    idempotent, CLS-safe, vere alt. Chinna article ki add cheyyadu.
  · ensure_summary_table() — structured recruitment facts nunchi oka clean
    table. Facts lekapothe table ne raayadu (fake table = thin content).
Rendu publish pipeline lo wire ayyayi + theme CSS lo mobile-first styles.
"""
import os, re, sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)

fails = []
def ck(name, cond, extra=""):
    print(("  %-56s " % name) + ("✔" if cond else "✘ " + str(extra)))
    if not cond:
        fails.append(name)

BIG = ("<h2>Overview</h2><p>a</p><h2>Eligibility</h2><p>b</p>"
       "<h2>How to apply</h2><p>c</p><h2>FAQ</h2><p>d</p>")
SMALL = "<h2>Overview</h2><p>a</p>"

def main():
    print("v247 — 2nd image + summary table")
    from autoblog import seo

    # ---------- second image ----------
    one = seo.attach_inline_image(BIG, "https://x/a.webp", "alt one")
    two = seo.attach_second_image(one, "https://x/b.webp", "alt two")
    ck("pedda article ki 2nd image add avtundi", two.count("<img") == 2)
    ck("rendo figure ki separate class", "su-figure-2" in two)
    ck("CLS safe (width+height)", two.count('width="1200"') == 2 and two.count('height="675"') == 2)
    ck("lazy + async decode", two.count('loading="lazy"') == 2 and two.count('decoding="async"') == 2)
    ck("alt duplicate kaadu", 'alt="alt one"' in two and 'alt="alt two"' in two)
    ck("idempotent (3rd image radu)",
       seo.attach_second_image(two, "https://x/c.webp", "three").count("<img") == 2)
    ck("chinna article lo add cheyyadu",
       seo.attach_second_image(seo.attach_inline_image(SMALL, "https://x/a.webp", "a"),
                               "https://x/b.webp", "b").count("<img") == 1)
    ck("khaali url = no-op", seo.attach_second_image(one, "", "x") == one)
    ck("2nd image chivari section lo (1st kanna kinda)",
       two.index("su-figure-2") > two.index('alt="alt one"'))

    # ---------- summary table ----------
    rec = {"org_name": "TSPSC", "vacancies": "1540", "apply_end": "2026-11-20",
           "qualification": "Degree", "apply_url": "https://www.tspsc.gov.in/"}
    t = seo.ensure_summary_table(BIG, rec)
    ck("table add ayindi", "<table" in t and "su-summary-table" in t)
    ck("facts anni vachhayi", all(x in t for x in ("TSPSC", "1540", "20-Nov-2026", "Degree")))
    ck("apply link nofollow+blank", 'rel="nofollow noopener"' in t and 'target="_blank"' in t)
    ck("first h2 tarvata place ayindi", t.index("su-summary-table") < t.index("Eligibility"))
    ck("idempotent (rendo table radu)",
       seo.ensure_summary_table(t, rec).count("<table") == 1)
    ck("already table unte touch cheyyadu",
       seo.ensure_summary_table("<h2>A</h2><table><tr><td>x</td></tr></table>", rec).count("<table") == 1)

    # HONESTY — facts lekapothe fake table raayakudadu
    ck("facts levu → table ledu", seo.ensure_summary_table(BIG, {}) == BIG)
    ck("okka fact → table ledu (thin)",
       seo.ensure_summary_table(BIG, {"org_name": "TSPSC"}) == BIG)
    ck("placeholder values skip (TBA/NA/-)",
       seo.ensure_summary_table(BIG, {"org_name": "TSPSC", "vacancies": "TBA",
                                      "qualification": "N/A"}) == BIG)
    ck("tappu date guess cheyyadu",
       "Last date" not in seo.ensure_summary_table(
           BIG, {"org_name": "TSPSC", "qualification": "Degree",
                 "apply_end": "soon"}))
    ck("non-http apply link skip",
       "Official link" not in seo.ensure_summary_table(
           BIG, {"org_name": "TSPSC", "qualification": "Degree",
                 "apply_url": "javascript:alert(1)"}))
    ck("XSS escape",
       "<script>" not in seo.ensure_summary_table(
           BIG, {"org_name": "<script>bad</script>", "qualification": "Degree"}))

    # ---------- pipeline wiring ----------
    pipe = open(os.path.join(ROOT, "autoblog", "pipeline.py"), encoding="utf-8").read()
    ck("pipeline lo attach_second_image", "seo.attach_second_image(" in pipe)
    ck("pipeline lo ensure_summary_table", "seo.ensure_summary_table(" in pipe)
    ck("rendu try/except lo (publish aagadu)", pipe.count("v247") >= 3)

    # ---------- theme css ----------
    css = open(os.path.join(ROOT, "wordpress-theme", "studentup", "assets",
                            "css", "premium.css"), encoding="utf-8").read()
    ck("css: summary table styles", ".su-summary-table table" in css)
    ck("css: mobile scroll guard", "overflow-x:auto" in css)
    ck("css: phone breakpoint", "@media(max-width:480px)" in css)

    print("=" * 74)
    if fails:
        print("  %d TEST(S) FAILED ✘" % len(fails)); sys.exit(1)
    print("  anni v247 checks pass ✔")

if __name__ == "__main__":
    main()
