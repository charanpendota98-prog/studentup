# -*- coding: utf-8 -*-
"""v245 — advanced source expansion (owner: "sources inka advanced ga").

Grid 258 → 326 curated sources. Kotha vi: TS/AP department-wise official
recruitment (TGPSC/APPSC groups, police, DSC, gurukul, discoms, RTC, health,
courts), central departments (IB/CBI/AAI/ECIL/BEL/HAL), board + university
results, hall tickets, exam calendars, scholarships (ePASS/Jnanabhumi/NSP),
IT hiring, internships. Duplicate name/query okkati kuda undakudadu.
"""
import os, sys, collections

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)

fails = []
def ck(name, cond, extra=""):
    print(("  %-52s " % name) + ("✔" if cond else "✘ " + str(extra)))
    if not cond:
        fails.append(name)

LIVE_CATS = {
    "Central Govt Jobs", "TS Govt Jobs", "AP Govt Jobs", "Private Jobs",
    "Software Jobs", "Walkin Jobs", "Outsourcing Jobs", "Part Time Jobs",
    "Abroad Jobs", "Internships", "Results", "Hall Tickets", "Upcoming Exams",
    "Current Affairs", "Exam Tips", "Scholarships", "Online Education",
    "Success Stories",
}

def main():
    print("v245 — advanced sources grid")
    from autoblog.sources_grid import SOURCES_GRID as G
    names = [g["name"] for g in G]
    qs = [g["q"] for g in G]
    ck("sources 320+", len(G) >= 320, len(G))
    ck("duplicate names levu", len(set(names)) == len(names),
       [k for k, v in collections.Counter(names).items() if v > 1])
    ck("duplicate queries levu", len(set(qs)) == len(qs),
       [k for k, v in collections.Counter(qs).items() if v > 1])
    bad = sorted({g["cat"] for g in G} - LIVE_CATS)
    ck("categories = live categories matrame", not bad, bad)
    ck("daily hot-list 50+ (radar budget balance)", sum(1 for g in G if g.get("daily")) >= 50)

    cats = collections.Counter(g["cat"] for g in G)
    for c, n in (("TS Govt Jobs", 20), ("AP Govt Jobs", 20), ("Results", 20),
                 ("Hall Tickets", 6), ("Scholarships", 14), ("Software Jobs", 15)):
        ck("%s ≥ %d sources" % (c, n), cats[c] >= n, cats[c])

    must = ["TGPSC Group 1", "APPSC Group 1", "TS Police Constable SI",
            "AP Grama Sachivalayam", "TS ePASS", "AP Jnanabhumi",
            "RRB NTPC ALP Group D", "PM Internship Scheme"]
    for m in must:
        ck("source undi: %s" % m, m in names)

    for g in G:
        if not g["name"].strip() or not g["q"].strip():
            ck("khaali source entry", False, g)
            break

    print("=" * 70)
    if fails:
        print("  %d TEST(S) FAILED ✘" % len(fails)); sys.exit(1)
    print("  anni v245 checks pass ✔")

if __name__ == "__main__":
    main()
