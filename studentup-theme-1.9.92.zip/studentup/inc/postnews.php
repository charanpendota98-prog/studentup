<?php
/**
 * v294 — "Post Your News" (reader submissions) + Breaking News section rules.
 *
 * Owner (2026-10-14):
 *  · Daily Quiz pakkana "Post your news" — readers send success stories,
 *    photos, videos, district information. We approve → we post.
 *    Google Form attach cheyyochu (Settings → Verified Success Story Google Form URL).
 *  · Open chesthe aa section (page) chupinchali — approved stories motivational ga.
 *  · Breaking News = separate section (district news). Click → category opens.
 *    Breaking posts HOME PAGE lo chupinchoddu — only Breaking News open chesina
 *    vallaki kanipinchali.
 *
 * Honesty contract: form URL lekapote iframe render kaadu (WhatsApp/Telegram
 * send buttons matrame — avi real). Approved stories lekapote grid render kaadu.
 *
 * @package studentup
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Page slug for the submissions page (firstrun creates it). */
define( 'STUDENTUP_POSTNEWS_SLUG', 'post-your-news' );

/**
 * URL of the Post Your News page ('' when the page is not published yet).
 *
 * @return string
 */
function studentup_postnews_url() {
	$url = function_exists( 'studentup_mega_page_url' ) ? studentup_mega_page_url( array( STUDENTUP_POSTNEWS_SLUG, 'share-your-story' ) ) : '';
	if ( ! $url ) {
		$page = get_page_by_path( STUDENTUP_POSTNEWS_SLUG );
		if ( $page instanceof WP_Post && 'publish' === get_post_status( $page ) ) {
			$url = (string) get_permalink( $page );
		}
	}
	return $url;
}

/**
 * Configured Google Form URL (embed-safe) or ''.
 *
 * @return string
 */
function studentup_postnews_form_url() {
	$u = function_exists( 'studentup_opt' ) ? trim( (string) studentup_opt( 'success_story_form_url', '' ) ) : '';
	if ( ! $u || ! preg_match( '#^https?://#i', $u ) ) {
		return '';
	}
	return esc_url_raw( $u );
}

/**
 * Google Form "embedded=true" variant (only for docs.google.com/forms URLs).
 *
 * @param string $url form url.
 * @return string '' when not embeddable.
 */
function studentup_postnews_embed_url( $url ) {
	$host = wp_parse_url( $url, PHP_URL_HOST );
	if ( ! $host || ! preg_match( '#(^|\.)docs\.google\.com$#i', $host ) || false === stripos( $url, '/forms/' ) ) {
		return '';
	}
	$url = preg_replace( '#/(viewform|edit)(\?.*)?$#i', '/viewform', $url );
	return add_query_arg( 'embedded', 'true', $url );
}

/**
 * Compact CTA card — sits under the Daily Quiz on the home grid.
 * Renders only when the page exists (no dead links).
 *
 * @return void
 */
function studentup_postnews_cta() {
	$url = studentup_postnews_url();
	if ( ! $url ) {
		return;
	}
	?>
	<a class="su-postnews" href="<?php echo esc_url( $url ); ?>" data-su-ev="postnews_open">
		<span class="su-postnews-ic" aria-hidden="true"><?php echo studentup_ui_icon( 'upload', 22 ); // phpcs:ignore WordPress.Security.EscapeOutput -- trusted SVG ?></span>
		<span class="su-postnews-body">
			<b><?php esc_html_e( 'Post your news', 'studentup' ); ?></b>
			<span class="su-postnews-chips">
				<i><?php esc_html_e( 'Success story', 'studentup' ); ?></i><i><?php esc_html_e( 'Photo / Video', 'studentup' ); ?></i><i><?php esc_html_e( 'District update', 'studentup' ); ?></i>
			</span>
		</span>
		<span class="su-postnews-go" aria-hidden="true"><?php echo studentup_ui_icon( 'arrow', 18 ); // phpcs:ignore WordPress.Security.EscapeOutput -- trusted SVG ?></span>
	</a>
	<?php
}

/**
 * Approved stories (published posts in success-stories family) — newest first.
 *
 * @param int $n max.
 * @return WP_Post[]
 */
function studentup_postnews_approved( $n = 12 ) {
	$term = function_exists( 'studentup_used_term' ) ? studentup_used_term( 'success-stories' ) : null;
	if ( ! $term ) {
		return array();
	}
	$q = new WP_Query(
		array(
			'cat'                 => (int) $term->term_id,
			'posts_per_page'      => max( 1, (int) $n ),
			'post_status'         => 'publish',
			'ignore_sticky_posts' => true,
			'no_found_rows'       => true,
		)
	);
	return $q->posts;
}

/* ------------------------------------------------------------------------- */
/* Breaking News — own section; never on the home page.                      */
/* ------------------------------------------------------------------------- */

/**
 * Breaking News category (real term) or null.
 *
 * @return WP_Term|null
 */
function studentup_breaking_term() {
	static $t = false;
	if ( false === $t ) {
		$t = null;
		foreach ( array( 'breaking-news', 'breaking' ) as $slug ) {
			$term = get_category_by_slug( $slug );
			if ( $term && ! is_wp_error( $term ) ) {
				$t = $term;
				break;
			}
		}
	}
	return $t;
}

/**
 * Breaking News section URL — category archive when it exists, else home anchor.
 *
 * @return string
 */
function studentup_breaking_section_url() {
	$t = studentup_breaking_term();
	return $t ? (string) get_category_link( $t ) : home_url( '/#breaking' );
}

/**
 * Hide breaking-news posts from every query that is NOT the breaking section
 * itself (home loops, Top 5, slider, latest, RSS home, related). Single posts,
 * search, the category archive, feeds of that category and admin stay intact.
 *
 * @param WP_Query $q query.
 * @return void
 */
function studentup_breaking_hide_from_home( $q ) {
	if ( is_admin() || ! ( $q instanceof WP_Query ) ) {
		return;
	}
	$t = studentup_breaking_term();
	if ( ! $t ) {
		return;
	}
	if ( 'post' !== (string) ( $q->get( 'post_type' ) ?: 'post' ) ) {
		return;
	}
	// Queries that explicitly ask for the breaking category → leave them alone.
	$asked = array_filter(
		array(
			(string) $q->get( 'cat' ),
			(string) $q->get( 'category_name' ),
			implode( ',', (array) $q->get( 'category__in' ) ),
			implode( ',', (array) $q->get( 'category__and' ) ),
		)
	);
	foreach ( $asked as $v ) {
		if ( false !== stripos( $v, $t->slug ) || in_array( (string) $t->term_id, array_map( 'trim', explode( ',', $v ) ), true ) ) {
			return;
		}
	}
	if ( $q->get( 'tax_query' ) || $q->get( 'p' ) || $q->get( 'name' ) || $q->get( 'post__in' ) ) {
		return;
	}
	if ( $q->is_main_query() ) {
		if ( $q->is_singular() || $q->is_search() || $q->is_tag() || $q->is_author() || $q->is_date() || $q->is_feed() ) {
			return;
		}
		if ( $q->is_category( $t->term_id ) ) {
			return;
		}
	}
	$not = (array) $q->get( 'category__not_in' );
	$not[] = (int) $t->term_id;
	$q->set( 'category__not_in', array_values( array_unique( array_map( 'intval', $not ) ) ) );
}
add_action( 'pre_get_posts', 'studentup_breaking_hide_from_home', 9 );

/**
 * firstrun: make sure the Breaking News category + Post Your News page exist.
 */
add_filter(
	'studentup_firstrun_pages',
	static function ( $pages ) {
		$pages = (array) $pages;
		if ( ! isset( $pages[ STUDENTUP_POSTNEWS_SLUG ] ) ) {
			$pages[ STUDENTUP_POSTNEWS_SLUG ] = 'Post Your News';
		}
		return $pages;
	},
	5
);

/**
 * Assign the page template to the submissions page (works for pages created
 * earlier too — runs once per admin load, cheap get_page_by_path).
 */
function studentup_postnews_assign_template() {
	$page = get_page_by_path( STUDENTUP_POSTNEWS_SLUG );
	if ( $page instanceof WP_Post && 'page-post-news.php' !== (string) get_post_meta( $page->ID, '_wp_page_template', true ) ) {
		update_post_meta( $page->ID, '_wp_page_template', 'page-post-news.php' );
	}
	if ( ! studentup_breaking_term() ) {
		$res = wp_insert_term(
			'Breaking News',
			'category',
			array(
				'slug'        => 'breaking-news',
				'description' => 'District-wise breaking updates. This section is shown only here, not on the home page.',
			)
		);
		if ( is_wp_error( $res ) && 'term_exists' === $res->get_error_code() ) {
			// Name exists under a different slug — nothing to do.
			return;
		}
	}
}
add_action( 'admin_init', 'studentup_postnews_assign_template' );
add_action( 'after_switch_theme', 'studentup_postnews_assign_template' );
